import json,sys,types
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import unsprung_joint,compare_lab_compute
scenario=sys.argv[1];output=root/'logs/lab-perf-16'/('duplicates-'+scenario)
solve_code=unsprung_joint.solve_unsprung_joint.__code__
eval_code=next(c for c in solve_code.co_consts if isinstance(c,types.CodeType) and c.co_name=='evaluate')
stack=[];rows=[]

def profile(frame,event,arg):
    if frame.f_code is solve_code:
        if event=='call':stack.append({'counter':Counter(),'last_end':None,'last_force':None,'last_torque':None,'torques':set()})
        elif event=='return':
            state=stack.pop();counter=state['counter'];counter['unique_torque_vectors']=len(state['torques']);rows.append(dict(counter))
    elif frame.f_code is eval_code and event=='call':
        state=stack[-1];values=frame.f_locals['values'];end=values[:16].tobytes();force=(end,values[16:24].tobytes());torque=values[24:].tobytes()
        state['counter']['evaluations']+=1
        for name,key in (('end',end),('force',force),('torque',torque)):
            state['counter'][name+'_changes']+=key!=state['last_'+name];state['last_'+name]=key
        state['torques'].add(torque)
sys.setprofile(profile)
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=output))
finally:sys.setprofile(None)
result=json.loads((output/'result.json').read_text(encoding='utf-8'));count=result['substeps'];measured=rows[-count:]
totals={name:sum(row.get(name,0) for row in measured) for name in measured[0]}
reference=root/'logs/lab-perf-15/complete-AB'/('braking-B1' if scenario=='braking' else 'nonlinear-B')/'payload.bin'
assert (output/'payload.bin').read_bytes()==reference.read_bytes()
(output/'duplicates.json').write_text(json.dumps({'scope':'原共同解不改的call事件计数，耗时不作性能收益；初始化与测量分别保存','scenario':scenario,'all_substeps':rows,'measured_substeps':count,'measured_counts':totals,'payload_exact_to_baseline':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(totals)
