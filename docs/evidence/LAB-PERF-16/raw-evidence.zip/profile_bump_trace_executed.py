import json,sys
from pathlib import Path
root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import cProfile,pstats
from types import SimpleNamespace
from lab_experiment import LabExperiment
import compare_lab_compute

output=root/'logs/lab-perf-16/profile-bump'
profile=cProfile.Profile()
import ast,types
from collections import Counter
import unsprung_joint
solve_code=unsprung_joint.solve_unsprung_joint.__code__
targets={c for c in solve_code.co_consts if isinstance(c,types.CodeType) and c.co_name in ('evaluate','velocity_terms')}
tree=ast.parse((root/'src/unsprung_joint.py').read_text(encoding='utf-8'))
lines={}
for name in ('reaction_base','force_reaction','torque_data'):
    nodes=[n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)]
    assert len(nodes)==1,name
    lines[nodes[0].lineno]=name
stack=[];counts=[]
def trace(frame,event,arg):
    if frame.f_code is solve_code:
        if event=='call':stack.append(Counter());frame.f_trace_lines=False
        elif event=='return':counts.append(dict(stack.pop()))
        return trace
    if frame.f_code in targets:
        if event=='line' and frame.f_lineno in lines:stack[-1][lines[frame.f_lineno]]+=1
        return trace
    return None
sys.settrace(trace)
original=LabExperiment.step

def step(run):
    profile.enable()
    try:return original(run)
    finally:profile.disable()

LabExperiment.step=step
try:
    compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    LabExperiment.step=original
    sys.settrace(None)
count=288;measured=counts[-count:]
(output/"reuse-counts.json").write_text(json.dumps({"measured_substeps":count,"by_substep":measured,"counts":{name:sum(row.get(name,0) for row in measured) for name in lines.values()}},indent=2)+"\n",encoding="utf-8")
profile.dump_stats(str(output/'step.prof'))
with (output/'profile.txt').open('w',encoding='utf-8') as stream:
    stats=pstats.Stats(profile,stream=stream)
    stats.sort_stats('cumulative').print_stats(55)
    stats.sort_stats('tottime').print_stats(35)
rows=[{'file':path,'line':line,'function':function,'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for (path,line,function),v in stats.stats.items()]
(output/'profile.json').write_text(json.dumps({'ticks':144,'total_seconds':stats.total_tt,'functions':rows,'scope':'完整非线性实体凸起的独立诊断；分析器耗时不进入速度收益表'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-16/complete-AB/nonlinear-B/payload.bin').read_bytes()
print('bump profile physics payload exact')
