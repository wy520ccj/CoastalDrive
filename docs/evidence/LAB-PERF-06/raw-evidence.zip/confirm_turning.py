import json
import subprocess
import sys
from pathlib import Path
root=Path.cwd()
output=root/'logs/lab-perf-06/turning-confirmation'
output.mkdir(parents=True,exist_ok=False)
rows=json.loads((root/'logs/lab-perf-06/complete-AB/summary.json').read_text(encoding='utf-8'))
rows=[row for row in rows if row['scenario']=='turning']
reference=(root/'logs/lab-perf-06/complete-AB/turning-A/payload.bin').read_bytes()
for name,source in (('turning-B2',root),('turning-A2',root/'builds/lab-perf-06/baseline')):
    command=[sys.executable,str(root/'tools/physics/run_sim_double.py'),str(root/'tools/performance/compare_lab_compute.py'),'--worker','--source',str(source),'--scenario','turning','--output',str(output/name)]
    print('RUN',name,flush=True)
    with (output/(name+'.txt')).open('w',encoding='utf-8') as stream:
        subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=240)
    row=json.loads((output/name/'result.json').read_text(encoding='utf-8'))
    assert (output/name/'payload.bin').read_bytes()==reference
    rows.append({'case':name,**row,'complete_payload_equal':True})
    print('PASSED',name,row['wall_seconds'],flush=True)
(output/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
