import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root/"src"))
from lab_runtime import runtime_fingerprint

output = root/"logs/lab-perf-06/lab-regression-final"
output.mkdir(parents=True, exist_ok=False)
os.environ["LOCALAPPDATA"] = str(output/"user-data")
names = sorted({p.name for pattern in ("test_unsprung*.py", "test_lab*.py")
                for p in (root/"tests").glob(pattern)} | {
    "test_vehicle_unsprung.py", "test_radial_geometry.py", "test_box_radial_geometry.py",
    "test_finite_radial_contact.py", "test_finite_suspension.py", "test_suspension_bench.py",
    "test_suspension_preload.py", "test_suspension_motion.py", "test_suspension_damper.py", "test_suspension_work.py"})
summary = {"scope": "实验台专项完整模块与记录复算；按用户限定不运行游戏seed/window；不是通用T1/T2/T3 Gate",
           "runtime": runtime_fingerprint(), "tests": names, "checks": [], "passed": False}
commands = [("ruff", [sys.executable, "-m", "ruff", "check", "src", "tests", "tools"]),
            ("pytest", [sys.executable, "-m", "pytest", "-q", *["tests/"+name for name in names]])]
for name, command in commands:
    before = time.perf_counter()
    print("RUN", name, flush=True)
    with (output/(name+".log")).open("w", encoding="utf-8") as stream:
        result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT, check=False, timeout=300)
    row = {"name": name, "command": command, "exit_code": result.returncode,
           "seconds": time.perf_counter()-before}
    summary["checks"].append(row)
    (output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(row, flush=True)
    assert result.returncode == 0
summary["passed"] = True
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
