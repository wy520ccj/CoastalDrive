import hashlib
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
sys.path.insert(0, str(root/"src"))
logs = root/"logs/lab-perf-14"
output = root/"docs/evidence/LAB-PERF-14"
output.mkdir(parents=True, exist_ok=True)
baseline = root/"builds/lab-perf-14/baseline/src"
suffixes = (".py", ".c", ".cpp", ".h")
old_names = {p.name for p in baseline.iterdir() if p.suffix in suffixes}
new_names = {p.name for p in (root/"src").iterdir() if p.suffix in suffixes}
changes = sorted(name for name in old_names | new_names if name not in old_names or name not in new_names
                 or (baseline/name).read_bytes().replace(b"\r\n", b"\n") != (root/"src"/name).read_bytes().replace(b"\r\n", b"\n"))
assert changes == ["radial_geometry.py","unsprung_contact_geometry.py"]
import ast
old_radial=ast.parse((baseline/"radial_geometry.py").read_text(encoding="utf-8"))
new_radial=ast.parse((root/"src/radial_geometry.py").read_text(encoding="utf-8"))
old_nodes={n.name:n for n in old_radial.body if isinstance(n,ast.ClassDef)}
new_nodes={n.name:n for n in new_radial.body if isinstance(n,ast.ClassDef)}
for name in ("UnsprungGeometry","RadialHit","RadialSurface"):
    assert ast.dump(old_nodes[name])==ast.dump(new_nodes[name]),name
old_query=next(n for n in old_nodes["RadialRoads"].body if isinstance(n,ast.FunctionDef) and n.name=="query")
ref=ast.parse((root/"tests/lab_surface_cache_reference.py").read_text(encoding="utf-8"))
ref_query=next(n for n in ref.body if isinstance(n,ast.FunctionDef) and n.name=="query_reference")
assert ast.dump(ast.Module(body=old_query.body))==ast.dump(ast.Module(body=ref_query.body))
old_contact=ast.parse((baseline/"unsprung_contact_geometry.py").read_text(encoding="utf-8"))
new_contact=ast.parse((root/"src/unsprung_contact_geometry.py").read_text(encoding="utf-8"))
old_class=next(n for n in old_contact.body if isinstance(n,ast.ClassDef) and n.name=="FiniteRadialContact")
new_class=next(n for n in new_contact.body if isinstance(n,ast.ClassDef) and n.name=="FiniteRadialContact")
for name in ("__init__","evaluate"):
    old=next(n for n in old_class.body if isinstance(n,ast.FunctionDef) and n.name==name)
    new=next(n for n in new_class.body if isinstance(n,ast.FunctionDef) and n.name==name)
    for node in ast.walk(new):
        if isinstance(node,ast.Call):node.keywords=[k for k in node.keywords if k.arg!="surface_cache"]
    assert ast.dump(old)==ast.dump(new),name
old_tool=(baseline.parent/"tools/physics/unsprung_step_checkpoint.py").read_text(encoding="utf-8")
new_tool=(root/"tools/physics/unsprung_step_checkpoint.py").read_text(encoding="utf-8")
added='    finite.query_cache = (None if all(surface.plane is not None for surface in roads.surfaces)\n                          else [{} for _ in roads.surfaces])\n'
assert new_tool.replace(added,'',1)==old_tool
rows = json.loads((logs/"final-AB/summary.json").read_text(encoding="utf-8"))
assert len(rows)==12
assert sum(row["substeps"] for row in rows)==1728


def case_root(row):
    return logs/"final-AB"/row["case"]

native_by_label = {}
for label in ("A", "B"):
    cases = [row for row in rows if "-"+label in row["case"]]
    native_by_label[label] = {name: value["sha256"] for name, value in cases[0]["native"].items()}
    assert all({name: value["sha256"] for name, value in row["native"].items()} == native_by_label[label] for row in cases)
    source = baseline if label == "A" else root/"src"
    for name, value in cases[0]["native"].items():
        assert Path(value["path"]).parent == source.resolve()
        assert hashlib.sha256(Path(value["path"]).read_bytes()).hexdigest() == value["sha256"]
assert native_by_label["A"]==native_by_label["B"]
assert all(row["runtime"] == rows[0]["runtime"] and row["complete_payload_equal"] and row["substeps"] == 2*row["ticks"] for row in rows)
for row in rows:
    source = baseline if "-A" in row["case"] else root/"src"
    assert row["source_hashes"] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix in suffixes}
groups = []
for scenario in ("braking", "turning", "nonlinear-bump"):
    cases = [row for row in rows if row["scenario"] == scenario]
    expected = (case_root(cases[0])/"payload.bin").read_bytes()
    for row in cases:
        actual = (case_root(row)/"payload.bin").read_bytes()
        assert actual == expected and row["payload_sha256"] == hashlib.sha256(expected).hexdigest()
        assert row["config"] == cases[0]["config"] and row["options"] == cases[0]["options"]
    payload = pickle.loads(expected)
    assert len(payload["snapshots"]) == cases[0]["ticks"]+1 and len(payload["joint"]) == cases[0]["substeps"]
    assert all(row["joint_iterations"] == cases[0]["joint_iterations"] for row in cases)
    measured = {}
    for label in ("A", "B"):
        sample = [row for row in cases if "-"+label in row["case"]]
        steps = [dt for row in sample for dt in row["step_seconds"]]
        measured[label] = {"runs": len(sample),
            **{key: float(np.mean([r[key] for r in sample])) for key in ("wall_seconds", "cpu_seconds", "physics_snapshot_seconds")},
            "step_p95_seconds": float(np.percentile(steps, 95)), "step_p99_seconds": float(np.percentile(steps, 99)),
            "initialization": {key: float(np.mean([r["initialization"][key] for r in sample]))
                               for key in ("wall_seconds", "cpu_seconds", "ticks")}}
    group = {"scenario": scenario, "options": cases[0]["options"], "actual_config": cases[0]["config"],
             "requested_config": cases[0]["requested_config"], "measured": measured,
             "wall_reduction_percent": 100*(1-measured["B"]["wall_seconds"]/measured["A"]["wall_seconds"]),
             "cpu_reduction_percent": 100*(1-measured["B"]["cpu_seconds"]/measured["A"]["cpu_seconds"]),
             "complete_payload_exact": True, "payload_sha256": hashlib.sha256(expected).hexdigest()}
    if scenario == "braking":
        import math
        assert max(command.brake for command in payload["commands"])==1.
        first,last=payload["snapshots"][0].player,payload["snapshots"][-1].player
        assert math.hypot(*last.velocity[:2]) < math.hypot(*first.velocity[:2])
    if scenario == "nonlinear-bump":
        assert group["actual_config"]["suspension_coil_enabled"] and group["actual_config"]["suspension_damper_curves"]
        load = np.asarray([s.player.unsprung_state.normal_force for s in payload["snapshots"]])
        group["peak_normal_load_change_from_initial_N"] = np.max(abs(load-load[0]), axis=0).tolist()
        assert group["peak_normal_load_change_from_initial_N"][0] > 100 and group["peak_normal_load_change_from_initial_N"][2] > 100
    groups.append(group)
frozen = json.loads((logs/"frozen-results.json").read_text(encoding="utf-8"))
assert frozen["exact"] and len(frozen["runs"][0]["cases"]) == 18 and frozen["runs"][0]["cases"] == frozen["runs"][1]["cases"]
import re
validation_counts={}
for folder,name in (("T0","Double_T0"),("T0-standard","standard_T0"),("lab-regression","Double_lab_regression")):
    log=(logs/folder/"pytest.log").read_text(encoding="utf-8")
    matches=re.findall(r"(\d+) passed",log)
    assert len(matches)==1
    validation_counts[name]=int(matches[0])
assert validation_counts["Double_lab_regression"]==501
validation = {name: json.loads((logs/name/"summary.json").read_text(encoding="utf-8"))
              for name in ("T0", "T0-standard", "lab-regression")}
assert all(result["passed"] for result in validation.values())
old_profile_root = root/"logs/lab-perf-13/profile-after"
old_profile_result = json.loads((old_profile_root/"result.json").read_text(encoding="utf-8"))
reused_short_profile_EOL_variants={}
for name,old_hash in old_profile_result["source_hashes"].items():
    raw=(baseline/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()==old_hash:continue
    lf=raw.replace(b"\r\n",b"\n")
    matches=[label for label,value in (("LF",lf),("CRLF",lf.replace(b"\n",b"\r\n"))) if hashlib.sha256(value).hexdigest()==old_hash]
    assert len(matches)==1,name
    reused_short_profile_EOL_variants[name]=matches[0]
for path in baseline.glob("*.pyd"):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == old_profile_result["source_hashes"][path.name]
new_profile_result=json.loads((logs/"profile-after/result.json").read_text(encoding="utf-8"))
assert old_profile_result["config"] == new_profile_result["config"]
assert old_profile_result["options"] == new_profile_result["options"]
assert old_profile_result["snapshot_hashes"] == new_profile_result["snapshot_hashes"]
profiles = {"before": json.loads((old_profile_root/"profile.json").read_text(encoding="utf-8")),
            "after": json.loads((logs/"profile-after/profile.json").read_text(encoding="utf-8"))}
import ast
query_lines = {}
for label, path in (("before", baseline/"radial_geometry.py"),("after",root/"src/radial_geometry.py")):
    tree=ast.parse(path.read_text(encoding="utf-8"))
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="RadialRoads")
    query_lines[label]=next(n.lineno for n in node.body if isinstance(n,ast.FunctionDef) and n.name=="query")
profile_rows = {}
for label, profile in profiles.items():
    def calls(name, file, line=None):
        found = [row for row in profile["functions"] if row["function"] == name and Path(row["file"]).name == file
                 and (line is None or row["line"] == line)]
        assert len(found) == 1
        return found[0]["calls"]
    profile_rows[label] = {"ticks": profile["ticks"], "residual_calls": calls("evaluate", "unsprung_joint.py"),
                           "road_geometry_queries": calls("query", "radial_geometry.py", query_lines[label]),
                           "port_assembly_calls": calls("tire_ports", "unsprung_drivetrain.py"),
                           "generic_concatenation_calls": calls("__getitem__", "_index_tricks_impl.py"),
                           "numpy_cross_calls": calls("cross", "numeric.py"),
                           "native_body_torque_calls": sum(r["calls"] for r in profile["functions"] if "wheel_contact_kernels.unsprung_body_torque>" in r["function"])}
for values in profile_rows.values():
    assert {k: values[k] for k in ("ticks", "residual_calls", "road_geometry_queries", "port_assembly_calls")} == {"ticks": 6, "residual_calls": 1692, "road_geometry_queries": 1122, "port_assembly_calls": 552}
assert profile_rows["before"]["generic_concatenation_calls"] == profile_rows["after"]["generic_concatenation_calls"] == 186
assert profile_rows["before"]["numpy_cross_calls"] == profile_rows["after"]["numpy_cross_calls"] == 894
assert profile_rows["before"]["native_body_torque_calls"] == profile_rows["after"]["native_body_torque_calls"] == 1692
for label,profile in profiles.items():
    for kernel in ("radial_plane_values","radial_contact_frames"):
        profile_rows[label]["native_"+kernel+"_calls"]=sum(r["calls"] for r in profile["functions"] if "wheel_contact_kernels."+kernel+">" in r["function"])
for label,profile in profiles.items():
    for name,file in (("native_gyro_impulse","unsprung_dynamics.py"),("rotation_increment","unsprung_motion.py"),("solve","_linalg.py")):
        selected=[r for r in profile["functions"] if r["function"]==name and Path(r["file"]).name==file]
        assert len(selected)==1
        profile_rows[label][name+"_calls"]=selected[0]["calls"]
assert profile_rows["before"]["native_gyro_impulse_calls"] == 1095
assert profile_rows["after"]["native_gyro_impulse_calls"] == 1095
assert [profile_rows[label]["rotation_increment_calls"] for label in ("before","after")]==[1080,1080]
assert profile_rows["before"]["solve_calls"] == profile_rows["after"]["solve_calls"] == 2823
for label,profile in profiles.items():
    for name,file in (("contact_force","tire_compliance.py"),("clip","fromnumeric.py")):
        profile_rows[label][name+"_calls"]=sum(r["calls"] for r in profile["functions"] if r["function"]==name and Path(r["file"]).name==file)
    for kernel in ("unsprung_contact_residual","unsprung_port_residual"):
        profile_rows[label][kernel+"_calls"]=sum(r["calls"] for r in profile["functions"] if "mechanical_kernels."+kernel+">" in r["function"])
assert profile_rows["before"]["contact_force_calls"]==0 and profile_rows["after"]["contact_force_calls"]==0
assert profile_rows["before"]["clip_calls"]==0 and profile_rows["after"]["clip_calls"]==0
assert profile_rows["after"]["unsprung_contact_residual_calls"]==profile_rows["after"]["unsprung_port_residual_calls"]==1692
bump_profile=json.loads((logs/"profile-bump/profile.json").read_text(encoding="utf-8"))
bump_result=json.loads((logs/"profile-bump/result.json").read_text(encoding="utf-8"))
assert (logs/"profile-bump/payload.bin").read_bytes()==(logs/"final-AB/nonlinear-B/payload.bin").read_bytes()
assert bump_result["config"]==next(row["config"] for row in rows if row["case"]=="nonlinear-B")
assert bump_result["source_hashes"]==next(row["source_hashes"] for row in rows if row["case"]=="nonlinear-B")
old_bump_root=root/"logs/lab-perf-13/profile-bump"
old_bump_result=json.loads((old_bump_root/"result.json").read_text(encoding="utf-8"))
old_bump_profile=json.loads((old_bump_root/"profile.json").read_text(encoding="utf-8"))
baseline_source_hashes=next(row["source_hashes"] for row in rows if row["case"]=="nonlinear-A")
assert old_bump_result["source_hashes"].keys()==baseline_source_hashes.keys()
eol_differences={}
for name,old_hash in old_bump_result["source_hashes"].items():
    if old_hash==baseline_source_hashes[name]:continue
    raw=(baseline/name).read_bytes().replace(b"\r\n",b"\n")
    variants={"LF":raw,"CRLF":raw.replace(b"\n",b"\r\n")}
    matches=[label for label,value in variants.items() if hashlib.sha256(value).hexdigest()==old_hash]
    assert len(matches)==1,name
    eol_differences[name]=matches[0]

for name,value in old_bump_result["native"].items():
    assert value["sha256"]==native_by_label["A"][name]
assert old_bump_result["config"]==bump_result["config"]
assert (old_bump_root/"payload.bin").read_bytes()==(logs/"profile-bump/payload.bin").read_bytes()
bump_hotspots={}
for label,profile in (("before",old_bump_profile),("after",bump_profile)):
    data={}
    for name,file in (("box_section","box_radial_geometry.py"),("evaluate","box_radial_geometry.py"),("wheel_support","box_radial_geometry.py"),("query","radial_geometry.py")):
        found=[r for r in profile["functions"] if r["function"]==name and Path(r["file"]).name==file]
        if name=="query":found=[r for r in found if r["line"]==query_lines[label]]
        assert len(found)==1 or (name in ("evaluate","wheel_support") and len(found)==0)
        data[name]=({**found[0],"fraction_of_profile_total":found[0]["cumulative_seconds"]/profile["total_seconds"]} if found else {"calls":0})
    for kernel in ("box_cone_samples","box_cone_refine","box_axis_supports","radial_box_bounds","box_face_candidates","box_edge_frames"):
        data[kernel+"_calls"]=sum(r["calls"] for r in profile["functions"] if "wheel_contact_kernels."+kernel+">" in r["function"])
    data["unit_matrix_calls"]=sum(r["calls"] for r in profile["functions"] if r["function"]=="eye" and Path(r["file"]).name=="_twodim_base_impl.py")
    bump_hotspots[label]=data
assert bump_hotspots["before"]["query"]["calls"]==bump_hotspots["after"]["query"]["calls"]==29260
cache_stats=json.loads((logs/"profile-bump/cache-stats.json").read_text(encoding="utf-8"))
for kind in ("plane","nonplane"):
    assert cache_stats[kind+"_cached_requests"]==115312
    assert cache_stats[kind+"_hits"]==36408
    assert cache_stats[kind+"_uncached_rows"]==1728
assert bump_hotspots["after"]["radial_box_bounds_calls"]==1728+115312-36408
for label in ("before","after"):
    assert bump_hotspots[label]["box_cone_samples_calls"]==4*bump_hotspots[label]["box_section"]["calls"]
assert bump_hotspots["after"]["box_section"]["calls"]<bump_hotspots["before"]["box_section"]["calls"]
assert bump_hotspots["after"]["box_cone_refine_calls"]<bump_hotspots["before"]["box_cone_refine_calls"]
assert not any("_cached_plane"==r["function"] for r in profiles["after"]["functions"])
full_bump_call_counts={}
for label,profile in (("before",old_bump_profile),("after",bump_profile)):
    counts={}
    for name,file in (("evaluate","unsprung_joint.py"),("normal_material","unsprung_contact.py"),("solve","_linalg.py")):
        found=[row for row in profile["functions"] if row["function"]==name and Path(row["file"]).name==file]
        assert len(found)==1
        counts[file+":"+name]=found[0]["calls"]
    full_bump_call_counts[label]=counts
assert full_bump_call_counts["before"]==full_bump_call_counts["after"]=={"unsprung_joint.py:evaluate":44318,"unsprung_contact.py:normal_material":14126,"_linalg.py:solve":74040}
initial_rows=json.loads((logs/"complete-AB/summary.json").read_text(encoding="utf-8"))
assert len(initial_rows)==12 and sum(r["substeps"] for r in initial_rows)==1728
for row in initial_rows:
    raw=(logs/"complete-AB"/row["case"]/"payload.bin").read_bytes()
    final=next(r for r in rows if r["scenario"]==row["scenario"])
    assert raw==(case_root(final)/"payload.bin").read_bytes() and row["complete_payload_equal"]
    assert row["config"]==final["config"] and row["options"]==final["options"]
    for name,sha in row["source_hashes"].items():
        path=baseline/name if '-A' in row["case"] else logs/"initial-source/src"/name
        if not path.is_file():path=root/"src"/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==sha,(row["case"],name)
    assert {k:v["sha256"] for k,v in row["native"].items()}==native_by_label["A"]
duplicates={}
for scenario in ("braking","nonlinear-bump"):
    folder=logs/("duplicates-"+scenario)
    result=json.loads((folder/"duplicates.json").read_text(encoding="utf-8"))
    assert result["payload_exact_to_LAB_PERF_13"]
    assert (folder/"payload.bin").read_bytes()==(case_root(next(r for r in rows if r["scenario"]==scenario))/"payload.bin").read_bytes()
    duplicates[scenario]={key:value for key,value in result.items() if key!="by_context"}
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".log", ".txt", ".py", ".md", ".bin", ".prof", ".pkl") and "user-data" not in path.parts:
            archive.write(path, path.relative_to(logs).as_posix())
    for path in old_profile_root.iterdir():
        if path.is_file():
            archive.write(path, "reused-baseline-profile/"+path.name)
    for path in old_bump_root.iterdir():
        if path.is_file():archive.write(path,"reused-baseline-bump-profile/"+path.name)
    for name in ("src/radial_geometry.py","src/unsprung_contact_geometry.py","tools/physics/unsprung_step_checkpoint.py"):
        archive.write(baseline.parent/name,"baseline-source/"+name)
    for path in baseline.glob("*.pyd"):
        archive.write(path,"executed-native/baseline/"+path.name)
    for path in ("tools/performance/compare_lab_compute.py","tools/physics/unsprung_step_checkpoint.py","src/radial_geometry.py","src/unsprung_contact_geometry.py","tests/test_lab_surface_cache.py","tests/lab_surface_cache_reference.py"):
        archive.write(root/path,"executed-source/"+path)

summary = {"baseline": "5f3b38d", "source_changes": changes, "all_native_and_C_source_unchanged": True,
           "joint_solver_and_original_material_functions_exact": True, "runtime": rows[0]["runtime"], "native_sha256": native_by_label,
           "groups": groups, "total_substeps_compared": 3456, "final_substeps_compared":1728, "initial_cases":[{key:row[key] for key in ("case","scenario","wall_seconds","cpu_seconds","initialization","payload_sha256","complete_payload_equal")} |
             {"raw_result":"complete-AB/"+row["case"]+"/result.json", "step_p95_seconds":float(np.percentile(row["step_seconds"],95)),"step_p99_seconds":float(np.percentile(row["step_seconds"],99)),
              "source_hashes_sha256":hashlib.sha256(json.dumps(row["source_hashes"],sort_keys=True).encode()).hexdigest()} for row in initial_rows], "duplicate_diagnosis":duplicates, "cache_stats":cache_stats, "frozen_scenarios": frozen, "profile_call_counts": profile_rows, "bump_hotspots": bump_hotspots, "full_bump_call_counts": full_bump_call_counts, "reused_bump_profile_EOL_variants": eol_differences, "reused_short_profile_EOL_variants": reused_short_profile_EOL_variants, "validation": validation,
           "validation_counts": validation_counts,
           "formal_full_T1_T2_T3": "not_run; 按用户范围只做试验台，完整专项回归/记录复算完成，游戏seed/window未跑",
           "physics_gate": "原完整模型/120Hz/两子步/34变量/epsilon/阈值保持，物理输出精确相同；既有能量精度Gate开放",
           "known_mesh_boundary": "部分旋转三角网格边缘的原EPA拒绝收敛；旧新异常类型/支持间隙文本一致，未放宽阈值，仍待修复",
           "real_time_human_gate": "open; 当前仍慢于实时，人工体验待确认",
           "continuous_goal": "active; 本块完成不代表持续优化目标完成",
           "raw_evidence_sha256": hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()}
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{k: group[k] for k in ("scenario", "wall_reduction_percent", "cpu_reduction_percent")} for group in groups], indent=2))
print("source/binaries/config/payload/native boundary/18 physical cases/query counts/validation verified")
