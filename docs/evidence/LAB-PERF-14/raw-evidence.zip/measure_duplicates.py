import json,sys,weakref
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
import numpy as np
root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
from radial_geometry import RadialRoads
from unsprung_contact_geometry import FiniteRadialContact
import compare_lab_compute
scenario=sys.argv[1];output=root/'logs/lab-perf-14'/('duplicates-'+scenario)
states=weakref.WeakKeyDictionary();counts=Counter();contexts=[]
original_init=FiniteRadialContact.__init__;original_query=RadialRoads.query

def key(center,axis):
    return center.dtype.str,center.shape,center.strides,center.tobytes(),axis.dtype.str,axis.shape,axis.strides,axis.tobytes()

def init(self,roads,*args,**kwargs):
    state=([set() for _ in roads.surfaces],Counter())
    states[roads]=state;contexts.append(state[1])
    return original_init(self,roads,*args,**kwargs)

def query(self,centers,up,axes):
    state=states.get(self)
    if state is not None:
        known,row=state
        centers,axes=map(np.asarray,(centers,axes))
        row['queries']+=1
        for surface,seen in zip(self.surfaces,known,strict=True):
            kind='plane' if surface.plane is not None else 'nonplane'
            for center,axis in zip(centers,axes,strict=True):
                k=key(center,axis);hit=k in seen;seen.add(k)
                counts[kind+'_rows']+=1;counts[kind+'_hits']+=hit
                row[kind+'_rows']+=1;row[kind+'_hits']+=hit
    return original_query(self,centers,up,axes)
FiniteRadialContact.__init__=init;RadialRoads.query=query
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=output))
finally:FiniteRadialContact.__init__=original_init;RadialRoads.query=original_query
reference=root/'logs/lab-perf-13/complete-AB'/('braking-B1' if scenario=='braking' else 'nonlinear-B')/'payload.bin'
assert (output/'payload.bin').read_bytes()==reference.read_bytes()
result={'scope':'原物理查询不变的重复量诊断；含真实初始化，耗时不作收益表','scenario':scenario,'contexts':len(contexts),'counts':dict(counts),'by_context':[dict(row) for row in contexts],'payload_exact_to_LAB_PERF_13':True}
(output/'duplicates.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(result['counts'])
