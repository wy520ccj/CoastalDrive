import json,sys
from pathlib import Path
root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import cProfile,pstats
from types import SimpleNamespace
from lab_experiment import LabExperiment
import compare_lab_compute

output=root/'logs/lab-perf-14/profile-bump'
profile=cProfile.Profile()
from collections import Counter
from radial_geometry import RadialRoads
cache_stats=Counter();measured=False
original_query=RadialRoads.query

def query(self,centers,up,axes,**kwargs):
    if not measured:return original_query(self,centers,up,axes,**kwargs)
    cache=kwargs.get('surface_cache')
    if cache is None:
        for surface in self.surfaces:
            label='plane' if surface.plane is not None else 'nonplane'
            cache_stats[label+'_uncached_rows']+=len(centers)
    else:
        import numpy as np
        centers,axes=map(np.asarray,(centers,axes))
        layout=centers.dtype.str,centers.shape[1:],centers.strides[1:],axes.dtype.str,axes.shape[1:],axes.strides[1:]
        keys=tuple((layout,center.tobytes(),axis.tobytes()) for center,axis in zip(centers,axes,strict=True))
        for surface,known in zip(self.surfaces,cache,strict=True):
            label='plane' if surface.plane is not None else 'nonplane'
            cache_stats[label+'_cached_requests']+=len(keys)
            cache_stats[label+'_hits']+=sum(key in known for key in keys)
    result=original_query(self,centers,up,axes,**kwargs)
    if cache is not None:cache_stats['peak_candidate_entries_per_context']=max(cache_stats['peak_candidate_entries_per_context'],sum(len(known) for known in cache))
    return result
RadialRoads.query=query
original=LabExperiment.step

def step(run):
    global measured
    measured=True
    profile.enable()
    try:return original(run)
    finally:
        profile.disable()
        measured=False

LabExperiment.step=step
try:
    compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    LabExperiment.step=original
    RadialRoads.query=original_query
(output/"cache-stats.json").write_text(json.dumps(dict(cache_stats),indent=2)+"\n",encoding="utf-8")
profile.dump_stats(str(output/'step.prof'))
with (output/'profile.txt').open('w',encoding='utf-8') as stream:
    stats=pstats.Stats(profile,stream=stream)
    stats.sort_stats('cumulative').print_stats(55)
    stats.sort_stats('tottime').print_stats(35)
rows=[{'file':path,'line':line,'function':function,'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for (path,line,function),v in stats.stats.items()]
(output/'profile.json').write_text(json.dumps({'ticks':144,'total_seconds':stats.total_tt,'functions':rows,'scope':'完整非线性实体凸起的独立诊断；分析器耗时不进入速度收益表'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-14/final-AB/nonlinear-B/payload.bin').read_bytes()
print('bump profile physics payload exact')
