import dataclasses
import importlib.util
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'logs/lab-perf-22')]
import vehicle_unsprung as vehicle
from compare_results import compare
from damper_bench_reference import document as bench_document
from lab_experiment import LabExperiment,LabOptions
from lab_solver_validation import model_for,verify_result
from suspension_bench import fit_bench
from vehicle_designs import vehicle_design
from vehicle_parameters import config_from_document

output=root/'logs/lab-perf-22/stress';output.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('stress_baseline',root/'builds/lab-perf-22/baseline/src/unsprung_joint.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
old.UnsprungJointStep=vehicle.solve_unsprung_joint.__globals__['UnsprungJointStep']
def old_solve(*args,**kwargs):
    kwargs.pop('jacobian_hint')
    return old.solve_unsprung_joint(*args,**kwargs)
original=vehicle.solve_unsprung_joint
document=json.loads((root/'docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json').read_text(encoding='utf-8'))
config=config_from_document(document,vehicle_design('reference-rwd').config)
cases=(('braking-4s',LabOptions(duration=4.)),
       ('ride-braking-2.4s',LabOptions(maneuver='ride_braking',speed_kph=18.,duration=2.4,bump_distance_m=2.,bump_length_m=.4)))
summary=[]
for name,options in cases:
    scenario_config=config
    if name.startswith('ride'):scenario_config,_report=fit_bench(bench_document(),config)
    payloads=[];results=[]
    for label,solver in (('A',old_solve),('B',original)):
        joint=[];checks=[];measured=False
        def solve(*args,**kwargs):
            model=model_for(args,kwargs) if measured else None
            result=solver(*args,**kwargs)
            if measured:
                checks.append(verify_result(model,result))
                joint.append({field.name:getattr(result,field.name) for field in dataclasses.fields(result) if field.name!='contact_geometry'})
            return result
        vehicle.solve_unsprung_joint=solve
        before=time.perf_counter()
        run=LabExperiment(options,config=scenario_config)
        initialized=time.perf_counter()-before
        try:
            measured=True
            while not run.done:run.step()
            elapsed=time.perf_counter()-before-initialized
            snapshots=[dataclasses.replace(s,contact_epoch=0,impacts=tuple(dataclasses.replace(e,epoch=0) for e in s.impacts)) for s in run.snapshots]
            payload={'snapshots':snapshots,'samples':run.samples,'commands':run.commands,'joint':joint}
            binary=pickle.dumps(payload,protocol=5);(output/(name+'-'+label+'.bin')).write_bytes(binary)
            results.append({'label':label,'substeps':len(joint),'ticks':len(snapshots)-1,'reason':run.reason,
                            'config':dataclasses.asdict(run.config),'options':dataclasses.asdict(options),
                            'quality_max':{key:max(row[key] for row in checks) for key in checks[0]},
                            'independent_all_substeps_checked':True,'diagnostic_wall_seconds':elapsed,'initialization_seconds':initialized})
            payloads.append(payload)
            print(name,label,'OK',len(joint),'substeps',results[-1]['quality_max'],flush=True)
        finally:run.close();vehicle.solve_unsprung_joint=original
    difference=compare(*payloads)
    # 模式变化保留在证据中；原始方程/输入和误差复算独立通过。
    summary.append({'case':name,'runs':results,'difference':difference,'commands_equal':payloads[0]['commands']==payloads[1]['commands']})
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('longer actual-world paired cases completed; all substeps independently checked')
