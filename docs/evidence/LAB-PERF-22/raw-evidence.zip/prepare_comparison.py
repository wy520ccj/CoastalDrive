from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-21/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-21','lab-perf-22')
source=source.replace("root/'logs/lab-perf-20/base-interleaved'/scenario/'B1.bin'","root/'logs/lab-perf-21/base-interleaved'/scenario/'B1.bin'")
source=source.replace('old_solve=old_geometry.solve_unsprung_joint', '''def old_solve(*args,**kwargs):
    kwargs.pop('jacobian_hint')
    return old_geometry.solve_unsprung_joint(*args,**kwargs)''',1)
marker='all_groups=[]'
source=source.replace(marker,'''# 旧求解器经当前调用代码运行，额外种子参数移除，实际支持源码路径明确单列。
source_hashes['A']=dict(source_hashes['B'])
source_hashes['A']['unsprung_joint.py']=hashlib.sha256((baseline/'unsprung_joint.py').read_bytes()).hexdigest()
for label in ('A','B'):
    for name in native[label]:
        actual=Path(sys.modules[name].__file__).resolve()
        if label=='A' and name=='wheel_contact_kernels':actual=old_path.resolve()
        native[label][name]={'path':str(actual),'sha256':hashlib.sha256(actual.read_bytes()).hexdigest()}
'''+marker,1)
source=source.replace("'rows':rows,'repeat_exact_within_method':True", "'rows':rows,'repeat_exact_within_method':True,'support_source_root':str(root/'src'),'old_solver_source':str(baseline/'unsprung_joint.py')")
(root/'logs/lab-perf-22/interleaved.py').write_text(source,encoding='utf-8')
for name in ('energy_refinement.py','stress.py'):
    path=root/'logs/lab-perf-22'/name
    text=path.read_text(encoding='utf-8')
    marker='original=vehicle.solve_unsprung_joint'
    assert marker in text
    text=text.replace(marker,'''def old_solve(*args,**kwargs):
    kwargs.pop('jacobian_hint')
    return old.solve_unsprung_joint(*args,**kwargs)
'''+marker,1)
    text=text.replace("('A',old.solve_unsprung_joint)","('A',old_solve)")
    path.write_text(text,encoding='utf-8')
print('comparison records actual shared source and native paths; baseline solver adapter only removes algorithm hint')
