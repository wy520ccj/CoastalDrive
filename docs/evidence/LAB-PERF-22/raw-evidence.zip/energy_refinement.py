import importlib.util
import json
import sys
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/physics')]
import lab_energy_check as energy
import vehicle_unsprung as vehicle
from lab_runtime import runtime_fingerprint

baseline=root/'builds/lab-perf-22/baseline/src'
spec=importlib.util.spec_from_file_location('energy_baseline',baseline/'unsprung_joint.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
def old_solve(*args,**kwargs):
    kwargs.pop('jacobian_hint')
    return old.solve_unsprung_joint(*args,**kwargs)
original=vehicle.solve_unsprung_joint
output=root/'logs/lab-perf-22/energy-refinement';output.mkdir(exist_ok=False)
rows=[]
try:
    for count in (2,4,8):
        for label,solver in (('A',old_solve),('B',original)):
            vehicle.solve_unsprung_joint=solver
            folder=output/f'{count}-{label}'
            energy.check(folder,'manual',.12,count,root/'docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json')
            result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
            rows.append({'substeps':count,'label':label,'max_abs':result['max_abs'],'sum':result['sum'],'runtime':result['runtime']})
            (output/'summary.json').write_text(json.dumps({'rows':rows,'scope':'相同完整工程输入实际世界能量2/4/8细化；不等于原能量Gate通过','runtime':runtime_fingerprint()},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
finally:vehicle.solve_unsprung_joint=original
print('paired actual-world energy refinement completed')
