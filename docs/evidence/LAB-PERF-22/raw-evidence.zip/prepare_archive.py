from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-21/archive_report.py').read_text(encoding='utf-8').replace('lab-perf-21','lab-perf-22').replace('LAB-PERF-21','LAB-PERF-22')
source=source.replace("assert changes==['unsprung_joint.py']","assert changes==['unsprung_joint.py','vehicle_unsprung.py']")
start=source.index('old_tree,new_tree=')
end=source.index('groups=read(',start)
prefix='''old_tree,new_tree=ast.parse(old),ast.parse(new)
model=ast.parse((root/'tests/lab_solver_model_reference.py').read_text(encoding='utf-8'))
for name in ('evaluate','configuration','velocity_terms'):
    nodes=[next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name) for tree in (old_tree,new_tree,model)]
    assert ast.dump(nodes[0])==ast.dump(nodes[1])==ast.dump(nodes[2]),name
loops=[next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='iteration') for tree in (old_tree,new_tree)]
assert ast.dump(loops[0])==ast.dump(loops[1])
assert old[old.rindex('    end,forces,torques = values[:16]'):]==new[new.rindex('    end,forces,torques = values[:16]'):]
import copy
vehicle_trees=[ast.parse((folder/'vehicle_unsprung.py').read_text(encoding='utf-8')) for folder in (baseline,root/'src')]
for name in ('body_partition','read_mechanics','powertrain_result','wheel_contacts','publish_tires','observe_unsprung'):
    nodes=[next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name) for tree in vehicle_trees]
    assert ast.dump(nodes[0])==ast.dump(nodes[1]),name
def is_cache_assignment(node):
    return isinstance(node,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=='_unsprung_jacobian' for t in node.targets)
for name in ('install_guides','initialize_rolling','commit'):
    a,b=[copy.deepcopy(next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)) for tree in vehicle_trees]
    assert sum(is_cache_assignment(n) for n in b.body)==1
    b.body=[n for n in b.body if not is_cache_assignment(n) and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='hint' for t in n.targets))]
    assert ast.dump(a)==ast.dump(b),name
a,b=[copy.deepcopy(next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='read')) for tree in vehicle_trees]
b.body=[n for n in b.body if not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('prior','key','seed') for t in n.targets))]
returned=next(n for n in b.body if isinstance(n,ast.Return))
hint=returned.value.args.pop()
assert isinstance(hint,ast.Call) and hint.func.id=='JointJacobianHint'
assert ast.dump(a)==ast.dump(b)
a,b=[copy.deepcopy(next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='solve')) for tree in vehicle_trees]
returned=next(n for n in b.body if isinstance(n,ast.Return))
returned.value.keywords=[n for n in returned.value.keywords if n.arg!='jacobian_hint']
assert ast.dump(a)==ast.dump(b)
'''
source=source[:start]+prefix+source[end:]
source=source.replace("root/'logs/lab-perf-20/base-interleaved'","root/'logs/lab-perf-21/base-interleaved'")
source=source.replace("        assert row['source_hashes']=={p.name:sha(p) for p in source.iterdir() if p.suffix in suffixes}",'''        actual={p.name:sha(p) for p in (root/'src').iterdir() if p.suffix in suffixes}
        if label=='A':actual['unsprung_joint.py']=sha(baseline/'unsprung_joint.py')
        assert row['source_hashes']==actual''')
source=source.replace("            assert Path(data['path']).parent==source.resolve() and sha(Path(data['path']))==data['sha256']",'''            actual_parent=baseline if label=='A' and name=='wheel_contact_kernels' else root/'src'
            assert Path(data['path']).parent==actual_parent.resolve() and sha(Path(data['path']))==data['sha256']''')
source=source.replace("{'T0':155,'T0-standard':155,'lab-regression':759}","{'T0':117,'T0-standard':117,'lab-regression':771}")
source=source.replace("==44","==45")
source=source.replace("assert profile['counts']['jacobian']>=288 and profile['counts']['polish']==288\nassert profile['counts']['residual']<21742", "assert profile['counts']=={'residual':3486,'jacobian':8,'update':1311,'polish':288,'export_seed':288,'warm_seed':287}")
source=source.replace("root/'logs/lab-perf-20/profile-bump/", "root/'logs/lab-perf-21/profile-bump/")
source=source.replace("root/'logs/lab-perf-20/profile-bump'", "root/'logs/lab-perf-21/profile-bump'")
source=source.replace('assert old_iterations==791','assert old_iterations==792')
source=source.replace("'baseline':'b85bf10'","'baseline':'75ca5e5'")
source=source.replace("'full_suite_note':'759项完整专项覆盖最终全部用例；普通/Double T0各155项'", "'full_suite_note':'771项完整专项覆盖最终全部用例；普通/Double T0各117项'" )
source=source.replace("'src/unsprung_joint.py','tests/test_lab_solver_update.py'", "'src/unsprung_joint.py','src/vehicle_unsprung.py','tools/physics/unsprung_step_checkpoint.py','tests/test_lab_jacobian_hint.py','tests/test_lab_solver_update.py'")
(root/'logs/lab-perf-22/archive_report.py').write_text(source,encoding='utf-8')
print('archive assertions adapted for actual shared bridge and private numerical seed; not executed yet')
