import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd();build=root/'builds/lab-perf-22';build.mkdir(exist_ok=False)
subprocess.run(['git','archive','--format=zip','--output',str(build/'baseline.zip'),'HEAD','src','assets/game/vehicle-configs'],check=True)
with zipfile.ZipFile(build/'baseline.zip') as archive:archive.extractall(build/'baseline')
native={}
for path in (root/'src').glob('*.pyd'):
    raw=path.read_bytes();(build/'baseline/src'/path.name).write_bytes(raw);native[path.name]=hashlib.sha256(raw).hexdigest()
assert len(native)==5
(root/'logs/lab-perf-22/native-copies.json').write_text(json.dumps(native,indent=2)+'\n',encoding='utf-8')
for name in ('compare_results.py','quality_worker.py','profile_worker.py','stress.py','energy_refinement.py','lab_regression.py'):
    text=(root/'logs/lab-perf-21'/name).read_text(encoding='utf-8-sig').replace('lab-perf-21','lab-perf-22')
    (root/'logs/lab-perf-22'/name).write_text(text,encoding='utf-8')
print('75ca5e5 source and actual five native modules frozen')
