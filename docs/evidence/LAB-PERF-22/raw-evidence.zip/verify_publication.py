import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-22'
summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'))
archive_path=folder/'raw-evidence.zip'
assert hashlib.sha256(archive_path.read_bytes()).hexdigest()==summary['raw_evidence_sha256']
for group in summary['groups']:
    row=next(r for r in group['rows'] if r['label']=='B1')
    for name,digest in row['source_hashes'].items():assert hashlib.sha256((root/'src'/name).read_bytes()).hexdigest()==digest,name
    for name,data in row['native'].items():assert hashlib.sha256(Path(data['path']).read_bytes()).hexdigest()==data['sha256'],name
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name in ('src/unsprung_joint.py','src/vehicle_unsprung.py','tools/physics/unsprung_step_checkpoint.py',
                 'tests/test_lab_jacobian_hint.py','tests/test_lab_solver_update.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py',
                 'tests/test_lab_joint_reuse.py','tests/test_lab_newton_base.py','tests/test_unsprung_joint.py'):
        assert archive.read('executed-source/'+name)==(root/name).read_bytes(),name
    for name,data in summary['native']['B'].items():
        path=Path(data['path'])
        assert archive.read('executed-native/shared/'+path.name)==path.read_bytes(),name
assert summary['source_changes']==['unsprung_joint.py','vehicle_unsprung.py'] and summary['native_unchanged']
print('archive integrity/SHA; measured production, final tests/checkpoint tool and five native binaries exact')
