import json
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-22'
data=json.loads((folder/'summary.json').read_text(encoding='utf-8'));groups=data['groups']
metrics='/'.join(f"{g['wall_seconds_reduction_percent']:.2f}" for g in groups)
energy_delta=max(abs(r['sum_delta_J']) for r in data['energy_refinement'])
lines=['# 试验台相邻子步Jacobian数值种子','',
'2026-10-16，基线75ca5e5，主目录main，仅独立轮心试验台；持续目标active。','',
'## 实现与物理边界','',
'上一块完整凸起288个子步仍各构造一次34列方向矩阵，共9792次额外扰动。先用独立实验函数将上一子步的方向矩阵带入当前缩放，三个完整工况均通过冻结原方程/能量复算，凸起只需8次重建。该实验只有单个世界，计时含验证，不用作正式速度收益。','',
'正式实现JointJacobianHint：previous是本次原始输入矩阵，current是本次成功求解的独立输出。矩阵以未缩放物理坐标保存，进入当前共同解时按state_scale/row_scale换算；不带入旧轮荷、材料、接触点、残差或车辆状态。矩阵只给搜索方向，原完整残差/精确有限端口行决定当前候选是否下降，旧方向失效时仍重建当前差分。','',
'每个车辆独有一个数值种子。创建导向、重置和initialize_rolling清空；配置对象、dt、传动比或同步状态变化时不带入。新的UnsprungAdvanceInput持有独立hint；合格求解后由commit路径发布current供下一子步使用，不修改previous。输入矩阵不被求解器改写，输出矩阵只读且存储独立。没有跨车辆/世界共享方向矩阵。','',
'可信单步检查点保存previous，清除派生current。输入和输出分开，加载后重复求解使用原输入种子；旧检查点缺少新增可选字段时由原数据类默认None维持冷启动。未把UI/场景/快照当作物理或算法状态来源。','',
'jacobian_updates=False继续原完整中央差分Newton，不使用种子。默认的34维方程、每轮精确有限端口行、当前真实几何、Broyden更新/重建、原30轮/12线搜索、合格校正及动量<1e−9 Ns/力<1e−5 N/端口<1e−9 Nm门槛保持。Newton循环AST完全相同，原evaluate/configuration/velocity_terms和最终能量段保持；本块只在循环前换算种子、循环后导出矩阵。','',
'生产修改为unsprung_joint.py和vehicle_unsprung.py及可信单步工具；五扩展和隔离Panda1.10.16/Bullet285 Double SDK不变。调用代码的力学读取/端口/提交/观测/初始化数学段经AST核对未变。普通游戏源码和配置未改。','',
'## 同批完整步实测','',
'三个原工况各四独立世界，逐拍ABBA/逆序正常前进；C轴向缓存/Python曲率缓存/单车Jacobian种子均独立。绑定切换/序列化在计时外，初始化单列。旧求解器由75ca5e5原文加载，通过当前调用代码运行，仅移除新算法hint参数；旧调用从不生成或发布种子。A的全部payload与上一块正式B文件逐字节相同。','',
'实际来源记录区分共享的当前调用代码与旧求解器路径；A源码SHA使用当前支持模块+冻结unsprung_joint.py，B全部来自当前src。原生扩展也记录实际加载路径：A私有wheel来自冻结目录，其余实际共享扩展来自当前src，五个SHA相同。没有把整个旧目录错误标为当前执行来源。','',
'| 工况 | 旧墙钟s | 新墙钟s | 耗时减少 | 旧CPU s | 新CPU s | CPU减少 |',
'|---|---:|---:|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['wall_seconds']:.6f} | {b['wall_seconds']:.6f} | {g['wall_seconds_reduction_percent']:.2f}% | {a['cpu_seconds']:.6f} | {b['cpu_seconds']:.6f} | {g['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','| 工况 | 旧P95 ms | 新P95 ms | 旧P99 ms | 新P99 ms |','|---|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['step_p95_seconds']*1000:.3f} | {b['step_p95_seconds']*1000:.3f} | {a['step_p99_seconds']*1000:.3f} | {b['step_p99_seconds']*1000:.3f} |")
lines+=['','CPU逐拍统计有Windows量化，不从短测CPU与墙钟差值推断等待；整步墙钟、物理/快照时间与尾延迟共同支持本批收益。机器绝对速度有波动，不跨历史批次相乘。实体凸起1.2模拟秒仍需2.054墙钟秒，尚未实时。','',
'| 工况 | A1初始化s | B1初始化s | B2初始化s | A2初始化s | 初始化拍数 |','|---|---:|---:|---:|---:|---:|']
for g in groups:
    initial=[r['initialization'] for r in g['rows']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{r['wall_seconds']:.3f}" for r in initial)+f" | {initial[0]['ticks']} |")
lines+=['','制动100km/h/.2s/24拍，首计算拍brake=1；转向30km/h/2°/.4s/48拍/onset=0；凸起18km/h/1.2s/144拍、2m位置/.4m长度、完整预载/安装曲线/非线性阻尼。合成部件台架拟合只用于一致性对照，不代表实车标定。','',
'12次864拍/1728子步，A两次精确重复且等于上一块正式B结果，B两次也精确重复。命令、全部离散物理状态一致，只有求解迭代数变化；全部连续差保存，不删除字段以获得相同结论。仅归一实例epoch，排除含原生节点的contact_geometry引用，实际接触仍在快照。','',
'| 工况 | 位置最大差m | 共同速度最大差 | 接触力最大差N |','|---|---:|---:|---:|']
for g in groups:
    d=g['difference']['numeric_max_abs_deltas']
    lines.append(f"| {g['scenario']} | {d['payload.snapshots[].player.position[]']:.3e} | {d['payload.joint[].velocity']:.3e} | {d['payload.joint[].forces']:.3e} |")
lines+=['','## 独立方程、能量与较长工况','',
'默认方法的三个工况432个实际新子步，在原始输入上用冻结原模型和独立几何/运动缓存重新计算完整34残差，再由原能量结果段重算账本；算法hint显式从独立物理模型参数中移除，不能影响验收方程。全部原门槛通过，能量账复算差为0，验证运行的payload与速度B文件逐字节一致。','',
'| 工况 | 旧/新峰值动量残差Ns | 旧/新峰值力残差N | 旧/新峰值能量误差J |','|---|---:|---:|---:|']
for g in groups:
    e=data['peak_residuals'][g['scenario']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{e[k]['A']:.3e} / {e[k]['B']:.3e}" for k in ('momentum_error','force_error','energy_error'))+' |')
lines+=['','部分峰值残差比冷启动更大，但仍满足原门槛；没有因此扩大容差。矩阵种子是数值近似，最终物理状态始终由同一原方程验收，不宣称新旧数值逐字节相同。','',
'| 请求较长工况 | 旧/新实际拍数 | 旧/新子步数 | 结束原因 | 新峰值动量Ns | 新峰值力N |','|---|---:|---:|---|---:|---:|']
for case in data['stress']:
    a,b=case['runs']
    lines.append(f"| {case['case']} | {a['ticks']} / {b['ticks']} | {a['substeps']} / {b['substeps']} | {b['reason']} | {b['quality_max']['momentum_error']:.3e} | {b['quality_max']['force_error']:.3e} |")
stress_steps=sum(r['substeps'] for case in data['stress'] for r in case['runs'])
lines+=['',f'较长工况在相同拍停车，命令和离散物理状态一致；旧/新共{stress_steps}子步独立验证原方程与能量账，全部通过，能量复算差0；实际共同解能量误差也均低于原3e−8J专项门槛。诊断时间含逐步验证，不作收益。','',
'相同完整工程输入、手动转向/油门/制动/离合，.12秒实际世界2/4/8子步能量细化：','',
'| 子步配置 | 旧累计能量残差J | 新累计能量残差J | 差J |','|---|---:|---:|---:|']
for r in data['energy_refinement']:
    lines.append(f"| {r['substeps']} | {r['old_sum_J']:.12f} | {r['new_sum_J']:.12f} | {r['sum_delta_J']:.3e} |")
lines+=['',f'六次共420个实际世界子步，累计能量差最大{energy_delta:.3e}J，保留原细化下降趋势。原真实世界完整能量/速度网格收敛Gate仍开放，不因这些限定工况回填原阶段通过。','',
'## 验证、工作量与来源','',
'新增12项：无/零/单位/负单位种子，跨质量/相邻速度的未缩放重用，配置/dt/传动比/同步变化失效，暖输入可信检查点重复复算，两个实际车辆隔离及初始化/重置清空，以及.6秒实际独立轮心Box记录导出/载入/重算全部快照/信号/命令精确相同。零/坏方向仍必须重建或经原残差达标，种子输入字节不变，输出只读独立。','',
'原相关105项通过，新增11项先检通过，补上实际记录与重置后的最终12项通过；初次Ruff仅导入格式失败，已修复且原日志保留，无物理数值失败。最终普通/Double T0各117项、Double45模块771项完整试验台专项/Ruff、真实记录与旧检查点复算通过。','',
'完整凸起带入种子287次/导出288次，矩阵重建288→8、差分扰动9792→272、残差11952→3486；割线更新792→1311，合格校正288保持。更多廉价迭代换取少量昂贵几何差分，仍逐次计算当前完整物理残差。','',
'完整新剖析计数源码profiled_solver.py归档，payload与速度B相同，分析器时间不进入收益表；旧剖析复用LAB-PERF-21并核对源码LF/CRLF及五扩展SHA。没有重复六拍或旧完整剖析。','',
'summary与raw-evidence.zip保存先验单世界实验、正式12份payload/全部差、432子步原方程检查、较长工况与实际世界能量细化、共享五扩展、旧新源码/可信检查点工具/独立模型/全部测试与日志。旧求解器/当前调用代码实际路径和SHA分别记录；旧目录仅是受控参照，不是产品入口。','',
'复现：项目Python tools/physics/run_sim_double.py logs/lab-perf-22/interleaved.py，须新输出目录与75ca5e5冻结src/五扩展；quality_worker.py、energy_refinement.py、stress.py分别复现原方程/细化/较长工况，lab_regression.py跑专项。','',
'本块仅本地提交，持续目标active。游戏seed/window及通用T1/T2/T3未跑；完整物理/精度、原能量、人工体验、实时及EPA部分旋转网格边缘拒绝仍开放。下一根据新完整剖析减少每子步固定读取/装配和重复接触计算，仍以完整步与原方程验证。','']
(folder/'README.md').write_text('\n'.join(lines),encoding='utf-8')
(root/'docs/tasks/LAB-PERF-22.md').write_text(f'''# LAB-PERF-22 相邻子步Jacobian搜索信息

- 状态：done（本功能块）；基线75ca5e5，main，本地提交；持续目标active。
- 单车未缩放Jacobian只给当前数值方向，原完整残差/精确端口行/Broyden重建与校正/收敛门槛不变；循环AST/能量尾段保持，完整物理/120Hz/双子步/34未知数/30轮/12线搜索和参数保持。
- 配置/dt/传动比/同步变化不带入；初始化/重置清空，输入previous/输出current独立，合格求解后在commit路径发布，可信检查点保留原输入、清掉派生输出。全Newton参照不使用种子。
- 三工况四独立世界逐拍完整步−{metrics}%，P95/P99均下降；1728性能子步，方法各自精确重放、原命令/离散状态一致，连续差保留；旧求解器与共享当前调用代码实际来源分开核对。
- 432实际新子步原方程/能量复算，较长停车{stress_steps}子步及实际世界2/4/8细化420子步通过，累计能量差最大{energy_delta:.3e}J；部分残差升高但原门槛不变，原完整精度/能量Gate开放。
- 新增12项种子/失效/隔离/重置/检查点与.6秒实际记录复算；普通/Double T0各117项、Double45模块771项专项/Ruff/旧检查点通过，初次仅Ruff导入格式失败保留。
- 完整凸起种子287次、导出288次，矩阵重建288→8，差分9792→272、残差11952→3486，更新1311/校正288。五扩展及Double SDK未改；游戏源码/配置未改。
- [完整证据](../evidence/LAB-PERF-22/README.md)、summary.json、raw-evidence.zip含参数/CPU/墙钟/尾延迟/初始化/路径与SHA/全部差异/复现脚本。
- 仍慢于实时，游戏seed/window及通用T1/T2/T3未跑，原人工/实时/完整精度/EPA Gate继续开放。下一每子步固定读取/装配与真实接触成本，不结束目标。
''',encoding='utf-8')
path=root/'docs/current-progress.md';text=path.read_text(encoding='utf-8')
start=text.index('当前施工仅试验台：');end=text.index('\n',start)
text=text[:start]+f'当前施工仅试验台：最新完成[LAB-PERF-22](tasks/LAB-PERF-22.md)单车Jacobian数值种子，三工况完整步再减{metrics}%；不复用旧物理状态，原完整残差/门槛与模型保持。配置/步长/传动/初始化失效、暖输入检查点与实际记录复算通过，771项专项通过。持续目标active，仍慢于实时，下一固定读取/装配与真实接触成本。下列历史节点只支持各自版本/协议，最新收益以本块同批对照为准。'+text[end:]
text+=f'\n- [LAB-PERF-22 单车Jacobian数值种子](tasks/LAB-PERF-22.md)：75ca5e5基线，单车未缩放矩阵只给当前方向，初始化/参数/dt/传动改变失效，输入输出独立保存复算。三工况完整步−{metrics}%，1728性能子步各自精确重复、事件命令一致；432实际新子步原方程、较长停车{stress_steps}子步和实际世界420子步细化通过。新增12项，普通/Double T0各117项、Double45模块771项/实际记录复算通过；矩阵288→8，残差11952→3486，原完整物理/门槛保持，五扩展未改。本地提交，持续目标active，原精度/人工/实时/EPA Gate开放。\n'
path.write_text(text,encoding='utf-8')
print('report/task/progress written from verified measurements')
