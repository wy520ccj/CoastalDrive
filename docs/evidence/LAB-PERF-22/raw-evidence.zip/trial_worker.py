import inspect
import json
import sys
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'tools/performance')]
import unsprung_joint as joint
import vehicle_unsprung as vehicle
import compare_lab_compute
from lab_experiment import LabExperiment
from lab_solver_validation import model_for,verify_result

scenario=sys.argv[1];original=vehicle.solve_unsprung_joint;original_step=LabExperiment.step
source=inspect.getsource(original)
source=source.replace('    jacobian = None\n    for iteration',
    '    jacobian = _warm.previous*state_scale[None,:]/row_scale[:,None] if _warm.previous is not None else None\n    for iteration',1)
marker='    end,forces,torques = values[:16]'
position=source.rindex(marker)
source=source[:position]+'    _warm.previous = None if jacobian is None else jacobian*row_scale[:,None]/state_scale[None,:]\n'+source[position:]
source=source.replace('            columns = []','            _record("jacobian")\n            columns = []',1)
source=source.replace('        end,forces,torques = values[:16]','        _record("residual")\n        end,forces,torques = values[:16]',1)
path=root/'logs/lab-perf-22/trial_solver.py';path.write_text(source,encoding='utf-8')
counts={};warm=SimpleNamespace(previous=None);measured=False;checks=[]
def record(name):
    if measured:counts[name]=counts.get(name,0)+1
namespace=dict(vars(joint));namespace.update(_warm=warm,_record=record)
exec(compile(source,str(path),'exec'),namespace)
trial=namespace['solve_unsprung_joint']
def solve(*args,**kwargs):
    model=model_for(args,kwargs) if measured else None
    result=trial(*args,**kwargs)
    if measured:checks.append(verify_result(model,result))
    return result
def step(run):
    global measured
    measured=True
    return original_step(run)
vehicle.solve_unsprung_joint=solve;LabExperiment.step=step
output=root/'logs/lab-perf-22/trial'/scenario
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=output))
finally:vehicle.solve_unsprung_joint=original;LabExperiment.step=original_step
assert len(checks)=={'braking':48,'turning':96,'nonlinear-bump':288}[scenario]
(output/'quality.json').write_text(json.dumps({'counts':counts,'maxima':{key:max(row[key] for row in checks) for key in checks[0]},'substeps':len(checks)},indent=2)+'\n',encoding='utf-8')
print(counts,flush=True)
