import json
import sys
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'tools/performance')]
import compare_lab_compute
import vehicle_unsprung as vehicle
from lab_solver_validation import model_for,verify_result
from lab_experiment import LabExperiment

scenario=sys.argv[1];original=vehicle.solve_unsprung_joint;original_step=LabExperiment.step
measured=False;checks=[]
def solve(*args,**kwargs):
    model=model_for(args,kwargs) if measured else None
    result=original(*args,**kwargs)
    if measured:checks.append(verify_result(model,result))
    return result
def step(run):
    global measured
    measured=True
    try:return original_step(run)
    finally:measured=False
vehicle.solve_unsprung_joint=solve;LabExperiment.step=step
output=root/'logs/lab-perf-22/independent-model'/scenario
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=output))
finally:vehicle.solve_unsprung_joint=original;LabExperiment.step=original_step
assert len(checks)=={'braking':48,'turning':96,'nonlinear-bump':288}[scenario]
expected=(root/'logs/lab-perf-22/base-interleaved'/scenario/'B1.bin').read_bytes()
assert (output/'payload.bin').read_bytes()==expected
(output/'quality.json').write_text(json.dumps({'scenario':scenario,'substeps':len(checks),'maxima':{
    name:max(row[name] for row in checks) for name in checks[0]},'all_checks':checks,
    'scope':'每个实际新子步输入，用冻结原方程、独立缓存和原能量结果段复算；全部原门槛，不作计时收益'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('all substeps independently satisfy original residual and energy equations; complete payload unchanged')
