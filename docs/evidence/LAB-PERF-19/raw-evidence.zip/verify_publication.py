import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-19'
summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'))
archive_path=folder/'raw-evidence.zip'
assert hashlib.sha256(archive_path.read_bytes()).hexdigest()==summary['raw_evidence_sha256']
for group in summary['groups']:
    row=next(r for r in group['rows'] if r['label']=='B1')
    for name,digest in row['source_hashes'].items():assert hashlib.sha256((root/'src'/name).read_bytes()).hexdigest()==digest,name
    for name,data in row['native'].items():assert hashlib.sha256(Path(data['path']).read_bytes()).hexdigest()==data['sha256'],name
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name in ('src/unsprung_joint.py','tests/test_lab_newton_base.py','tests/lab_newton_base_reference.py'):
        assert archive.read('executed-source/'+name)==(root/name).read_bytes(),name
    for name,data in summary['native']['B'].items():
        path=Path(data['path'])
        assert archive.read('executed-native/shared/'+path.name)==path.read_bytes(),name
assert summary['changes']==['unsprung_joint.py'] and summary['native_binaries_unchanged']
build_cache=json.loads((root/'logs/lab-perf-19/build-cache-restored.json').read_text(encoding='utf-8'))
assert hashlib.sha256(Path(build_cache['build_cache']).read_bytes()).hexdigest()==build_cache['after_sha256']
assert hashlib.sha256(Path(build_cache['production']).read_bytes()).hexdigest()==build_cache['after_sha256']
print('archive integrity/SHA; tested production source/tests and five unchanged native modules exact')
