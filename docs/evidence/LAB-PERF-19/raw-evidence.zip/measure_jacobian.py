import inspect
import json
import sys
import textwrap
import time
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import unsprung_joint as joint
import vehicle_unsprung as vehicle
import compare_lab_compute
from lab_experiment import LabExperiment

measured=False;counts=[0]*34;elapsed=[0.]*34
def record(column,seconds):
    if measured:counts[column]+=1;elapsed[column]+=seconds
original=joint.solve_unsprung_joint
source=textwrap.dedent(inspect.getsource(original))
line=next(line for line in source.splitlines() if 'columns.append((evaluate(plus)' in line)
assert line.lstrip().startswith('columns.append((evaluate(plus)[0]-evaluate(minus)[0])')
indent=line[:len(line)-len(line.lstrip())]
source=source.replace(line,indent+'_started = _clock()\n'+line+'\n'+indent+'_record(i,_clock()-_started)',1)
path=root/'logs/lab-perf-19/diagnostic_joint.py';path.write_text(source,encoding='utf-8')
namespace=vars(joint);namespace.update(_clock=time.perf_counter,_record=record)
exec(compile(source,str(path),'exec'),namespace)
vehicle.solve_unsprung_joint=joint.solve_unsprung_joint
original_step=LabExperiment.step
def step(run):
    global measured
    measured=True
    try:return original_step(run)
    finally:measured=False
LabExperiment.step=step
output=root/'logs/lab-perf-19/jacobian-diagnosis'
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    joint.solve_unsprung_joint=original;vehicle.solve_unsprung_joint=original;LabExperiment.step=original_step
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-18/interleaved/nonlinear-bump/A1.bin').read_bytes()
assert len(set(counts))==1 and counts[0]>0
groups={name:{'columns':list(range(start,stop)),'pairs':sum(counts[start:stop]),'wall_seconds':sum(elapsed[start:stop])}
        for name,start,stop in (('body_velocity',0,6),('wheel_guides',6,10),('engine_shaft',10,12),
                               ('wheel_spin',12,16),('tire_forces',16,24),('port_torques',24,34))}
result={'counts':counts,'column_seconds':elapsed,'groups':groups,'payload_exact':True,
        'scope':'原34列中央差分逐列计时；原表达式完全不改，初始化排除，不作速度收益'}
(output/'columns.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(groups)
