import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd();build=root/'builds/lab-perf-19'
build.mkdir(exist_ok=False)
subprocess.run(['git','archive','--format=zip','--output',str(build/'baseline.zip'),'HEAD','src','assets/game/vehicle-configs'],check=True)
with zipfile.ZipFile(build/'baseline.zip') as archive:archive.extractall(build/'baseline')
native={}
for path in (root/'src').glob('*.pyd'):
    raw=path.read_bytes();(build/'baseline/src'/path.name).write_bytes(raw)
    native[path.name]=hashlib.sha256(raw).hexdigest()
assert len(native)==5
(root/'logs/lab-perf-19/native-copies.json').write_text(json.dumps(native,indent=2)+'\n',encoding='utf-8')
for name in ('frozen_ab.py','lab_regression.py','profile_bump.py'):
    text=(root/'logs/lab-perf-18'/name).read_text(encoding='utf-8').replace('lab-perf-18','lab-perf-19')
    (root/'logs/lab-perf-19'/name).write_text(text,encoding='utf-8')
(root/'tests/lab_road_assembly_reference.py').write_bytes((build/'baseline/src/radial_geometry.py').read_bytes())
print('7075998 actual source and five native modules frozen')
