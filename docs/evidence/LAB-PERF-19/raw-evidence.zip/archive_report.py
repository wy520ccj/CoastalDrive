import ast
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path.insert(0,str(root/'src'))
logs=root/'logs/lab-perf-19';baseline=root/'builds/lab-perf-19/baseline/src'
output=root/'docs/evidence/LAB-PERF-19';output.mkdir(parents=True,exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
suffixes=('.py','.c','.cpp','.h')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes
               and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['unsprung_joint.py']
old=(baseline/'unsprung_joint.py').read_text(encoding='utf-8')
new=(root/'src/unsprung_joint.py').read_text(encoding='utf-8')
assert (root/'tests/lab_newton_base_reference.py').read_text(encoding='utf-8')==old
assert old.split('        columns = []',1)[1]==new.split('        columns = []',1)[1]
assert old.split('        kinematics = finite_contact.evaluate',1)[1].split('    def velocity_terms',1)[0]==new.split('        kinematics = finite_contact.evaluate',1)[1].split('    def velocity_terms',1)[0]
assert old.split('        geometry = configuration(end)',1)[1].split('    def evaluate',1)[0]==new.split('        geometry = configuration(end)',1)[1].split('    def evaluate',1)[0]
assert old.split('        force_reaction,wheel_force = force_data',1)[1].split('    config_rear = replace',1)[0]==new.split('        force_reaction,wheel_force = force_data',1)[1].split('    config_rear = replace',1)[0]
trees=[ast.parse(text) for text in (old,new)]
for name in ('UnsprungJointStep','dry_port_derivative'):
    nodes=[next(n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name) for tree in trees]
    assert ast.dump(nodes[0])==ast.dump(nodes[1])
for name in ('force_reaction','wheel_force','reaction_base','free_momentum'):
    scopes=[next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==('evaluate' if name in ('force_reaction','wheel_force') else 'velocity_terms')) for tree in trees]
    nodes=[next(n.value for n in ast.walk(scope) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)) for scope in scopes]
    assert ast.dump(nodes[0])==ast.dump(nodes[1])

stage=json.loads((logs/'stage-diagnosis/result.json').read_text(encoding='utf-8'))
stages=json.loads((logs/'stage-diagnosis/stages.json').read_text(encoding='utf-8'))
jac=json.loads((logs/'jacobian-diagnosis/columns.json').read_text(encoding='utf-8'))
jac_result=json.loads((logs/'jacobian-diagnosis/result.json').read_text(encoding='utf-8'))
assert stages['payload_exact'] and set(stages['counts'][name] for name in ('setup','keys','planes','selection_total','output_buffers','frames'))=={29260}
assert jac['payload_exact'] and set(jac['counts'])=={629}
assert jac_result['source_hashes']==stage['source_hashes']
assert (logs/'jacobian-diagnosis/payload.bin').read_bytes()==(logs/'stage-diagnosis/payload.bin').read_bytes()
jac['total_difference_seconds']=sum(jac['column_seconds'])
jac['fraction_of_complete_compute']=jac['total_difference_seconds']/jac_result['wall_seconds']
jac['central_difference_evaluations']=2*sum(jac['counts'])
assert jac['central_difference_evaluations']==42772
payload=pickle.loads((logs/'jacobian-diagnosis/payload.bin').read_bytes())
assert sum(row['iterations']-1 for row in payload['joint'])==629

groups=json.loads((logs/'base-interleaved/summary.json').read_text(encoding='utf-8'))['groups']
candidate_groups=json.loads((logs/'interleaved/summary.json').read_text(encoding='utf-8'))['groups']
assert len(groups)==len(candidate_groups)==3
native={};substeps=0
for group in groups:
    scenario=group['scenario'];folder=logs/'base-interleaved'/scenario
    expected=(root/'logs/lab-perf-18/interleaved'/scenario/'A1.bin').read_bytes()
    before=json.loads((root/'logs/lab-perf-18/interleaved'/scenario/'summary.json').read_text(encoding='utf-8'))
    assert group['options']==before['options'] and group['actual_config']==before['actual_config'] and group['requested_config']==before['requested_config']
    assert group['exact'] and len(group['rows'])==4
    assert all(row['support_cache']==group['rows'][0]['support_cache'] and row['curvature_cache']==group['rows'][0]['curvature_cache'] for row in group['rows'])
    for row in group['rows']:
        substeps+=row['substeps'];label=row['label'][0]
        assert (folder/(row['label']+'.bin')).read_bytes()==expected
        assert row['payload_sha256']==hashlib.sha256(expected).hexdigest()
        source=baseline if label=='A' else root/'src'
        assert row['source_hashes']=={p.name:sha(p) for p in source.iterdir() if p.suffix in suffixes}
        native[label]=row['native']
        for name,data in row['native'].items():
            assert Path(data['path']).parent==source.resolve() and sha(Path(data['path']))==data['sha256']
    trial=next(g for g in candidate_groups if g['scenario']==scenario)
    assert trial['exact'] and trial['actual_config']==group['actual_config'] and trial['options']==group['options']
    for row in trial['rows']:
        assert (logs/'interleaved'/scenario/(row['label']+'.bin')).read_bytes()==expected
        if row['label'].startswith('B'):
            for name,digest in row['source_hashes'].items():
                expected_hash=sha(logs/'candidate-selector'/name) if name in ('radial_geometry.py','lab_contact_native.h','wheel_contact_kernels.c') else stage['source_hashes'][name]
                assert digest==expected_hash,name
            wheel=next((logs/'candidate-selector').glob('wheel_contact_kernels*.pyd'))
            assert sha(wheel)==row['native']['wheel_contact_kernels']['sha256']
assert substeps==1728
assert {name:data['sha256'] for name,data in native['A'].items()}=={name:data['sha256'] for name,data in native['B'].items()}
assert all(sha(Path(data['path']))==stage['native'][name]['sha256'] for name,data in native['B'].items())
assert not (root/'tests/test_lab_road_assembly.py').exists() and not (root/'tests/lab_road_assembly_reference.py').exists()

frozen=json.loads((logs/'frozen-results.json').read_text(encoding='utf-8'))
assert frozen['exact'] and len(frozen['runs'][0]['cases'])==18 and frozen['runs'][0]['cases']==frozen['runs'][1]['cases']
validation={name:json.loads((logs/name/'summary.json').read_text(encoding='utf-8')) for name in ('T0','T0-standard','lab-regression')}
assert all(data['passed'] for data in validation.values())
validation_counts={}
for name in validation:
    found=re.findall(r'(\d+) passed',(logs/name/'pytest.log').read_text(encoding='utf-8'));assert len(found)==1
    validation_counts[name]=int(found[0])
assert validation_counts=={'T0':87,'T0-standard':87,'lab-regression':691}
assert len(validation['lab-regression']['tests'])==43

old_folder=root/'logs/lab-perf-18/profile-final-bump';new_folder=logs/'profile-final-bump'
old_result=json.loads((old_folder/'result.json').read_text(encoding='utf-8'))
new_result=json.loads((new_folder/'result.json').read_text(encoding='utf-8'))
assert old_result['source_hashes']==stage['source_hashes']
assert new_result['source_hashes']==groups[0]['rows'][1]['source_hashes']
assert old_result['config']==new_result['config']==groups[-1]['actual_config']
assert old_result['options']==new_result['options']==groups[-1]['options']
assert (new_folder/'payload.bin').read_bytes()==(old_folder/'payload.bin').read_bytes()==(logs/'base-interleaved/nonlinear-bump/B1.bin').read_bytes()
cache=json.loads((new_folder/'cache-counts.json').read_text(encoding='utf-8'))
assert cache['base_computation']=={'velocity':21045,'configuration':13497,'force':31109,'jacobian':629,'configuration_hit':629,'velocity_hit':629,'force_hit':629}
assert cache['geometry_cache']=={'support':{'hits':83760,'misses':11753},'curvature':{'hits':7751,'misses':7130}}
def selected(profile,name,file):return [r for r in profile['functions'] if r['function']==name and Path(r['file']).name==file]
def calls(profile,name,file):
    rows=selected(profile,name,file);assert len(rows)==1,(name,file)
    return rows[0]['calls']
profiles={label:json.loads((folder/'profile.json').read_text(encoding='utf-8')) for label,folder in (('before',old_folder),('after',new_folder))}
profile_counts={}
for label,profile in profiles.items():
    joint_file='unsprung_joint.py' if label=='before' else 'profiled_joint.py'
    row={'residuals':calls(profile,'evaluate',joint_file),'contact_evaluate':calls(profile,'evaluate','unsprung_contact_geometry.py'),
         'normal_material':calls(profile,'normal_material','unsprung_contact.py'),'configuration_calls':calls(profile,'configuration',joint_file),
         'road_queries':sum(r['calls'] for r in selected(profile,'query','radial_geometry.py') if r['line']==155),
         'surface_queries':sum(r['calls'] for r in selected(profile,'query','radial_geometry.py') if r['line']==83),
         'tire_ports':calls(profile,'tire_ports','unsprung_drivetrain.py'),'norm':calls(profile,'norm','_linalg.py'),
         'solve':calls(profile,'solve','_linalg.py')}
    for kernel in ('radial_box_bounds','box_face_candidates','box_cone_samples','box_cone_refine','finite_contact_averages','finite_contact_frames'):
        row[kernel]=sum(r['calls'] for r in profile['functions'] if 'wheel_contact_kernels.'+kernel+'>' in r['function'])
    profile_counts[label]=row
assert profile_counts['before']['residuals']==profile_counts['after']['residuals']==44318
assert profile_counts['before']['solve']==profile_counts['after']['solve']==74040
assert profile_counts['before']['surface_queries']==profile_counts['after']['surface_queries']==95513
for name in ('contact_evaluate','normal_material','configuration_calls','tire_ports','finite_contact_averages','finite_contact_frames'):
    assert profile_counts['before'][name]-profile_counts['after'][name]==629,name
assert profile_counts['before']['road_queries']-profile_counts['after']['road_queries']==1258
assert profile_counts['before']['norm']-profile_counts['after']['norm']==2516
for name in ('radial_box_bounds','box_face_candidates','box_cone_samples','box_cone_refine'):
    assert profile_counts['before'][name]==profile_counts['after'][name]

from lab_runtime import runtime_fingerprint
assert runtime_fingerprint()==validation['lab-regression']['runtime']==groups[0]['runtime']
build_cache=json.loads((logs/'build-cache-restored.json').read_text(encoding='utf-8'))
assert sha(Path(build_cache['build_cache']))==sha(Path(build_cache['production']))==build_cache['after_sha256']
with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.pyd','.h','.c') and 'user-data' not in path.parts:
            archive.write(path,path.relative_to(logs).as_posix())
    for path in old_folder.iterdir():
        if path.is_file():archive.write(path,'reused-baseline-profile/'+path.name)
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/shared/'+path.name)
    for name in ('src/unsprung_joint.py','tests/test_lab_newton_base.py','tests/lab_newton_base_reference.py','tools/performance/compare_lab_compute.py'):
        archive.write(root/name,'executed-source/'+name)
summary={'baseline':'7075998','changes':changes,'groups':groups,'substeps':1728,'rejected_candidate':candidate_groups,
         'build_cache_restored':build_cache,
         'road_diagnosis':stages,'jacobian_diagnosis':jac,'jacobian_full_result':jac_result,'frozen_scenarios':frozen,
         'profile_counts':profile_counts,'base_cache_counts':cache,'native':native,'validation':validation,'validation_counts':validation_counts,
         'full_newton_difference_and_energy_source_exact':True,'native_binaries_unchanged':True,
         'formal_T1_T2_T3':'not_run; 只处理试验台专项完整回归/记录复算，游戏seed/window未跑',
         'short_profile':'not_run; 完整凸起剖析已覆盖本块，未重复六拍剖析',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print([{k:g[k] for k in ('scenario','wall_seconds_reduction_percent','cpu_seconds_reduction_percent')} for g in groups])
print('one production source/five unchanged binaries/full payload/Newton formulas/629 pinned hits/validation verified')
