import json,sys
from pathlib import Path
root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import cProfile,pstats
import inspect,textwrap
from types import SimpleNamespace
from lab_experiment import LabExperiment
import compare_lab_compute
from box_radial_geometry import _axis_curvature
from wheel_contact_kernels import box_axis_cache_info
import unsprung_joint as joint
import vehicle_unsprung as vehicle

output=root/'logs/lab-perf-19/profile-final-bump'
profile=cProfile.Profile()
original=LabExperiment.step
cache_before = None
measured = False
base_counts = {}
def cache_count(name):
    if measured:base_counts[name] = base_counts.get(name,0)+1
original_solver = joint.solve_unsprung_joint
source = textwrap.dedent(inspect.getsource(original_solver))
for marker,name in (('        kinematics = finite_contact.evaluate','configuration'),
                    ('        geometry = configuration(end)','velocity'),
                    ('                force_reaction = reaction_base','force')):
    assert source.count(marker)==1
    indentation=marker[:len(marker)-len(marker.lstrip())]
    source=source.replace(marker,indentation+f'_cache_count("{name}")\n'+marker,1)
for marker,name in (('        if key==configuration_base_key:\n','configuration_hit'),
                    ('        if key==velocity_base_key:\n','velocity_hit'),
                    ('            if current_force_key==force_base_key:\n','force_hit')):
    assert source.count(marker)==1
    indentation=marker[:len(marker)-len(marker.lstrip())]+'    '
    source=source.replace(marker,marker+indentation+f'_cache_count("{name}")\n',1)
source=source.replace('        columns = []','        _cache_count("jacobian")\n        columns = []',1)
instrumented=root/'logs/lab-perf-19/profiled_joint.py'
instrumented.write_text(source,encoding='utf-8')
namespace=vars(joint);namespace['_cache_count']=cache_count
exec(compile(source,str(instrumented),'exec'),namespace)
vehicle.solve_unsprung_joint=joint.solve_unsprung_joint

def cache_info():
    return {'support':box_axis_cache_info(),'curvature':dict(_axis_curvature.cache_info()._asdict())}

def step(run):
    global cache_before,measured
    if cache_before is None:
        cache_before = cache_info()
    measured=True;profile.enable()
    try:return original(run)
    finally:profile.disable();measured=False

LabExperiment.step=step
try:
    compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    LabExperiment.step=original
    joint.solve_unsprung_joint=original_solver;vehicle.solve_unsprung_joint=original_solver
cache_after = cache_info()
counts = {name: {key: cache_after[name][key]-cache_before[name][key] for key in ("hits","misses")}
          for name in cache_before}
(output/'cache-counts.json').write_text(json.dumps({'before':cache_before,'after':cache_after,'geometry_cache':counts,
    'base_computation':base_counts},indent=2)+'\n',encoding='utf-8')
profile.dump_stats(str(output/'step.prof'))
with (output/'profile.txt').open('w',encoding='utf-8') as stream:
    stats=pstats.Stats(profile,stream=stream)
    stats.sort_stats('cumulative').print_stats(55)
    stats.sort_stats('tottime').print_stats(35)
rows=[{'file':path,'line':line,'function':function,'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for (path,line,function),v in stats.stats.items()]
(output/'profile.json').write_text(json.dumps({'ticks':144,'total_seconds':stats.total_tt,'functions':rows,'scope':'完整非线性实体凸起的独立诊断；分析器耗时不进入速度收益表'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-19/base-interleaved/nonlinear-bump/B1.bin').read_bytes()
print('bump profile physics payload exact')
