import dataclasses
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

root = Path.cwd()
if len(sys.argv) == 1:
    rows = []
    for label, source in (("A", root/"builds/lab-perf-19/baseline"), ("B", root)):
        result = subprocess.run([sys.executable, str(root/"tools/physics/run_sim_double.py"),
                                 __file__, str(source), label], stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, encoding="utf-8", check=True, timeout=60)
        rows.append(json.loads(result.stdout))
    assert rows[0]["cases"] == rows[1]["cases"]
    output = root/"logs/lab-perf-19/frozen-results.json"
    output.write_text(json.dumps({"exact": True, "runs": rows}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(len(rows[0]["cases"]), "additional joint scenarios exactly equal")
else:
    source = Path(sys.argv[1]).resolve()
    sys.path[:0] = [str(source/"src"), str(root/"tests")]
    from test_unsprung_joint import solve

    from vehicle_designs import REFERENCE_DESIGN

    def normalized(value):
        if dataclasses.is_dataclass(value):
            return {field.name: normalized(getattr(value, field.name)) for field in dataclasses.fields(value)
                    if field.name != "contact_geometry"}
        if isinstance(value, np.ndarray):
            return {"dtype": value.dtype.str, "shape": value.shape, "bytes": value.tobytes().hex()}
        if isinstance(value, np.generic):
            return normalized(value.item())
        if isinstance(value, float):
            return value.hex()
        if isinstance(value, (tuple, list)):
            return [normalized(item) for item in value]
        return value

    cases = {}
    scenarios = [(f"share-{share}-sync-{sync}-air-{air}", {"front_drive_share": share},
                  {"sync": sync, "airborne": air}) for share in (0., .5, 1.)
                 for sync in (False, True) for air in (False, True)]
    scenarios += [("reverse", {}, {"speed": -10., "ratio": -3.2}),
                  ("rough", {}, {"road": (.0002, -.0001, .0003, 0.)}),
                  ("finite-suspension", {}, {"finite_geometry": True}),
                  ("stored-rotor", {}, {"old_down_offset": (3., -2., 1.)}),
                  ("guide-bias", {}, {"guide_bias": np.full((4, 3), .0002)}),
                  ("wheel-momentum", {}, {"wheel_error": np.full((4, 3), .0002)})]
    for name, changes, arguments in scenarios:
        result = solve(dataclasses.replace(REFERENCE_DESIGN, **changes), **arguments)[0]
        content = json.dumps(normalized(result), sort_keys=True, separators=(",", ":"))
        cases[name] = hashlib.sha256(content.encode()).hexdigest()
    print(json.dumps({"source": str(source), "label": sys.argv[2], "cases": cases}))
