import json
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-19'
data=json.loads((folder/'summary.json').read_text(encoding='utf-8'));groups=data['groups']
jac=data['jacobian_diagnosis'];total=data['jacobian_full_result']['wall_seconds']
metric='/'.join(f"{g['wall_seconds_reduction_percent']:.2f}" for g in groups)
jac_percent=f"{100*jac['fraction_of_complete_compute']:.2f}"
lines=['# 试验台Newton基点精确复用与道路移植评估','',
'2026-10-16，基线7075998，主目录main，仅试验台；持续目标active。','',
'## 采用的改变','',
'只改unsprung_joint.py，在每轮Jacobian构造前固定本Newton基点已算好的构型、完整速度项、速度+八接触力项。原最后一项缓存仍照常移动；回到基点且键的原始字节全部相同，才复用该点结果。构型在有限径向接触下仍按前十速度、旧冻结端口仍按完整十六速度；速度和接触力键不减少字段，区分正负零。','',
'构型基点数据从本次velocity_data[0]取得，避免最后一项构型缓存与基点速度不一致；命中后同步原last key/data，保持下游force_key语义。每轮更新一个基点，全部缓存只属于本次solve闭包，不跨机械子步/世界/配置，不保存全部差分点。原数据只读复用，后续残差仍分配自己的输出。','',
'原34列中央差分、epsilon、Newton/线搜索、精确端口行修正、30轮/12次上限、残差门槛和能量结果段从columns=[]起全文相同；构型/速度的数值计算段、反力和轮心力表达式AST保持，求值尾段保持。五个原生扩展及SDK完全不变，没有改变物理模型或参数。','',
'## 为什么放弃道路候选C移植','',
'先测未改道路查询，实体凸起诊断19.317s中，键0.288s、平面准备1.401s、实际实体生成器4.541s、候选选择/结果组装（扣除实体查询）1.239s、输出缓冲0.149s、已有原生帧0.151s。原完整输出一致，诊断含计时开销，不当作速度收益。','',
'曾将候选控制流移入C，保留原查询、road_support回调、Python/NumPy比较分派、同距规则和异常顺序；三工况完整交叉结果一致，但收益不足：','',
'| 未采用C候选 | 墙钟减少 | CPU减少 |','|---|---:|---:|']
for group in data['rejected_candidate']:
    lines.append(f"| {group['scenario']} | {group['wall_seconds_reduction_percent']:.2f}% | {group['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','C移植的Python对象与回调边界成本抵消了循环收益，制动反而慢约1.92%，凸起仅快0.77%；不采用，不把函数调用数下降当成整步提速。候选3份源码、wheel二进制、两个测试文件及完整结果都保存在candidate-selector与interleaved。撤回时核对生产源码和五扩展与7075998实验前逐字节相同，再实现基点复用。','',
'C原型首轮23失败/36通过，原因是元组缓存键经C调用被拆成多个实参；修正原子传参后相关59项通过。最终候选26项与完整1728子步通过；测试闭包/Ruff格式问题已修正并保留日志。该候选没有跑完整691项，其结果不计作最终版本回归。当前生产不含C候选或新增C接口。','',
'## 真正的主开销','',
f"对恢复的原共同解逐列计时，不改原表达式。该次完整凸起计算{total:.6f}s，其中34列中央差分{jac['total_difference_seconds']:.6f}s，占{100*jac['fraction_of_complete_compute']:.2f}%；629次Jacobian重建，共42772次正负扰动求值。初始化另记，完整payload一致。",'',
'| 差分列 | 墙钟s |','|---|---:|']
for name,values in jac['groups'].items():lines.append(f"| {name} | {values['wall_seconds']:.6f} |")
lines+=['','前十个车身/轮心速度列承担多数开销。每次构造后，从最后一个扰动恢复到已算基点，却重算一次构型、完整速度项和接触力项；本块先去掉这些重复量。更大幅度减少Jacobian重建仍需单独验证，不能依据该时间占比直接承诺提速。','',
'## 最终完整步交叉实测','',
'三个原工况各四个独立世界，逐拍ABBA/反序正常前进，原生轴向缓存和Python曲率缓存各自独立。绑定切换/序列化在计时外，初始化单列；旧完整求解器来自冻结原文，结果类沿用相同原定义的正式模块名以免测试别名改变pickle路径。共享C计算源码和五扩展SHA完全相同。','',
'| 工况 | 旧墙钟s | 新墙钟s | 耗时减少 | 旧CPU s | 新CPU s | CPU减少 |',
'|---|---:|---:|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['wall_seconds']:.6f} | {b['wall_seconds']:.6f} | {g['wall_seconds_reduction_percent']:.2f}% | {a['cpu_seconds']:.6f} | {b['cpu_seconds']:.6f} | {g['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','| 工况 | 旧P95 ms | 新P95 ms | 旧P99 ms | 新P99 ms |','|---|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['step_p95_seconds']*1000:.3f} | {b['step_p95_seconds']*1000:.3f} | {a['step_p99_seconds']*1000:.3f} | {b['step_p99_seconds']*1000:.3f} |")
lines+=['','平均墙钟/CPU本批下降，转向P99变差约12.7%，原值保留，不宣称尾延迟Gate通过。机器绝对速度仍有波动，CPU逐拍计数离散，不跨历史批次拼接绝对值或累计相乘。当前仍慢于实时。','',
'| 工况 | A1初始化s | B1初始化s | B2初始化s | A2初始化s | 初始化拍数 |','|---|---:|---:|---:|---:|---:|']
for g in groups:
    initial=[r['initialization'] for r in g['rows']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{r['wall_seconds']:.3f}" for r in initial)+f" | {initial[0]['ticks']} |")
lines+=['','制动100km/h/.2s/24拍，第一个计算拍brake=1；转向30km/h/2°/.4s/48拍/onset=0；实体凸起18km/h/1.2s/144拍，实际预载/安装曲线/非线性阻尼。拟合输入为合成部件台架数据，不代表实车标定。12次共864拍/1728子步全部快照、信号、命令、共同解/能量账payload逐字节一致，18组额外求解也一致；仅归一实例epoch，排除含原生节点的contact_geometry引用，实际接触保留在快照。','',
'## 验证与实际次数','',
'新增8项真实平面/Box完整求解，覆盖原生体陀螺开关、有限悬架开关和导向偏置；对本块完整旧求解器逐位核对全部数值字段、实际接触/材料数组，重复求解验证缓存不跨调用，并确认材料计算至少减少本次Jacobian重建数。原36组完整求解等相关79项先检通过；最终普通/Double T0各87项/Ruff、Double43模块691项完整试验台回归和真实记录/旧检查点复算通过。','',
'完整凸起629次Jacobian，构型/速度/接触力三个基点各命中629次。实际构型计算14126→13497，速度项21674→21045，力前缀31738→31109，与重复恢复次数相符。','',
'完整残差44318、中央差分42772、Jacobian629、线性求解74040保持；接触构型14126→13497、逻辑道路29260→28002、范数354783→352267。减少的是同一基点已算结果的重复组装，实际实体生成器95513、Box包围盒80632、全局证明14881、锥端点59524、细化11918均保持；轴向/曲率缓存计数也完全相同。','',
'原完整剖析复用LAB-PERF-18，原源码/五扩展SHA与实验前完全一致。新完整剖析在复制的求解函数数值表达式前加入计数，执行源码profiled_joint.py明确归档，payload与最终速度实验相同；计数/分析器开销不进入速度表。没有再跑六拍剖析，完整剖析已覆盖本块工作量。','',
'summary和raw-evidence.zip保存弃用C方案、原道路/差分诊断、最终12份payload、18组输入、实际旧/新Python源、共享五扩展、旧新完整剖析、基点次数、构建/失败/验证日志及复现脚本。来源/配置/SDK与实际执行版本逐次核对。','',
'复现最终版本：从7075998冻结src和五扩展，使用同一Double SDK执行归档base_interleaved.py，输出选新目录。profile_bump.py和lab_regression.py复现完整剖析/专项回归。C候选只在归档中供复核，不是产品入口。','',
'本块仅本地提交，持续目标active。游戏seed/window及通用T1/T2/T3未跑；原120Hz/双子步/34变量/完整碰撞与求解门槛保持。原完整能量/精度、人工体验、实时及EPA部分网格边缘拒绝仍开放。下一优先评估Jacobian复用/更新策略，继续验证同一物理方程和收敛精度，不以降低模型或求解精度换速度。','']
(folder/'README.md').write_text('\n'.join(lines),encoding='utf-8')
(root/'docs/tasks/LAB-PERF-19.md').write_text(f'''# LAB-PERF-19 道路移植评估与Newton基点精确复用

- 状态：done（本功能块）；基线7075998，main，本地提交；持续目标active。
- 道路分段计时后尝试C候选遍历，完整结果一致但制动慢1.92%/凸起仅快0.77%，不采用，原源码/二进制/测试/全部失败与计时归档。恢复生产源码与五扩展原字节后转向共同解。
- 原完整凸起差分{jac['total_difference_seconds']:.3f}/{total:.3f}s，占{jac['fraction_of_complete_compute']*100:.2f}%，629次Jacobian/42772扰动。最终只复用当前Newton基点已算的构型/速度/速度+接触力，完整键/原计算顺序/全部差分与收敛保持。
- 三工况四独立世界逐拍交叉完整步墙钟−{metric}%；转向P99变差保留，仍慢于实时。1728子步完整结果与18组输入逐字节一致。
- 三类基点各命中629；构型14126→13497、速度21674→21045、力前缀31738→31109，残差44318/线性求解74040/真实实体95513/Box证明与细化保持。五扩展/SDK不变。
- 新增8项真实平面/Box完整解逐位对照；普通/Double T0各87项/Ruff、Double43模块691项专项回归/记录复算通过。完整剖析计数源码单列归档；六拍未重复。
- [完整记录](../evidence/LAB-PERF-19/README.md)、summary.json、raw-evidence.zip包含参数/CPU/墙钟/P95/P99/初始化、源码与扩展实际SHA、原始结果和复现命令。
- 游戏seed/window及通用T1/T2/T3未跑；原完整能量/精度/人工/实时/EPA Gate开放。下一重点Jacobian重建/更新，保留同一方程与精度门槛。
''',encoding='utf-8')
path=root/'docs/current-progress.md';text=path.read_text(encoding='utf-8')
start=text.index('当前施工仅试验台：');end=text.index('\n',start)
text=text[:start]+f'当前施工仅试验台：最新完成[LAB-PERF-19](tasks/LAB-PERF-19.md)Newton基点精确复用。道路C移植无稳定收益已撤回；定位中央差分占本次完整凸起计算约{jac_percent}%，最终在全部差分/原门槛下复用基点，三工况整步再减{metric}%，1728子步完整结果逐字节一致，转向P99变差保留。持续目标active，下一优先Jacobian重建/更新策略。下列历史节点只支持各自版本/协议，最新收益以本块同批对照为准。'+text[end:]
text+=f'\n- [LAB-PERF-19 Newton基点复用](tasks/LAB-PERF-19.md)：7075998基线，C候选移植无稳定收益撤回归档；原差分占本次完整凸起{jac_percent}%计算时间，固定当前基点三类完整字节数据，保留全部34列中央差分/原残差/门槛与五扩展。三工况四世界交叉整步−{metric}%，1728子步/18组输入精确一致，新增8项、普通/Double T0各87项、Double43模块691项/记录复算通过。各基点命中629次，转向P99变差保留，真实实体/Box证明与细化保持；本地提交，持续目标active，下一Jacobian重建/更新。\n'
path.write_text(text,encoding='utf-8')
print('report/task/progress written from verified measurements')
