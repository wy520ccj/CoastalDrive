import inspect
import json
import sys
import textwrap
import time
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import radial_geometry as radial
import compare_lab_compute
from lab_experiment import LabExperiment

counts={};durations={};measured=False
def stage(name,started):
    if measured:
        counts[name]=counts.get(name,0)+1
        durations[name]=durations.get(name,0.)+time.perf_counter()-started
original=radial.RadialRoads.query
source=textwrap.dedent(inspect.getsource(original))
source=source.replace('    config = self.config','    _started = _clock()\n    config = self.config',1)
source=source.replace('    if surface_cache is None:','    _stage("setup",_started)\n    _started = _clock()\n    if surface_cache is None:',1)
for marker in ('        planes = tuple(surface.query_plane','        planes = tuple(_cached_plane'):
    assert source.count(marker)==1
    source=source.replace(marker,'        _stage("keys",_started)\n        _started = _clock()\n'+marker,1)
source=source.replace('    hits = []','    _stage("planes",_started)\n    _started = _clock()\n    hits = []',1)
source=source.replace('    delta = np.empty(count)','    _stage("selection_total",_started)\n    _started = _clock()\n    delta = np.empty(count)',1)
source=source.replace('    radial_contact_frames(','    _stage("output_buffers",_started)\n    _started = _clock()\n    radial_contact_frames(',1)
source=source.replace('    return UnsprungGeometry(','    _stage("frames",_started)\n    return UnsprungGeometry(',1)
path=root/'logs/lab-perf-19/diagnostic_query.py';path.write_text(source,encoding='utf-8')
namespace=vars(radial);namespace.update(_stage=stage,_clock=time.perf_counter)
exec(compile(source,str(path),'exec'),namespace)
radial.RadialRoads.query=namespace['query']
original_surface=radial.RadialSurface.query
def surface(*args,**kwargs):
    iterator=original_surface(*args,**kwargs)
    while True:
        before=time.perf_counter()
        try:value=next(iterator)
        except StopIteration:
            stage('surface_generator',before)
            return
        stage('surface_generator',before)
        yield value
radial.RadialSurface.query=surface
original_step=LabExperiment.step
def step(run):
    global measured
    measured=True
    try:return original_step(run)
    finally:measured=False
LabExperiment.step=step
output=root/'logs/lab-perf-19/stage-diagnosis'
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    radial.RadialRoads.query=original;radial.RadialSurface.query=original_surface;LabExperiment.step=original_step
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-18/interleaved/nonlinear-bump/A1.bin').read_bytes()
assert all(counts[name]==29260 for name in ('setup','keys','planes','selection_total','output_buffers','frames'))
durations['selection_without_geometry']=durations['selection_total']-durations['surface_generator']
(output/'stages.json').write_text(json.dumps({'counts':counts,'wall_seconds':durations,'payload_exact':True,'scope':'原道路查询分段诊断，实体生成器逐次next单列，含计时开销，不当作速度收益'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(durations)
