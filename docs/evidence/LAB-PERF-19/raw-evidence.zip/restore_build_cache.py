import hashlib
import json
from pathlib import Path

root=Path.cwd();logs=root/'logs/lab-perf-19'
production=next((root/'src').glob('wheel_contact_kernels*.pyd'))
target=root/'build/lib.win-amd64-cpython-314'/production.name
candidate=logs/'candidate-selector'/production.name
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before=digest(target)
assert before in (digest(candidate),digest(production))
target.write_bytes(production.read_bytes())
assert digest(target)==digest(production)
(logs/'build-cache-restored.json').write_text(json.dumps({'production':str(production),'build_cache':str(target),
    'before_sha256':before,'after_sha256':digest(target),'candidate_sha256':digest(candidate)},indent=2)+'\n',encoding='utf-8')
print('discarded candidate also removed from default build/lib; saved candidate remains in archive')
