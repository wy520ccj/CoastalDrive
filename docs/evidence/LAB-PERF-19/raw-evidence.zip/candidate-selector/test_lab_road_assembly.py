"""道路原候选顺序、标量分派、缓存/错误及真实几何组装的逐位对照。"""

import struct
from dataclasses import fields, replace
from types import SimpleNamespace

import lab_road_assembly_reference as reference
import numpy as np
import pytest
from test_lab_surface_cache import layout, surfaces
from wheel_contact_kernels import radial_select_hits

from radial_geometry import RadialHit, RadialRoads
from vehicle_contacts import road_support
from vehicle_designs import REFERENCE_DESIGN


def assert_geometry(actual,expected):
    for a,b in zip(actual.hits,expected.hits,strict=True):
        if a is None:assert b is None;continue
        assert a.node==b.node and a.plane==b.plane
        for name in ('point','normal'):
            for x,y in zip(getattr(a,name),getattr(b,name),strict=True):
                assert type(x) is type(y) and struct.pack('=d',x)==struct.pack('=d',y)
    for field in fields(actual)[1:]:
        a,b=getattr(actual,field.name),getattr(expected,field.name)
        assert a.dtype==b.dtype and a.shape==b.shape and a.strides==b.strides
        assert a.tobytes()==b.tobytes(),field.name


class Surface:
    plane=None
    def __init__(self,body,candidates):self.body,self.candidates,self.calls=body,candidates,[]
    def query(self,center,axis,config):
        self.calls.append(int(center[0]))
        yield from self.candidates[int(center[0])]


@pytest.mark.parametrize('scalar',[float,np.float32,np.float64])
@pytest.mark.parametrize('cached',[False,True])
def test_original_distance_dispatch_slope_boundary_first_equal_signed_zero_and_cache(scalar,cached):
    config=replace(REFERENCE_DESIGN,wheel_radius=.33000003,suspension_travel=.18)
    limit=config.wheel_radius+config.suspension_travel
    centers=np.column_stack((np.arange(4,dtype=float),np.zeros((4,2))))
    axes=np.tile((1.,0.,0.),(4,1));up=np.array((0.,0.,1.))
    for normal_type in (tuple,np.asarray):
        tables=[]
        for surface in range(3):
            rows=[]
            for row in range(4):
                z=(np.nextafter(.5,0.),.5,np.nextafter(.5,1.),1.)[row]
                normal=normal_type((np.sqrt(1-z*z),0.,z))
                point=np.array((float(surface),-0.,.2),dtype=scalar)
                distances=(scalar(limit),scalar(0.),scalar(-0.))
                rows.append(tuple((distance,normal,point,(tuple(normal),.2)) for distance in distances[surface:surface+1]))
            tables.append(rows)
        raw=tuple(Surface(i,table) for i,table in enumerate(tables))
        roads=SimpleNamespace(config=config,surfaces=raw)
        first_cache=[{} for _ in raw] if cached else None
        old_cache=[{} for _ in raw] if cached else None
        for _ in range(2):
            actual=RadialRoads.query(roads,centers,up,axes,surface_cache=first_cache)
            expected=reference.RadialRoads.query(roads,centers,up,axes,surface_cache=old_cache)
            assert_geometry(actual,expected)
            if cached:assert all(a.keys()==b.keys() for a,b in zip(first_cache,old_cache))
        if cached:assert all(s.calls==list(range(4))*2 for s in raw)


@pytest.mark.parametrize('kind',['plane','box','mixed'])
@pytest.mark.parametrize('cached',[False,True])
def test_real_surface_queries_keep_complete_geometry_across_layouts_and_warm_cache(kind,cached):
    for frame in ('C','F'):
        raw=surfaces(frame,kind)
        roads=SimpleNamespace(config=REFERENCE_DESIGN,surfaces=raw)
        for order in ('C','F','strided','reverse'):
            centers=layout(np.array(((0.,-.09,.315),(.04,-.07,.315),(-.04,-.02,.4),(0.,2.,2.))),order)
            axes=layout(np.tile((1.,0.,0.),(4,1)),order);up=np.array((0.,0.,1.))
            a_cache=[{} for _ in raw] if cached else None
            b_cache=[{} for _ in raw] if cached else None
            for step in range(3):
                if step==2:centers[1,2]=np.nextafter(centers[1,2],np.inf)
                assert_geometry(RadialRoads.query(roads,centers,up,axes,surface_cache=a_cache),
                                reference.RadialRoads.query(roads,centers,up,axes,surface_cache=b_cache))


@pytest.mark.parametrize('cached',[False,True])
@pytest.mark.parametrize('failure',['generator','support','hit'])
def test_exception_and_callback_order_match_original_and_partial_generators_are_not_published(monkeypatch,cached,failure):
    import radial_geometry as current
    traces=[]
    for module in (reference,current):
        events=[];cache=[{}] if cached else None
        class BrokenSurface:
            body,plane='road',None
            def query(self,center,axis,config,_events=events):
                _events.append('yield')
                yield 0.,np.array((0.,0.,1.)),np.zeros(3),None
                _events.append('end')
                if failure=='generator':raise ArithmeticError('候选中断')
        def predicate(normal,_events=events):
            _events.append('support')
            if failure=='support':raise ValueError('资格中断')
            return road_support(normal)
        original_hit=module.RadialHit
        def hit(*args,_events=events,_hit=original_hit):
            _events.append('hit')
            if failure=='hit':raise RuntimeError('命中中断')
            return _hit(*args)
        with monkeypatch.context() as context:
            context.setattr(module,'road_support',predicate);context.setattr(module,'RadialHit',hit)
            roads=SimpleNamespace(config=REFERENCE_DESIGN,surfaces=(BrokenSurface(),))
            with pytest.raises({'generator':ArithmeticError,'support':ValueError,'hit':RuntimeError}[failure]):
                module.RadialRoads.query(roads,np.zeros((1,3)),np.array((0.,0.,1.)),np.array(((1.,0.,0.),)),surface_cache=cache)
        if cached and failure=='generator':assert not cache[0]
        traces.append(events)
    assert traces[0]==traces[1]


@pytest.mark.parametrize('cached',[False,True])
def test_empty_world_and_zero_wheels_keep_original_fields(cached):
    for count in (0,4):
        roads=SimpleNamespace(config=REFERENCE_DESIGN,surfaces=())
        centers=np.zeros((count,3));axes=np.tile((1.,0.,0.),(count,1));up=np.array((0.,0.,1.))
        assert_geometry(RadialRoads.query(roads,centers,up,axes,surface_cache=[] if cached else None),
                        reference.RadialRoads.query(roads,centers,up,axes,surface_cache=[] if cached else None))


def test_mapping_subclass_receives_nested_tuple_key_as_one_argument():
    class Cache(dict):
        def __init__(self):super().__init__();self.keys_seen=[]
        def get(self,key,default=None):self.keys_seen.append(key);return super().get(key,default)
    source=Surface('road',[((0.,np.array((0.,0.,1.)),np.zeros(3),None),)])
    roads=SimpleNamespace(config=REFERENCE_DESIGN,surfaces=(source,));cache=[Cache()]
    for _ in range(2):RadialRoads.query(roads,np.zeros((1,3)),np.array((0.,0.,1.)),np.array(((1.,0.,0.),)),surface_cache=cache)
    assert len(cache[0].keys_seen)==2 and len(source.calls)==1
    assert cache[0].keys_seen[0]==cache[0].keys_seen[1] and len(cache[0].keys_seen[0])==3


@pytest.mark.parametrize('problem',['count','shape','dtype','readonly'])
def test_native_selection_output_errors_are_explicit(problem):
    outputs=[np.empty(1),np.empty(1),np.empty((1,3)),np.empty((1,3))]
    if problem=='count':outputs.pop()
    elif problem=='shape':outputs[0]=np.empty(2)
    elif problem=='dtype':outputs[0]=np.empty(1,dtype=np.float32)
    else:outputs[0].flags.writeable=False
    with pytest.raises((ValueError,BufferError)):
        radial_select_hits((np.zeros((1,3)),np.zeros((1,3))),tuple(outputs),(),(),None,None,REFERENCE_DESIGN,.5,road_support,RadialHit)


def test_native_strided_output_storage_gaps_remain_untouched():
    centers=np.zeros((1,3));axes=np.array(((1.,0.,0.),));centers.flags.writeable=axes.flags.writeable=False
    source=Surface('road',[((-0.,np.array((0.,0.,1.)),np.array((-0.,.2,.3)),None),)])
    storage=[np.full(2,71.),np.full(2,71.),np.full((1,6),71.),np.full((1,6),71.)]
    outputs=tuple(v[...,::2] for v in storage)
    hits=radial_select_hits((centers,axes),outputs,(source,),(None,),None,None,REFERENCE_DESIGN,.5,road_support,RadialHit)
    assert hits[0].node=='road' and struct.pack('=d',outputs[1][0])==struct.pack('=d',-0.)
    for value in storage:assert np.all(value[...,1::2]==71.)
