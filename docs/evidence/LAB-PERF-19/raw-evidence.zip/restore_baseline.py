import hashlib
import json
from pathlib import Path

root=Path.cwd();logs=root/'logs/lab-perf-19'
saved=logs/'candidate-selector'
saved.mkdir(exist_ok=False)
for name in ('radial_geometry.py','lab_contact_native.h','wheel_contact_kernels.c'):
    (saved/name).write_bytes((root/'src'/name).read_bytes())
for path in (root/'src').glob('wheel_contact_kernels*.pyd'):(saved/path.name).write_bytes(path.read_bytes())
for name in ('test_lab_road_assembly.py','lab_road_assembly_reference.py'):
    (saved/name).write_bytes((root/'tests'/name).read_bytes())
baseline=root/'builds/lab-perf-19/baseline/src'
before=json.loads((logs/'stage-diagnosis/result.json').read_text(encoding='utf-8'))
for name in ('radial_geometry.py','lab_contact_native.h','wheel_contact_kernels.c'):
    raw=(baseline/name).read_bytes()
    digest=before['source_hashes'][name]
    variants=(raw,raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
    chosen=[v for v in variants if hashlib.sha256(v).hexdigest()==digest]
    assert chosen,name
    (root/'src'/name).write_bytes(chosen[0])
for path in baseline.glob('*.pyd'):(root/'src'/path.name).write_bytes(path.read_bytes())
assert all(hashlib.sha256((root/'src'/name).read_bytes()).hexdigest()==digest for name,digest in before['source_hashes'].items())
assert all(hashlib.sha256(Path(data['path']).read_bytes()).hexdigest()==data['sha256'] for data in before['native'].values())
print('production source and five native files byte-identical to pre-experiment 7075998; candidate saved')
