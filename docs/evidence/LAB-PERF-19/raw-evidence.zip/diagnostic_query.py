def query(self, centers, up, axes, *, surface_cache=None):
    """缓存仅供持有本描述/配置的有限接触对象使用，下一子步必须重建。"""
    _started = _clock()
    config = self.config
    centers,up,axes = map(np.asarray,(centers,up,axes))
    count = len(centers)
    _stage("setup",_started)
    _started = _clock()
    if surface_cache is None:
        keys = None
        _stage("keys",_started)
        _started = _clock()
        planes = tuple(surface.query_plane(centers,axes,config) if surface.plane is not None else None
                       for surface in self.surfaces)
    else:
        layout = centers.dtype.str,centers.shape[1:],centers.strides[1:],axes.dtype.str,axes.shape[1:],axes.strides[1:]
        keys = tuple((layout,center.tobytes(),axis.tobytes()) for center,axis in zip(centers,axes,strict=True))
        _stage("keys",_started)
        _started = _clock()
        planes = tuple(_cached_plane(surface,centers,axes,config,keys,cache) if surface.plane is not None else None
                       for surface,cache in zip(self.surfaces,surface_cache,strict=True))
    _stage("planes",_started)
    _started = _clock()
    hits = []
    touch,distances = np.zeros(count),np.zeros(count)
    points,hit_normals = np.zeros((count,3)),np.zeros((count,3))
    for i,(center,axis) in enumerate(zip(centers,axes)):
        best = None
        for index,(surface,values) in enumerate(zip(self.surfaces,planes)):
            if values is not None:
                candidates = (values[i],)
            elif surface_cache is None:
                candidates = surface.query(center,axis,config)
            else:
                cache = surface_cache[index]
                candidates = cache.get(keys[i])
                if candidates is None:
                    # 完整成功或空候选才写入；失败仍由原几何算法向上传播。
                    candidates = tuple(surface.query(center,axis,config))
                    cache[keys[i]] = candidates
            for distance,normal,point,plane in candidates:
                if (distance<=config.wheel_radius+config.suspension_travel and road_support(normal)
                        and (best is None or distance<best[0])):
                    best = distance,normal,point,surface.body,plane
        if best is None:
            hit = None
        else:
            distance,normal,point,road,plane = best
            touch[i],distances[i],points[i],hit_normals[i] = 1.,distance,point,normal
            hit = RadialHit(road,tuple(point),tuple(normal),plane)
        hits.append(hit)
    _stage("selection_total",_started)
    _started = _clock()
    delta = np.empty(count)
    offsets,normals,tangents,laterals,normal_offsets = (np.empty((count,3)) for _ in range(5))
    _stage("output_buffers",_started)
    _started = _clock()
    radial_contact_frames((centers,axes,up,touch,distances,points,hit_normals),
        (delta,offsets,normals,tangents,laterals,normal_offsets),count,
        config.wheel_radius,config.wheel_width/2,config.wheel_shoulder_radius,
        config.wheel_crown_height,config.suspension_travel)
    _stage("frames",_started)
    return UnsprungGeometry(tuple(hits),delta,offsets,normals,tangents,laterals,normal_offsets)
