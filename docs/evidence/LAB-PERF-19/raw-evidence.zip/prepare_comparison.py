from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-18/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-18','lab-perf-19')
source=source.replace('import unsprung_contact_geometry as geometry','import radial_geometry as geometry\nimport lab_road_assembly_reference as old_geometry')
source=source.replace('from lab_contact_frames_reference import FiniteRadialContact as OldContact','from lab_road_assembly_reference import RadialRoads as OldRoads')
source=source.replace("new_only={'finite_contact_averages','finite_contact_frames'}","new_only={'radial_select_hits'}")
source=source.replace("if path is None or Path(path).resolve().parent!=root/'src':continue", "if path is None or (Path(path).resolve().parent!=root/'src' and module is not old_geometry):continue")
source=source.replace('original_evaluate=geometry.FiniteRadialContact.evaluate','original_query=geometry.RadialRoads.query\n# 两个原数据类定义没有改动，沿用正式模块名，避免测试别名改变pickle路径。\nold_geometry.RadialHit=geometry.RadialHit\nold_geometry.UnsprungGeometry=geometry.UnsprungGeometry')
source=source.replace('geometry.FiniteRadialContact.evaluate=OldContact.evaluate if index in (0,3) else original_evaluate','geometry.RadialRoads.query=OldRoads.query if index in (0,3) else original_query')
source=source.replace('geometry.FiniteRadialContact.evaluate=original_evaluate','geometry.RadialRoads.query=original_query')
source=source.replace("root/'logs/lab-perf-17/complete-final-AB'/('nonlinear-A' if scenario=='nonlinear-bump' else ('braking-A1' if scenario=='braking' else 'turning-A'))/'payload.bin'", "root/'logs/lab-perf-18/interleaved'/scenario/'A1.bin'")
(root/'logs/lab-perf-19/interleaved.py').write_text(source,encoding='utf-8')
print('four independent worlds/extension states/curvature caches; old reference native bindings included')
