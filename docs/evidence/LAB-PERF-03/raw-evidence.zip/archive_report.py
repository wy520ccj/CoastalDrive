import hashlib
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
sys.path.insert(0, str(root/"src"))
logs = root/"logs/lab-perf-03"
output = root/"docs/evidence/LAB-PERF-03"
output.mkdir(parents=True, exist_ok=True)
baseline = root/"builds/lab-perf-03/baseline/src"
changes = [p.name for p in baseline.iterdir() if p.suffix in (".py", ".c", ".cpp", ".h")
           and p.read_bytes().replace(b"\r\n", b"\n") != (root/"src"/p.name).read_bytes().replace(b"\r\n", b"\n")]
assert changes == ["unsprung_joint.py"]
current_source = (root/"src/unsprung_joint.py").read_text(encoding="utf-8")
old_source = (baseline/"unsprung_joint.py").read_text(encoding="utf-8")
marker = "    config_rear = replace(config,lateral_stiffness=config.rear_lateral_stiffness)"
assert current_source[current_source.index(marker):] == old_source[old_source.index(marker):]
rows = json.loads((logs/"complete-AB/summary.json").read_text(encoding="utf-8"))
assert len(rows) == 8
native = {name: value["sha256"] for name, value in rows[0]["native"].items()}
for row in rows:
    assert row["complete_payload_equal"] and row["substeps"] == 2*row["ticks"]
    assert row["runtime"] == rows[0]["runtime"]
    assert {name: value["sha256"] for name, value in row["native"].items()} == native
    if "-B" in row["case"]:
        assert row["source_hashes"]["unsprung_joint.py"] == hashlib.sha256((root/"src/unsprung_joint.py").read_bytes()).hexdigest()
groups = []
for scenario in ("braking", "turning", "nonlinear-bump"):
    cases = [row for row in rows if row["scenario"] == scenario]
    expected = (logs/"complete-AB"/cases[0]["case"]/"payload.bin").read_bytes()
    for row in cases:
        assert (logs/"complete-AB"/row["case"]/"payload.bin").read_bytes() == expected
        assert row["payload_sha256"] == hashlib.sha256(expected).hexdigest()
        assert row["config"] == cases[0]["config"] and row["options"] == cases[0]["options"]
        assert row["requested_config"] == cases[0]["requested_config"]
    data = pickle.loads(expected)
    assert len(data["snapshots"]) == cases[0]["ticks"]+1 and len(data["joint"]) == cases[0]["substeps"]
    assert all(r["joint_iterations"] == cases[0]["joint_iterations"] for r in cases)
    measured = {}
    for label in ("A", "B"):
        sample = [row for row in cases if "-"+label in row["case"]]
        steps = [dt for row in sample for dt in row["step_seconds"]]
        measured[label] = {"runs": len(sample),
                           **{key: float(np.mean([r[key] for r in sample])) for key in
                              ("wall_seconds", "cpu_seconds", "physics_snapshot_seconds")},
                           "step_p95_seconds": float(np.percentile(steps, 95)),
                           "step_p99_seconds": float(np.percentile(steps, 99)),
                           "initialization": {key: float(np.mean([r["initialization"][key] for r in sample]))
                                              for key in ("wall_seconds", "cpu_seconds", "ticks")}}
    group = {"scenario": scenario, "options": cases[0]["options"], "actual_config": cases[0]["config"],
             "requested_config": cases[0]["requested_config"], "measured": measured,
             "wall_reduction_percent": 100*(1-measured["B"]["wall_seconds"]/measured["A"]["wall_seconds"]),
             "cpu_reduction_percent": 100*(1-measured["B"]["cpu_seconds"]/measured["A"]["cpu_seconds"]),
             "payload_sha256": hashlib.sha256(expected).hexdigest(), "complete_payload_exact": True}
    if scenario == "nonlinear-bump":
        config = group["actual_config"]
        assert config["suspension_coil_enabled"] and config["suspension_installation_curves"] and config["suspension_damper_curves"]
        load = np.asarray([s.player.unsprung_state.normal_force for s in data["snapshots"]])
        group["peak_normal_load_change_from_initial_N"] = np.max(abs(load-load[0]), axis=0).tolist()
        assert group["peak_normal_load_change_from_initial_N"][0] > 100.
        assert group["peak_normal_load_change_from_initial_N"][2] > 100.
    groups.append(group)
frozen = json.loads((logs/"frozen-results.json").read_text(encoding="utf-8"))
assert frozen["exact"] and len(frozen["runs"][0]["cases"]) == 18
assert frozen["runs"][0]["cases"] == frozen["runs"][1]["cases"]
validation = {name: json.loads((logs/name/"summary.json").read_text(encoding="utf-8"))
              for name in ("T0", "T0-standard", "lab-regression")}
assert all(result["passed"] for result in validation.values())
profiles = {label: json.loads((logs/("profile-"+label)/"profile.json").read_text(encoding="utf-8"))
            for label in ("before", "after")}
profile_rows = {}
for label, profile in profiles.items():
    def calls(name, file, line=None):
        matched = [row for row in profile["functions"] if row["function"] == name
                   and Path(row["file"]).name == file and (line is None or row["line"] == line)]
        assert len(matched) == 1
        return matched[0]["calls"]
    profile_rows[label] = {"ticks": profile["ticks"], "residual_calls": calls("evaluate", "unsprung_joint.py"),
                           "normal_material_calls": calls("normal_material", "unsprung_contact.py"),
                           "finite_contact_calls": calls("evaluate", "unsprung_contact_geometry.py"),
                           "road_geometry_queries": calls("query", "radial_geometry.py", 128),
                           "spin_calls": calls("spin", "unsprung_drivetrain.py")}
assert profile_rows["before"]["residual_calls"] == profile_rows["after"]["residual_calls"] == 1692
assert profile_rows["before"]["normal_material_calls"] == 1692 and profile_rows["after"]["normal_material_calls"] == 540
assert profile_rows["before"]["road_geometry_queries"] == profile_rows["after"]["road_geometry_queries"] == 1122
(logs/"notes.md").write_text("""# 证据范围

活动main基线c1f38eb，第一块LAB-PERF-02先保存为该本地提交。基线导出/扩展复制SHA一致，生产只改unsprung_joint.py。源码尾部config_rear之后的Newton、差分、线搜索、收敛、结果与能量账完整文本相同。

八次完整实验串行，随后运行两个6拍分析器样本之一的after和18组冻结输入对照；profile-before在施工前完成。全部速度测量结束后才执行回归。没有并发预览、修改时钟/亲和性/优先级。

曾临时添加/撤掉两个函数文档字符串，全部B测量记录源码SHA与最终源码一致。读取尚未创建的日志曾报文件不存在，不是物理失败；无物理失败、超时或放宽容差。

采用真实完整步ABBA/A-B、当前运行库；不把上一批LAB-PERF-02的不同CPU时段绝对秒数拼接计算累计提速。profile只用调用次数解释缓存收益，其自带开销不混入速度表。正常回归与Double专项可同时运行，均在性能采样之后。

首个归档汇总把同一radial_geometry.py里RadialSurface.query与RadialRoads.query混选，1122断言失败；已改为文件名+验证过的源码行128精确匹配，未改生产或重测物理。
""", encoding="utf-8")
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".log", ".txt", ".py", ".md", ".bin", ".prof") and "user-data" not in path.parts:
            archive.write(path, path.relative_to(logs).as_posix())
    archive.write(root/"tools/performance/compare_lab_compute.py", "executed-comparison-tool.py")
summary = {"baseline": "c1f38eb", "source_changes": changes, "solver_and_energy_tail_text_exact": True,
           "runtime": rows[0]["runtime"], "native_sha256": native, "groups": groups,
           "frozen_scenarios": frozen, "profile_call_counts": profile_rows,
           "validation": validation, "validation_counts": {"Double_T0": 35, "standard_T0": 35, "Double_lab_regression": 222},
           "physics_gate": "原完整模型/配置/120Hz/双子步/epsilon/阈值保持；未提升已有能量/精度Gate",
           "formal_T1_T2_T3": "not_run; 按用户只处理试验台，专项完整回归/记录复算完成，游戏seed/window未跑",
           "real_time_human_gate": "open; 实测仍慢于实时，人工体验待确认",
           "raw_evidence_sha256": hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()}
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{"scenario": g["scenario"], "wall_reduction_percent": g["wall_reduction_percent"],
                   "cpu_reduction_percent": g["cpu_reduction_percent"]} for g in groups], indent=2))
print("source/native/solver/payload/config/18-joint-cases/call-counts/validation verified")
