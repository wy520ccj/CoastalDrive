import hashlib
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
logs = root/"logs/lab-perf-02"
output = root/"docs/evidence/LAB-PERF-02"
output.mkdir(parents=True, exist_ok=True)
rows = json.loads((logs/"complete-AB/summary.json").read_text(encoding="utf-8"))
assert len(rows) == 8
source_changes = sorted(p.name for p in (root/"builds/lab-perf-02/baseline/src").iterdir()
                        if p.suffix in (".py", ".c", ".cpp", ".h")
                        and p.read_bytes().replace(b"\r\n", b"\n") != (root/"src"/p.name).read_bytes().replace(b"\r\n", b"\n"))
assert source_changes == sorted(["radial_geometry.py", "unsprung_contact_geometry.py", "unsprung_drivetrain.py",
                                 "unsprung_dynamics.py", "unsprung_joint.py", "unsprung_motion.py"])
native = {k: v["sha256"] for k, v in rows[0]["native"].items()}
assert all({k: v["sha256"] for k, v in row["native"].items()} == native for row in rows)
assert all(row["runtime"] == rows[0]["runtime"] and row["complete_payload_equal"] for row in rows)
assert all(len(row["step_seconds"]) == row["ticks"] and row["substeps"] == 2*row["ticks"] for row in rows)
sys.path.insert(0, str(root/"src"))
from dataclasses import asdict, replace

from driving_modes import DrivingMode
from vehicle_designs import REFERENCE_DESIGN
from vehicle_parameters import config_from_document

groups = []
for scenario in ("braking", "turning", "nonlinear-bump"):
    selected = [r for r in rows if r["scenario"] == scenario]
    reference = (logs/"complete-AB"/selected[0]["case"]/"payload.bin").read_bytes()
    for row in selected:
        actual = (logs/"complete-AB"/row["case"]/"payload.bin").read_bytes()
        assert actual == reference
        assert hashlib.sha256(actual).hexdigest() == row["payload_sha256"]
        assert row["config"] == selected[0]["config"] and row["options"] == selected[0]["options"]
    data = pickle.loads(reference)
    assert len(data["snapshots"]) == selected[0]["ticks"]+1
    assert len(data["joint"]) == selected[0]["substeps"]
    pair = {}
    for label in ("A", "B"):
        samples = [r for r in selected if "-"+label in r["case"]]
        steps = [step for row in samples for step in row["step_seconds"]]
        pair[label] = {"runs": len(samples),
                       "wall_mean_seconds": float(np.mean([r["wall_seconds"] for r in samples])),
                       "cpu_mean_seconds": float(np.mean([r["cpu_seconds"] for r in samples])),
                       "physics_snapshot_mean_seconds": float(np.mean([r["physics_snapshot_seconds"] for r in samples])),
                       "step_p95_seconds": float(np.percentile(steps, 95)),
                       "step_p99_seconds": float(np.percentile(steps, 99)),
                       "initialization_wall_mean_seconds": float(np.mean([r["initialization"]["wall_seconds"] for r in samples])),
                       "initialization_cpu_mean_seconds": float(np.mean([r["initialization"]["cpu_seconds"] for r in samples]))}
    requested = config_from_document(selected[0]["config"], REFERENCE_DESIGN)
    options = selected[0]["options"]
    actual = DrivingMode.SIMULATION.configured_vehicle(options["abs_enabled"],
        esc_enabled=options["esc_enabled"], base_config=requested)
    actual = replace(actual, road_friction=options["friction"])
    assert actual == replace(requested, stability=replace(requested.stability, esc_enabled=False))
    group = {"scenario": scenario, "options": options, "config": asdict(actual),
             "requested_config": selected[0]["config"],
             "actual_config_provenance": "按未改的LabExperiment/DrivingMode由原requested_config+options重建；原始报告保留，ESC按原协议关闭",
             "results": pair, "wall_speedup": pair["A"]["wall_mean_seconds"]/pair["B"]["wall_mean_seconds"],
             "cpu_speedup": pair["A"]["cpu_mean_seconds"]/pair["B"]["cpu_mean_seconds"],
             "complete_payload_exact": True, "payload_sha256": selected[0]["payload_sha256"]}
    if scenario == "nonlinear-bump":
        config = selected[0]["config"]
        assert config["suspension_coil_enabled"] and config["suspension_installation_curves"] and config["suspension_damper_curves"]
        loads = np.asarray([s.player.unsprung_state.normal_force for s in data["snapshots"]])
        peak_delta = np.max(abs(loads-loads[0]), axis=0)
        assert peak_delta[0] > 100 and peak_delta[2] > 100
        group["peak_normal_load_change_from_initial_N"] = peak_delta.tolist()
    groups.append(group)
validation = {name: json.loads((logs/name/"summary.json").read_text(encoding="utf-8"))
              for name in ("T0", "T0-standard", "lab-regression")}
assert all(v["passed"] for v in validation.values())
(logs/"notes.md").write_text("""# 执行边界

所有速度测量串行完成后才运行回归，未同时运行预览或测试。完整步测量包括极轻的求解结果列表收集；序列化/字节对照在计时后。初始化执行原真实物理，单独统计。

同版本重复有明显耗时波动，因此制动用ABBA；转向/凸起各A/B一次，只报告本批相对值，未拿LAB-PERF-01的历史绝对值拼接，也不作尾延迟或实时Gate。未修改CPU频率、亲和性、优先级或全局环境。

起初误用run_sim_double.py -c，参数解析拒绝，未执行物理；随后使用其支持的脚本入口。比较工具首次Ruff有导入空行和显式check参数两项，均已修正；物理对照无失败/超时。最终完整Ruff通过。

基线Git归档是LF，部分主目录文件是CRLF；源码范围审计归一换行后恰好六个物理模块不同，扩展二进制各次完全相同。没有更换旧SDK、旧DLL或历史版本来制造收益。

原比较工具result.config保存请求配置；实际LabExperiment按options将ESC关闭。原始报告未改，summary.groups.config按核对未改的正式配置构造代码重建实际值（唯一差别为ESC关闭）；requested_config另存。比较工具已改为今后直接保存run.config并分列requested_config，此修改仅报告元数据，不重跑速度测试。
""", encoding="utf-8")
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".log", ".txt", ".py", ".md", ".bin") and "user-data" not in path.parts:
            archive.write(path, path.relative_to(logs).as_posix())
    archive.write(root/"tools/performance/compare_lab_compute.py", "executed-comparison-tool.py")
summary = {"baseline": "4e9626230ec1a8f86e6b5f65873c7e824f9dbe92", "source_changes": source_changes,
           "native_sha256": native, "runtime": rows[0]["runtime"], "groups": groups,
           "raw_cases": rows, "validation": validation,
           "scope": "仅试验台独立轮心；原完整物理方程/配置/120Hz/两子步/阈值；未改游戏",
           "payload_definition": "全部快照(仅归一实例epoch)、信号、命令、每子步共同解全部字段(除含原生节点的contact_geometry)",
           "validation_counts": {"double_T0": 95, "standard_T0": 95, "double_lab_scoped_regression": 222},
           "formal_full_T1": "not_run: 用户限定只做试验台，不运行通用游戏seed；实验台专项完整模块/记录复算已完成",
           "T2_T3": "not_run", "human_gate": "pending", "real_time_gate": "open; offline throughput below real-time, formal gate not run",
           "raw_evidence_sha256": hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()}
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{k: g[k] for k in ("scenario", "wall_speedup", "cpu_speedup")} for g in groups], indent=2))
print("source/native/runtime/config/payload/normal-load/validation checks passed")
