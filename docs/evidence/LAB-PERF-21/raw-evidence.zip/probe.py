import dataclasses
import inspect
import json
import sys
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tests')]
import unsprung_joint as joint
import test_unsprung_joint as case
from lab_solver_validation import model_for,verify_result
from test_lab_joint_reuse import SCENARIOS
from vehicle_designs import REFERENCE_DESIGN

source=inspect.getsource(joint.solve_unsprung_joint)
old='''                plus,minus = values.copy(),values.copy()
                epsilon = 1e-5*scale
                plus[i] += epsilon
                minus[i] -= epsilon
                columns.append((evaluate(plus)[0]-evaluate(minus)[0])/(2*epsilon)*scale/row_scale)'''
new='''                plus = values.copy()
                epsilon = 1e-5*scale
                plus[i] += epsilon
                if jacobian_updates:
                    columns.append((evaluate(plus)[0]-residual)/epsilon*scale/row_scale)
                else:
                    minus = values.copy()
                    minus[i] -= epsilon
                    columns.append((evaluate(plus)[0]-evaluate(minus)[0])/(2*epsilon)*scale/row_scale)'''
assert source.count(old)==1
source=source.replace(old,new,1)
path=root/'logs/lab-perf-21/trial_solver.py';path.write_text(source,encoding='utf-8')
namespace=dict(vars(joint));exec(compile(source,str(path),'exec'),namespace)
trial=namespace['solve_unsprung_joint'];original=case.solve_unsprung_joint
rows=[]
try:
    for index,(changes,arguments) in enumerate(SCENARIOS):
        config=dataclasses.replace(REFERENCE_DESIGN,**changes)
        case.solve_unsprung_joint=original
        old_result=case.solve(config,**arguments)[0]
        def solve(*args,**kwargs):
            model=model_for(args,kwargs)
            result=trial(*args,**kwargs)
            checked.append(verify_result(model,result))
            return result
        checked=[];case.solve_unsprung_joint=solve
        result=case.solve(config,**arguments)[0]
        row={'case':index,'old_iterations':old_result.iterations,'new_iterations':result.iterations,'quality':checked,
             'velocity_max_abs_delta':float(abs(result.velocity-old_result.velocity).max()),
             'force_max_abs_delta':float(abs(result.forces-old_result.forces).max()),
             'old_energy_error':old_result.energy_error,'new_energy_error':result.energy_error}
        rows.append(row);print(row,flush=True)
        (root/'logs/lab-perf-21/probe-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
finally:case.solve_unsprung_joint=original
