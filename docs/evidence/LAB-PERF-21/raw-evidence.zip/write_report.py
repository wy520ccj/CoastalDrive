import json
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-21'
data=json.loads((folder/'summary.json').read_text(encoding='utf-8'));groups=data['groups']
metrics='/'.join(f"{g['wall_seconds_reduction_percent']:.2f}" for g in groups)
energy_delta=max(abs(r['sum_delta_J']) for r in data['energy_refinement'])
lines=['# 试验台首次Jacobian差分准备','',
'2026-10-16，基线b85bf10，主目录main，仅试验台；持续目标active。','',
'## 实现与数值边界','',
'LAB-PERF-20完整剖析中，21742次残差、7127次真实接触构型、288次首次Jacobian构造仍承担主要计算。每列中央差分需要正负两个额外残差，完整基点残差却已经算好。本块默认Jacobian更新路径改用(F(x+εeᵢ)−F(x))/ε，34列只需34次额外残差；ε仍为1e−5*state_scale[i]，原状态/残差缩放顺序不变。','',
'该差分只估计搜索方向，原完整残差决定每个候选步是否下降；后续Broyden割线更新、精确有限端口行、下降不足/旧矩阵失败重建、合格后校正、30轮/12次线搜索全部原文保持。原动量<1e−9 Ns、切向力<1e−5 N、端口<1e−9 Nm门槛不变，不以方向估计精度替代物理残差精度。','',
'jacobian_updates=False仍使用原完整中央差分Newton，原逐字节参照和旧预测1e−13/1e−9门槛不变。默认方法用冻结原方程和原能量结果段独立验证，不能再要求新旧算法完整输出逐字节一致；相同方法重跑仍逐字节一致。','',
'只改unsprung_joint.py中的差分准备分支。该分支之前的模型/基点准备、之后的Jacobian组装/求解/接受/能量段全文相同；evaluate/configuration/velocity_terms AST与独立冻结原模型一致。物理模型、真实几何、材料/碰撞、120Hz/双机械子步/34未知数和全部参数保持，五扩展及Panda1.10.16/Bullet285 Double SDK不变。','',
'## 同批完整物理步','',
'三个原工况各四个独立世界，逐拍ABBA/逆序正常前进；每个世界独立C轴向缓存与Python曲率缓存，绑定切换/序列化在计时外，初始化单列。A是冻结b85bf10的中央差分+Broyden，B是本轮前向差分+Broyden，两个路径都计算相同物理残差。','',
'| 工况 | 旧墙钟s | 新墙钟s | 耗时减少 | 旧CPU s | 新CPU s | CPU减少 |',
'|---|---:|---:|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['wall_seconds']:.6f} | {b['wall_seconds']:.6f} | {g['wall_seconds_reduction_percent']:.2f}% | {a['cpu_seconds']:.6f} | {b['cpu_seconds']:.6f} | {g['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','| 工况 | 旧P95 ms | 新P95 ms | 旧P99 ms | 新P99 ms |','|---|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['step_p95_seconds']*1000:.3f} | {b['step_p95_seconds']*1000:.3f} | {a['step_p99_seconds']*1000:.3f} | {b['step_p99_seconds']*1000:.3f} |")
lines+=['','CPU逐拍计数有Windows离散量化，短制动的CPU和墙钟可能交叉，原值保留，不据其差值推断等待时间；性能结论采用同批整步墙钟、物理/快照时间与尾延迟共同判断。机器绝对速度有波动，不跨历史批次相乘。实体凸起1.2模拟秒仍需3.309墙钟秒，尚未实时。','',
'| 工况 | A1初始化s | B1初始化s | B2初始化s | A2初始化s | 初始化拍数 |','|---|---:|---:|---:|---:|---:|']
for g in groups:
    initial=[r['initialization'] for r in g['rows']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{r['wall_seconds']:.3f}" for r in initial)+f" | {initial[0]['ticks']} |")
lines+=['','制动100km/h/.2s/24拍，首计算拍brake=1；转向30km/h/2°/.4s/48拍/onset=0；凸起18km/h/1.2s/144拍、2m位置/.4m长度、完整预载/安装曲线/非线性阻尼。台架拟合输入为合成部件数据，不代表实车标定。','',
'12次共864拍/1728子步，A各次与LAB-PERF-20实际文件逐字节相同，B两次也逐字节相同。新旧命令和全部离散物理状态相同，只有求解迭代数变化；连续字段差完整保存，未删除数值字段使其相同。仅归一实例epoch并排除含原生节点的contact_geometry引用，实际接触仍保留在快照。','',
'| 工况 | 位置最大差m | 共同速度最大差 | 接触力最大差N |','|---|---:|---:|---:|']
for g in groups:
    d=g['difference']['numeric_max_abs_deltas']
    lines.append(f"| {g['scenario']} | {d['payload.snapshots[].player.position[]']:.3e} | {d['payload.joint[].velocity']:.3e} | {d['payload.joint[].forces']:.3e} |")
lines+=['','## 独立残差、能量和较长工况','',
'独立试验18组输入先通过冻结原方程/能量复算，再将小改动用于正式源码。最终三个工况432个实际新子步逐一用冻结原模型、独立几何/运动缓存重算34残差，并用原能量结果段重算账本；全部原门槛通过，能量账复算差为0。独立检查运行的payload与速度实验B结果逐字节一致，诊断耗时不作收益。','',
'| 工况 | 旧/新峰值动量残差Ns | 旧/新峰值切向力残差N | 旧/新峰值能量误差J |','|---|---:|---:|---:|']
for g in groups:
    e=data['peak_residuals'][g['scenario']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{e[k]['A']:.3e} / {e[k]['B']:.3e}" for k in ('momentum_error','force_error','energy_error'))+' |')
lines+=['','残差峰值在浮点量级变化，不能把差分方向近似阶次直接当作最终物理精度；验收使用同一方程和原门槛。','',
'| 请求较长工况 | 旧/新实际拍数 | 旧/新子步数 | 结束原因 | 新峰值动量Ns | 新峰值力N |','|---|---:|---:|---|---:|---:|']
for case in data['stress']:
    a,b=case['runs']
    lines.append(f"| {case['case']} | {a['ticks']} / {b['ticks']} | {a['substeps']} / {b['substeps']} | {b['reason']} | {b['quality_max']['momentum_error']:.3e} | {b['quality_max']['force_error']:.3e} |")
stress_steps=sum(r['substeps'] for case in data['stress'] for r in case['runs'])
lines+=['',f'较长工况在相同拍停车，原命令与离散物理状态一致；旧/新共{stress_steps}个实际子步逐一独立验证同一原残差与能量账，全部通过，能量复算差0。各连续差/原因/时长保留原始证据；此运行含验证开销，不作性能收益。','',
'相同完整工程输入下，实际世界手动转向/油门/制动/离合，.12秒2/4/8子步能量细化：','',
'| 子步配置 | 旧累计能量残差J | 新累计能量残差J | 差J |','|---|---:|---:|---:|']
for r in data['energy_refinement']:
    lines.append(f"| {r['substeps']} | {r['old_sum_J']:.12f} | {r['new_sum_J']:.12f} | {r['sum_delta_J']:.3e} |")
lines+=['',f'六次共420个实际世界子步，累计能量差最大{energy_delta:.3e}J，保留原细化下降趋势。原真实世界能量积分误差/速度网格收敛等完整Gate仍开放，不能把方程残差检查当作该阶段通过。','',
'## 验证、工作量和来源','',
'保留LAB-PERF-20的65项默认方法原方程/能量、真实Box/平面、完整Newton逐位参照及旧Jacobian刷新错误检查；新增2项检查首次34维搜索矩阵在默认/完整Newton下实际使用35/69次残差（含基点），避免漏掉未知数或重复求基点。旧矩阵刷新检查的求值数界限按每次34扰动对应修改，物理残差门槛完全不变。','',
'初检141项/Ruff通过；最终普通/Double T0各155项、Double44模块759项完整试验台回归/Ruff、真实记录和旧检查点复算通过。旧预测文件1e−13/1e−9原阈值仍在显式完整Newton检查，默认方法独立检查原方程，未放宽旧阈值。本轮无物理数值测试失败。','',
f"完整凸起Jacobian仍{data['updated_solver_counts']['jacobian']}次，扰动从19584→9792，残差21742→{data['updated_solver_counts']['residual']}；割线更新791→{data['updated_solver_counts']['update']}，校正仍288次。没有丢失真实接触模型；减少的是构造方向矩阵时的重复扰动，新旧真实几何调用次数可以不同。",'',
'完整新剖析只用于计数与后续热点，profiled_solver.py原样归档，payload与速度B相同；旧剖析复用LAB-PERF-20并核对原源码LF/CRLF变体/五扩展与配置，未重复跑六拍或旧完整剖析。首个归档脚本的AST查找匹配到能量段enumerate而非差分循环，修正为指定i/scale循环后通过，原日志保留，未改生产代码或重跑速度实验。','',
'summary与raw-evidence.zip保留先验18组、完整性能12份payload/差异、432子步独立原方程检查、较长工况与实际世界能量细化、共享五扩展、旧新正式源码、冻结原模型/测试与执行脚本/日志。各次实际源路径和SHA核对，历史文件只用于证据。','',
'复现：项目Python tools/physics/run_sim_double.py logs/lab-perf-21/interleaved.py（须新输出目录与b85bf10冻结src/五扩展）；quality_worker.py、energy_refinement.py、stress.py分别复现独立方程、细化、较长工况；lab_regression.py跑专项。','',
'本块仅本地提交，持续目标active。游戏seed/window及通用T1/T2/T3未跑；完整模型/精度/能量、人工体验、实时及EPA部分旋转网格边缘拒绝仍开放。下一根据新完整剖析继续首次Jacobian与接触构型成本，测量后再确定更便宜的搜索方向准备。','']
(folder/'README.md').write_text('\n'.join(lines),encoding='utf-8')
(root/'docs/tasks/LAB-PERF-21.md').write_text(f'''# LAB-PERF-21 首次Jacobian差分准备

- 状态：done（本功能块）；基线b85bf10，main，本地提交；持续目标active。
- 默认更新路径用已算基点构造前向差分，34列只需34额外残差；jacobian_updates=False仍完整中央差分Newton。后续Broyden/精确端口行/接受/校正/30轮/12线搜索及原残差门槛原文保持。
- 只改unsprung_joint.py差分分支，五扩展/SDK/完整物理/120Hz/双机械子步/34未知数/碰撞/参数保持。不能宣称新旧算法输出逐字节相同；同方法重放精确、命令/离散状态一致，全部连续差保留。
- 三工况四世界逐拍交叉完整步墙钟−{metrics}%，P95/P99均降；1728性能子步。432实际新子步原方程/能量独立复算通过；较长停车{stress_steps}子步同门槛通过；实际世界2/4/8细化420子步保留原趋势，累计能量差最大{energy_delta:.3e}J。
- 新增2项首次矩阵实际求值数检查；普通/Double最终T0各155项、Double44模块759项完整专项/Ruff与真实记录/旧检查点复算通过。旧预测文件阈值不变，默认方法原模型独立验收。
- 完整凸起Jacobian288次/额外差分19584→9792、残差21742→{data['updated_solver_counts']['residual']}；更新{data['updated_solver_counts']['update']}、校正288。原方程AST/能量结尾及差分以外源码全文核对。
- [完整证据](../evidence/LAB-PERF-21/README.md)、summary.json、raw-evidence.zip包含参数/源码/扩展SHA/CPU/墙钟/尾延迟/初始化/完整差异/模型检查与复现脚本。
- 仍慢于实时，游戏seed/window及通用T1/T2/T3未跑，原精度/能量/人工/实时/EPA Gate保持开放。下一继续首次Jacobian与接触构型成本，不结束目标。
''',encoding='utf-8')
path=root/'docs/current-progress.md';text=path.read_text(encoding='utf-8')
start=text.index('当前施工仅试验台：');end=text.index('\n',start)
text=text[:start]+f'当前施工仅试验台：最新完成[LAB-PERF-21](tasks/LAB-PERF-21.md)首次Jacobian差分准备，默认利用原基点残差，三工况完整步再减{metrics}%；完整Newton中央差分保留，原物理/残差/门槛保持。432实际新子步原方程复算、较长停车与2/4/8能量细化、759项专项通过。持续目标active，仍慢于实时，下一首次Jacobian/真实接触成本。下列历史节点只支持各自版本/协议，最新收益以本块同批对照为准。'+text[end:]
text+=f'\n- [LAB-PERF-21 首次Jacobian准备](tasks/LAB-PERF-21.md)：b85bf10基线，默认方向矩阵用已算基点/每列单次扰动；同物理方程/收敛校正/门槛，显式完整Newton中央差分不变。三工况完整步−{metrics}%，1728性能子步各自精确重放、命令/离散状态一致；432实际新子步原模型/能量复算、较长停车{stress_steps}子步与实际世界420子步细化通过。普通/Double T0各155项，Double44模块759项/记录复算通过；本地提交，持续目标active，原精度/人工/实时/EPA Gate开放。\n'
path.write_text(text,encoding='utf-8')
print('report/task/progress written from verified measurements')
