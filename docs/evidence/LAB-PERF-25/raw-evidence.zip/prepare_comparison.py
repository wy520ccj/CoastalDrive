from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-24/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-24','lab-perf-25').replace('final-interleaved','base-interleaved')
source=source.replace("'box_baseline',baseline/'box_radial_geometry.py'","'radial_baseline',baseline/'radial_geometry.py'")
source=source.replace('old_box','old_radial').replace("sys.modules['box_baseline']","sys.modules['radial_baseline']")
source=source.replace('old_spec.loader.exec_module(old_radial)', 'old_spec.loader.exec_module(old_radial)\nold_radial.RadialHit=radial.RadialHit;old_radial.UnsprungGeometry=radial.UnsprungGeometry')
source=source.replace("new_only={'ordinary_small_norm','box_edge_proof'}","new_only={'radial_query_hits'}")
source=source.replace('old_curve=old_radial._axis_curvature\noriginal_radial_section=radial.box_section\n','')
source=source.replace('old_curve=old_radial._axis_curvature\noriginal_box_section=radial.box_section\n','')
source=source.replace('original_box_norm,original_surface_norm=box.small_norm,radial.small_norm','original_query=radial.RadialRoads.query')
source=source.replace('''    box.small_norm=np.linalg.norm if index in (0,3) else original_box_norm
    radial.small_norm=np.linalg.norm if index in (0,3) else original_surface_norm''','''    radial.RadialRoads.query=old_radial.RadialRoads.query if index in (0,3) else original_query''')
source=source.replace('    old_radial._axis_curvature=curvatures[index]\n','')
source=source.replace('    radial.box_section=old_radial.box_section if index in (0,3) else original_box_section\n','')
source=source.replace("# 两组共享当前支持源码；原范数别名与旧实际扩展来源另外记录。","# 两组共享当前支持源码；旧查询完整源码与实际扩展来源另外记录。")
source=source.replace("# 旧模式用完整冻结Box及原NumPy范数；求解器和普通叉积共用。","# 旧模式只切换冻结的完整查询，几何和求解器共用。")
source=source.replace('((old_curve if i in (0,3) else original_curve).__wrapped__)','(original_curve.__wrapped__)')
source=source.replace("root/'logs/lab-perf-23/base-interleaved'/scenario/'B1.bin'","root/'logs/lab-perf-24/final-interleaved'/scenario/'B1.bin'")
source=source.replace("'old_radial_source':str(baseline/'box_radial_geometry.py'),'old_radial_sha256':hashlib.sha256((baseline/'box_radial_geometry.py').read_bytes()).hexdigest(),'old_norm_reference_sources':{name:hashlib.sha256((baseline/name).read_bytes()).hexdigest() for name in ('radial_geometry.py','box_radial_geometry.py')}",
                      "'old_query_source':str(baseline/'radial_geometry.py'),'old_query_sha256':hashlib.sha256((baseline/'radial_geometry.py').read_bytes()).hexdigest()")
source=source.replace('        box.small_norm,radial.small_norm=original_box_norm,original_surface_norm','        radial.RadialRoads.query=original_query')
source=source.replace('        old_radial._axis_curvature=old_curve\n','').replace('        radial.box_section=original_box_section\n','')
assert 'old_curve' not in source and 'old_norm' not in source and 'original_box' not in source
assert source.count('old_query_source')==1
(root/'logs/lab-perf-25/interleaved.py').write_text(source,encoding='utf-8')
print('four-world complete-step crossover: frozen Python traversal versus native query traversal')
