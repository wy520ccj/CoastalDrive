import hashlib
import json
from pathlib import Path

root=Path.cwd();output=root/'logs/lab-perf-25/first-candidate';output.mkdir(exist_ok=False)
hashes={}
for name in ('lab_contact_native.h','wheel_contact_kernels.c','radial_geometry.py'):
    raw=(root/'src'/name).read_bytes();(output/name).write_bytes(raw);hashes[name]=hashlib.sha256(raw).hexdigest()
for path in (root/'src').glob('wheel_contact_kernels*.pyd'):
    raw=path.read_bytes();(output/path.name).write_bytes(raw);hashes[path.name]=hashlib.sha256(raw).hexdigest()
(output/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
source=(root/'logs/lab-perf-25/profile_worker.py').read_text(encoding='utf-8')
source=source.replace("output=root/'logs/lab-perf-25/profile-bump'","output=root/'logs/lab-perf-25/first-candidate/profile-bump'")
(output/'profile_worker.py').write_text(source,encoding='utf-8')
print('first traversal source/native frozen')
