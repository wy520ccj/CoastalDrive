"""三个原工况各四个独立世界逐拍交叉，完整推进/缓存独立/计时外序列化。"""
import dataclasses
import functools
import hashlib
import importlib.util
import json
import pickle
import sys
import time
import types
from pathlib import Path

import numpy as np

root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'logs/lab-perf-25')]
from compare_results import compare
import wheel_contact_kernels as current
import box_radial_geometry as box
import unsprung_joint as geometry
import vehicle_unsprung as vehicle
import radial_geometry as radial

from damper_bench_reference import document as bench_document

from lab_experiment import LabExperiment,LabOptions
from lab_runtime import runtime_fingerprint
from suspension_bench import fit_bench
from vehicle_designs import vehicle_design
from vehicle_parameters import config_from_document
from vehicle_unsprung import UnsprungAdvanceInput

output=root/'logs/lab-perf-25/final-interleaved'
output.mkdir(exist_ok=False)
baseline=root/'builds/lab-perf-25/baseline/src'
old_spec=importlib.util.spec_from_file_location('radial_baseline',baseline/'radial_geometry.py')
old_radial=importlib.util.module_from_spec(old_spec);sys.modules['radial_baseline']=old_radial
old_spec.loader.exec_module(old_radial)
old_radial.RadialHit=radial.RadialHit;old_radial.UnsprungGeometry=radial.UnsprungGeometry

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

old_path=next(baseline.glob('wheel_contact_kernels*.pyd'))
new_path=Path(current.__file__)
modules=(load('axis_a1.wheel_contact_kernels',old_path),current,
         load('axis_b2.wheel_contact_kernels',new_path),load('axis_a2.wheel_contact_kernels',old_path))
originals={name:value for name,value in vars(current).items() if isinstance(value,types.BuiltinFunctionType)}
new_only={'radial_query_hits'}
assert originals.keys()-vars(modules[0]).keys()==new_only
function_sets=tuple({name:vars(module)[name] for name in originals if name in vars(module)} for module in modules)
assert len({id(functions['box_axis_cache_info']) for functions in function_sets})==4
names_by_id={id(value):name for name,value in originals.items()}
bindings=[]
for module in list(sys.modules.values()):
    if not isinstance(module,types.ModuleType):continue
    path=vars(module).get('__file__')
    if path is None or (Path(path).resolve().parent!=root/'src' and module is not old_radial):continue
    for attribute,value in list(vars(module).items()):
        if id(value) in names_by_id:bindings.append((module,attribute,value,names_by_id[id(value)]))
labels=('A1','B1','B2','A2')
original_curve=box._axis_curvature
original_solver=geometry.solve_unsprung_joint
original_query=radial.RadialRoads.query
original_solve=UnsprungAdvanceInput.solve
def unused(*args):raise AssertionError('旧版完整接触求值不应执行新增C入口')
curvatures={}
def select(index):
    functions=function_sets[index]
    for module,attribute,original,name in bindings:
        setattr(module,attribute,unused if name in new_only and index in (0,3) else functions[name])
    vehicle.solve_unsprung_joint=original_solver
    radial.RadialRoads.query=old_radial.RadialRoads.query if index in (0,3) else original_query
    box._axis_curvature=curvatures[index]

document=json.loads((root/'docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json').read_text(encoding='utf-8'))
base_config=config_from_document(document,vehicle_design('reference-rwd').config)
scenarios={'braking':LabOptions(duration=.2),
           'turning':LabOptions(maneuver='step_steer',speed_kph=30.,duration=.4,onset=0.,steering_deg=2.),
           'nonlinear-bump':LabOptions(maneuver='ride_bump',speed_kph=18.,duration=1.2,bump_distance_m=2.,bump_length_m=.4)}
source_hashes={label:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix in ('.py','.c','.cpp','.h')}
               for label,source in (('A',baseline),('B',root/'src'))}
native={label:{p.stem.split('.')[0]:{'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
               for p in source.glob('*.pyd')} for label,source in (('A',baseline),('B',root/'src'))}
# 两组共享当前支持源码；旧查询完整源码与实际扩展来源另外记录。
source_hashes['A']=dict(source_hashes['B'])
# 旧模式只切换冻结的完整查询，几何和求解器共用。
for label in ('A','B'):
    for name in native[label]:
        actual=Path(sys.modules[name].__file__).resolve()
        if label=='A' and name=='wheel_contact_kernels':actual=old_path.resolve()
        native[label][name]={'path':str(actual),'sha256':hashlib.sha256(actual.read_bytes()).hexdigest()}
all_groups=[]
for scenario,options in scenarios.items():
    folder=output/scenario;folder.mkdir()
    for functions in function_sets:functions['box_axis_cache_info'](True)
    curvatures={i:functools.lru_cache(maxsize=512,typed=True)(original_curve.__wrapped__) for i in range(4)}
    config,metadata=base_config,document['metadata']
    if scenario=='nonlinear-bump':
        config,report=fit_bench(bench_document(),config);assert report['passed']
        metadata={'suspension_calibration':report,'basis':'合成部件数据，优化一致性对照，不代表实车标定'}
    runs=[];initial=[]
    captured=[[] for _ in labels];times=[[] for _ in labels];cpus=[[] for _ in labels]
    active=-1
    def solve(value,**kwargs):
        result=original_solve(value,**kwargs);captured[active].append(result)
        return result
    try:
        for index,label in enumerate(labels):
            select(index)
            before,cpu=time.perf_counter(),time.process_time()
            runs.append(LabExperiment(options,config=config,parameter_metadata=metadata))
            initial.append({'wall_seconds':time.perf_counter()-before,'cpu_seconds':time.process_time()-cpu,'ticks':runs[-1].current.tick})
            print(scenario,'INIT',label,initial[-1],flush=True)
        UnsprungAdvanceInput.solve=solve
        ticks=round(options.duration*120)
        for tick in range(ticks):
            for active in ((0,1,2,3) if tick%2==0 else (3,2,1,0)):
                select(active)
                before,cpu=time.perf_counter(),time.process_time()
                runs[active].step()
                used=time.process_time()-cpu;elapsed=time.perf_counter()-before
                times[active].append(elapsed);cpus[active].append(used)
            if tick%36==35:print(scenario,'TICK',tick+1,flush=True)
        expected_path=root/'logs/lab-perf-24/final-interleaved'/scenario/'B1.bin'
        expected=expected_path.read_bytes()
        rows=[]
        for index,(label,run) in enumerate(zip(labels,runs)):
            assert run.done and run.reason=='time_limit'
            snapshots=[dataclasses.replace(state,contact_epoch=0,impacts=tuple(dataclasses.replace(event,epoch=0) for event in state.impacts)) for state in run.snapshots]
            joint=[{field.name:getattr(result,field.name) for field in dataclasses.fields(result) if field.name!='contact_geometry'} for result in captured[index]]
            binary=pickle.dumps({'snapshots':snapshots,'samples':run.samples,'commands':run.commands,'joint':joint},protocol=5)
            (folder/(label+'.bin')).write_bytes(binary)
            assert binary==expected,(scenario,label)
            rows.append({'label':label,'wall_seconds':sum(times[index]),'cpu_seconds':sum(cpus[index]),'step_seconds':times[index],
                         'step_cpu_seconds':cpus[index],'initialization':initial[index],'substeps':len(joint),
                         'physics_snapshot_seconds':run.compute_seconds,'payload_sha256':hashlib.sha256(binary).hexdigest(),
                         'source_hashes':source_hashes[label[0]],'native':native[label[0]],
                         'support_cache':function_sets[index]['box_axis_cache_info'](),
                         'curvature_cache':dict(curvatures[index].cache_info()._asdict())})
        a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes()
        assert (folder/'A2.bin').read_bytes()==a and (folder/'B2.bin').read_bytes()==b
        difference=compare(pickle.loads(a),pickle.loads(b))
        assert not difference['changed_discrete_counts'] and all(v==0. for v in difference['numeric_max_abs_deltas'].values())
        assert pickle.loads(a)['commands']==pickle.loads(b)['commands']
        (folder/'difference.json').write_text(json.dumps(difference,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        group={'scenario':scenario,'options':dataclasses.asdict(options),'requested_config':dataclasses.asdict(config),
               'actual_config':dataclasses.asdict(runs[0].config),'runtime':runtime_fingerprint(),'rows':rows,'repeat_exact_within_method':True,'support_source_root':str(root/'src'),'old_query_source':str(baseline/'radial_geometry.py'),'old_query_sha256':hashlib.sha256((baseline/'radial_geometry.py').read_bytes()).hexdigest(),'difference':difference}
        group['measured']={}
        for label in ('A','B'):
            selected=[r for r in rows if r['label'].startswith(label)]
            steps=[dt for r in selected for dt in r['step_seconds']]
            group['measured'][label]={**{key:float(np.mean([r[key] for r in selected])) for key in ('wall_seconds','cpu_seconds','physics_snapshot_seconds')},
                                     'step_p95_seconds':float(np.percentile(steps,95)),'step_p99_seconds':float(np.percentile(steps,99))}
        for key in ('wall_seconds','cpu_seconds'):
            group[key+'_reduction_percent']=100*(1-group['measured']['B'][key]/group['measured']['A'][key])
        all_groups.append(group)
        (folder/'summary.json').write_text(json.dumps(group,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        (output/'summary.json').write_text(json.dumps({'groups':all_groups,'scope':'三工况逐拍ABBA/反序交叉，四个世界/原生缓存/曲率缓存独立，绑定切换及序列化在计时外'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(scenario,'EXACT',group['measured'],'wall reduction',group['wall_seconds_reduction_percent'],flush=True)
    finally:
        UnsprungAdvanceInput.solve=original_solve
        vehicle.solve_unsprung_joint=original_solver
        radial.RadialRoads.query=original_query
        box._axis_curvature=original_curve
        for module,attribute,original,name in bindings:setattr(module,attribute,original)
        for run in runs:run.close()
assert sum(row['substeps'] for group in all_groups for row in group['rows'])==1728
