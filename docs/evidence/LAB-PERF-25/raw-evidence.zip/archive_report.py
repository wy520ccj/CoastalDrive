"""核对完整旧查询、两候选真实来源和全部整步输出，归档限定证据。"""
import ast
import copy
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'logs/lab-perf-25')]
from compare_results import compare
from lab_runtime import runtime_fingerprint

logs=root/'logs/lab-perf-25';baseline=root/'builds/lab-perf-25/baseline/src'
output=root/'docs/evidence/LAB-PERF-25';output.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def source(path):return path.read_text(encoding='utf-8')
def dump(node):return ast.dump(node,include_attributes=False)
suffixes=('.py','.c','.h','.cpp')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['lab_contact_native.h','radial_geometry.py','wheel_contact_kernels.c']
header=source(root/'src/lab_contact_native.h')
assert header[:header.index('/* 仍按原轮心')]+header[header.rindex('#endif'):]==source(baseline/'lab_contact_native.h')
registration='    {"radial_query_hits",radial_query_hits_native,METH_VARARGS,"试验台真实查询候选按原序遍历与选择"},\n'
c=source(root/'src/wheel_contact_kernels.c');assert c.count(registration)==1
assert c.replace(registration,'')==source(baseline/'wheel_contact_kernels.c')
old,new=[ast.parse(source(p/'radial_geometry.py')) for p in (baseline,root/'src')]
for node in new.body:
    if isinstance(node,ast.ImportFrom) and node.module=='wheel_contact_kernels':node.names=[n for n in node.names if n.name!='radial_query_hits']
index=next(i for i,n in enumerate(old.body) if isinstance(n,ast.ImportFrom) and n.module=='vehicle_contacts')
new.body.insert(index,copy.deepcopy(old.body[index]))
queries=[next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='query' and any(isinstance(v,ast.arg) and v.arg=='surface_cache' for v in n.args.kwonlyargs)) for tree in (old,new)]
a,b=queries
old_hits=next(n for n in a.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='hits')
old_loop=next(n for n in a.body if isinstance(n,ast.For))
index=next(i for i,n in enumerate(b.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Tuple) and isinstance(n.targets[0].elts[0],ast.Name) and n.targets[0].elts[0].id=='touch')
b.body.insert(index,copy.deepcopy(old_hits))
index=next(i for i,n in enumerate(b.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='hits' and isinstance(n.value,ast.Call))
b.body[index]=copy.deepcopy(old_loop)
assert dump(old)==dump(new)
assert (root/'tests/lab_query_reference.py').read_bytes()==(baseline/'radial_geometry.py').read_bytes()
assert source(root/'src/vehicle_contacts.py')==source(baseline/'vehicle_contacts.py')

runtime=runtime_fingerprint();actual_sources={p.name:sha(p) for p in (root/'src').iterdir() if p.suffix in suffixes}
first_sources=dict(actual_sources)
for name in changes:first_sources[name]=sha(logs/'first-candidate'/name)
first_hashes=read(logs/'first-candidate/hashes.json')
assert all(sha(logs/'first-candidate'/name)==digest for name,digest in first_hashes.items())
baseline_native=read(logs/'native-copies.json');all_groups={};native={};quality={};substeps=0
for batch in ('base-interleaved','final-interleaved'):
    groups=read(logs/batch/'summary.json')['groups'];all_groups[batch]=groups;assert len(groups)==3
    for group in groups:
        scenario=group['scenario'];folder=logs/batch/scenario
        assert group['runtime']==runtime and group['repeat_exact_within_method']
        assert Path(group['support_source_root'])==root/'src'
        assert Path(group['old_query_source'])==baseline/'radial_geometry.py'
        assert group['old_query_sha256']==sha(baseline/'radial_geometry.py')
        expected=(root/'logs/lab-perf-24/final-interleaved'/scenario/'B1.bin').read_bytes()
        previous=read(root/'logs/lab-perf-24/final-interleaved'/scenario/'summary.json')
        assert group['options']==previous['options'] and group['actual_config']==previous['actual_config']
        a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes();assert a==b==expected
        difference=compare(pickle.loads(a),pickle.loads(b))
        assert difference==group['difference'] and not difference['changed_discrete_counts']
        assert all(v==0. for v in difference['numeric_max_abs_deltas'].values())
        for row in group['rows']:
            binary=folder/(row['label']+'.bin');assert binary.read_bytes()==expected and sha(binary)==row['payload_sha256']
            assert row['source_hashes']==(actual_sources if batch=='final-interleaved' else first_sources)
            assert row['substeps']==len(pickle.loads(expected)['joint']);substeps+=row['substeps']
            label=row['label'][0]
            if batch=='final-interleaved':native[label]=row['native']
            for name,data in row['native'].items():
                path=Path(data['path']);parent=baseline if label=='A' and name=='wheel_contact_kernels' else root/'src'
                assert path.parent==parent
                saved=logs/'first-candidate'/path.name if batch=='base-interleaved' and label=='B' and name=='wheel_contact_kernels' else path
                assert sha(saved)==data['sha256']
        independent=root/'logs/lab-perf-22/independent-model'/scenario
        quality[scenario]=read(independent/'quality.json');assert (independent/'payload.bin').read_bytes()==expected
        assert quality[scenario]['substeps']==len(pickle.loads(expected)['joint'])
        assert quality[scenario]['maxima']['energy_recompute_gap']==0.
        assert quality[scenario]['maxima']['momentum_error']<1e-9 and quality[scenario]['maxima']['force_error']<1e-5 and quality[scenario]['maxima']['port_error']<1e-9
assert substeps==3456 and sum(q['substeps'] for q in quality.values())==432
for name,digest in baseline_native.items():
    assert sha(baseline/name)==digest
    assert (sha(root/'src'/name)==digest)==(not name.startswith('wheel_contact_kernels.'))
for name in ('build-final.log','build-second.log'):
    build=source(logs/name)
    assert build.count('building ')==1 and "building 'wheel_contact_kernels'" in build and '/fp:strict' in build
validation={name:read(logs/name/'summary.json') for name in ('T0-final','T0-standard','lab-regression')}
assert all(v['passed'] for v in validation.values())
validation_counts={}
for name in validation:
    matches=re.findall(r'(\d+) passed',source(logs/name/'pytest.log'));assert len(matches)==1;validation_counts[name]=int(matches[0])
assert validation_counts=={'T0-final':139,'T0-standard':139,'lab-regression':972}
assert validation['lab-regression']['runtime']==runtime and len(validation['lab-regression']['tests'])==48
profile=read(logs/'profile-bump/profile.json');previous=read(root/'logs/lab-perf-24/profile-bump/profile.json')
first_profile=read(logs/'first-candidate/profile-bump/profile.json')
expected_counts={'residual':3486,'jacobian':8,'update':1311,'polish':288,'export_seed':288,'warm_seed':287}
assert profile['counts']==previous['counts']==first_profile['counts']==expected_counts
previous_EOL_variants={}
for label,folder in (('first',logs/'first-candidate/profile-bump'),('final',logs/'profile-bump')):
    assert (folder/'payload.bin').read_bytes()==(logs/'final-interleaved/nonlinear-bump/B1.bin').read_bytes()
    result=read(folder/'result.json');assert result['source_hashes']==(first_sources if label=='first' else actual_sources)
    prior=read(root/'logs/lab-perf-24/profile-bump/result.json');assert result['runtime']==prior['runtime']
    r=result['runtime'];assert (r['panda'],r['bullet'],r['scalar_bits'])==(runtime['panda_version'],runtime['bullet_version'],runtime['math_scalar_bits'])
    assert sha(Path(r['module']))==runtime['files']['panda3d/core.cp314-win_amd64.pyd']
    for name,data in result['native'].items():
        path=Path(data['path']);saved=logs/'first-candidate'/path.name if label=='first' and name=='wheel_contact_kernels' else path
        assert sha(saved)==data['sha256']
for name,data in prior['native'].items():assert baseline_native[Path(data['path']).name]==data['sha256']
for name,digest in prior['source_hashes'].items():
    raw=(baseline/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()==digest:continue
    lf=raw.replace(b'\r\n',b'\n');matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
    assert len(matched)==1,name;previous_EOL_variants[name]=matched[0]
profile_counts={}
for label,data in (('A',previous),('first',first_profile),('B',profile)):
    values={}
    for name,file in (('solve','_linalg.py'),('query','radial_geometry.py'),('_cached_plane','radial_geometry.py'),('query_plane','radial_geometry.py'),('box_section','box_radial_geometry.py'),('normal_material','unsprung_contact.py'),('read_mechanics','vehicle_unsprung.py'),('observe_unsprung','vehicle_unsprung.py'),('road_support','vehicle_contacts.py')):
        values[file+':'+name]=sum(r['calls'] for r in data['functions'] if r['function']==name and Path(r['file']).name==file)
    for name in ('radial_query_hits','box_cone_samples','box_cone_refine','box_edge_frames','radial_box_bounds'):
        values['native.'+name]=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.'+name+'>' in r['function'])
    profile_counts[label]=values
for key in profile_counts['A']:
    if key in ('native.radial_query_hits','vehicle_contacts.py:road_support'):continue
    assert profile_counts['A'][key]==profile_counts['B'][key]==profile_counts['first'][key],key
assert profile_counts['B']['native.radial_query_hits']==profile_counts['first']['native.radial_query_hits']==4960

with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.csv','.h','.c','.pyd') and 'user-data' not in path.parts and path.name!='archive-report.log':
            archive.write(path,path.relative_to(logs).as_posix())
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/baseline/'+path.name)
    for path in (root/'src').glob('wheel_contact_kernels*.pyd'):archive.write(path,'executed-native/current/'+path.name)
    for name in changes:archive.write(baseline/name,'executed-source/baseline/'+name)
    for path in (root/'logs/lab-perf-24/profile-bump').iterdir():
        if path.is_file():archive.write(path,'reused-baseline-profile/'+path.name)
    for scenario in quality:
        for name in ('quality.json','payload.bin'):
            path=root/'logs/lab-perf-22/independent-model'/scenario/name
            archive.write(path,'reused-equation-validation/'+scenario+'/'+name)
    for name in [*['src/'+name for name in changes],'src/unsprung_joint.py','src/vehicle_contacts.py','tests/test_lab_query_native.py','tests/lab_query_reference.py','tests/test_lab_surface_cache.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py','tools/performance/compare_lab_compute.py']:
        archive.write(root/name,'executed-source/'+name)
with zipfile.ZipFile(output/'raw-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
summary={'baseline':'53d3fa8','source_changes':changes,'groups':all_groups['final-interleaved'],'first_candidate_groups':all_groups['base-interleaved'],
         'substeps_in_final_performance':1728,'substeps_in_both_candidates':substeps,
         'support_source_hashes_are_context_not_old_binary_build_manifest':True,
         'old_mode':'shared current support/solver/geometry + frozen complete RadialRoads.query + baseline private wheel; separate caches/Jacobian per world',
         'old_binary_build_source':{name:sha(baseline/name) for name in ('wheel_contact_kernels.c','lab_contact_native.h')},
         'non_traversal_module_ast_exact':True,'old_C_calculation_prefix_exact':True,'comparisons':'original <= limit, normal[2] >= .5, strict < best through Python rich comparison; no cast before comparison',
         'first_candidate_saved_source_and_binary_hashes':first_hashes,'reused_baseline_profile_EOL_variants':previous_EOL_variants,'profile_counts':profile_counts,'solver_counts':expected_counts,
         'reused_432_substep_equation_validation':quality,'quality_scope':'22块已跑的432子步原方程/能量验证；本块两个候选所有实际payload逐字节相同。长工况/2,4,8细化未重跑。',
         'validation':validation,'validation_counts':validation_counts,'Double_T0_reused_final_identical_source':'T0-final;139项已通过，未重复运行',
         'native':native,'other_four_native_unchanged':True,'runtime':runtime,'current_source_hashes':actual_sources,
         'formal_T1_T2_T3':'not_run; Double48模块972项试验台专项及真实记录复算；游戏seed/window未跑',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('verified:',validation_counts,'substeps',substeps,'original source/native/output provenance exact')
print('profile counts:',profile_counts)
