from pathlib import Path

folder=Path('logs/lab-perf-25')
source=(folder/'interleaved.py').read_text(encoding='utf-8')
(folder/'first-candidate/interleaved.py').write_text(source,encoding='utf-8')
assert source.count("output=root/'logs/lab-perf-25/base-interleaved'")==1
source=source.replace("output=root/'logs/lab-perf-25/base-interleaved'","output=root/'logs/lab-perf-25/final-interleaved'")
(folder/'interleaved.py').write_text(source,encoding='utf-8')
print('second crossover: same physical traversal; single tuple materialization and direct method vectorcall')
