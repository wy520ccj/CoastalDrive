import json,sys
from pathlib import Path
root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import cProfile,pstats
from types import SimpleNamespace
from lab_experiment import LabExperiment
import compare_lab_compute

output=root/'logs/lab-perf-13/profile-bump'
profile=cProfile.Profile()
original=LabExperiment.step

def step(run):
    profile.enable()
    try:return original(run)
    finally:profile.disable()

LabExperiment.step=step
try:
    compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:
    LabExperiment.step=original
profile.dump_stats(str(output/'step.prof'))
with (output/'profile.txt').open('w',encoding='utf-8') as stream:
    stats=pstats.Stats(profile,stream=stream)
    stats.sort_stats('cumulative').print_stats(55)
    stats.sort_stats('tottime').print_stats(35)
rows=[{'file':path,'line':line,'function':function,'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for (path,line,function),v in stats.stats.items()]
(output/'profile.json').write_text(json.dumps({'ticks':144,'total_seconds':stats.total_tt,'functions':rows,'scope':'完整非线性实体凸起的独立诊断；分析器耗时不进入速度收益表'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-13/complete-AB/nonlinear-B/payload.bin').read_bytes()
print('bump profile physics payload exact')
