"""核对两候选全部整步输出和真实来源，确认原接触证明/求解保持。"""
import ast
import copy
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'logs/lab-perf-24')]
from compare_results import compare
from lab_runtime import runtime_fingerprint

logs=root/'logs/lab-perf-24';baseline=root/'builds/lab-perf-24/baseline/src'
output=root/'docs/evidence/LAB-PERF-24';output.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def source(path):return path.read_text(encoding='utf-8')
def dump(node):return ast.dump(node,include_attributes=False)
def function(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
suffixes=('.py','.c','.h','.cpp')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['box_radial_geometry.py','lab_contact_native.h','radial_geometry.py','unsprung_dynamics.py','wheel_contact_kernels.c']
header=source(root/'src/lab_contact_native.h')
assert header[:header.index('/* 二/三维')]+header[header.rindex('#endif'):]==source(baseline/'lab_contact_native.h')
c=source(root/'src/wheel_contact_kernels.c')
for registration in ('    {"box_edge_proof",box_edge_proof_native,METH_VARARGS,"试验台四棱原驻点界限批量准备"},\n',
                     '    {"ordinary_small_norm",ordinary_small_norm_native,METH_O,"接触几何二/三维原普通范数"},\n'):
    assert c.count(registration)==1;c=c.replace(registration,'')
assert c==source(baseline/'wheel_contact_kernels.c')

class OriginalNorm(ast.NodeTransformer):
    def visit_Call(self,node):
        self.generic_visit(node)
        if isinstance(node.func,ast.Name) and node.func.id=='small_norm':
            node.func=ast.Attribute(value=ast.Attribute(value=ast.Name(id='np',ctx=ast.Load()),attr='linalg',ctx=ast.Load()),attr='norm',ctx=ast.Load())
        return node

def original_module(path):
    tree=OriginalNorm().visit(ast.parse(source(path)))
    for node in tree.body:
        if isinstance(node,ast.ImportFrom):node.names=[n for n in node.names if n.name not in ('small_norm','ordinary_small_norm','box_edge_proof')]
    tree.body=[n for n in tree.body if not isinstance(n,ast.ImportFrom) or n.names]
    return tree

dynamics=original_module(root/'src/unsprung_dynamics.py');dynamics.body.remove(function(dynamics,'small_norm'))
assert dump(dynamics)==dump(ast.parse(source(baseline/'unsprung_dynamics.py')))
radial=original_module(root/'src/radial_geometry.py')
assert dump(radial)==dump(ast.parse(source(baseline/'radial_geometry.py')))
old=ast.parse(source(baseline/'box_radial_geometry.py'));new=original_module(root/'src/box_radial_geometry.py')
edge=function(new,'_edge_proof');new.body.remove(edge)
old_section=function(old,'box_section');new_section=function(new,'box_section')
old_row=next(n for n in ast.walk(old_section) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='row')
new_free=next(n for n in new_section.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='free')
new_free.body=[n for n in new_free.body if not (isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='edge_bounds')]
new_row=next(n for n in new_free.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='row')
new_row.body[0:1]=copy.deepcopy(old_row.body[:2])
index=next(i for i,n in enumerate(new_row.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Tuple) and isinstance(n.targets[0].elts[0],ast.Name) and n.targets[0].elts[0].id=='critical')
formulas=[next(n for n in old_row.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name) for name in ('critical','minimum_dot','maximum_dot')]
new_row.body[index:index+1]=copy.deepcopy(formulas)
assert dump(new)==dump(old)
fallback_loop=next(n for n in edge.body if isinstance(n,ast.For))
assert dump(fallback_loop.body[0])==dump(old_row.body[1])
assert all(dump(a)==dump(b) for a,b in zip(fallback_loop.body[1:4],formulas))
for target,name in (('lab_norm_box_reference.py','box_radial_geometry.py'),('lab_norm_radial_reference.py','radial_geometry.py')):
    assert (root/'tests'/target).read_bytes()==(baseline/name).read_bytes()

runtime=runtime_fingerprint();actual_sources={p.name:sha(p) for p in (root/'src').iterdir() if p.suffix in suffixes}
first_sources=dict(actual_sources)
for name in changes:first_sources[name]=sha(logs/'first-candidate'/name)
first_hashes=read(logs/'first-candidate/hashes.json')
assert all(sha(logs/'first-candidate'/name)==digest for name,digest in first_hashes.items())
baseline_native=read(logs/'native-copies.json');all_groups={};native={};quality={};substeps=0
for batch in ('base-interleaved','final-interleaved'):
    groups=read(logs/batch/'summary.json')['groups'];all_groups[batch]=groups;assert len(groups)==3
    for group in groups:
        scenario=group['scenario'];folder=logs/batch/scenario
        assert group['runtime']==runtime and group['repeat_exact_within_method']
        assert Path(group['support_source_root'])==root/'src'
        assert group['old_norm_reference_sources']=={name:sha(baseline/name) for name in ('radial_geometry.py','box_radial_geometry.py')}
        if batch=='final-interleaved':
            assert Path(group['old_box_source'])==baseline/'box_radial_geometry.py'
            assert group['old_box_sha256']==sha(baseline/'box_radial_geometry.py')
        expected=(root/'logs/lab-perf-23/base-interleaved'/scenario/'B1.bin').read_bytes()
        previous=read(root/'logs/lab-perf-23/base-interleaved'/scenario/'summary.json')
        assert group['options']==previous['options'] and group['actual_config']==previous['actual_config']
        a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes();assert a==b==expected
        difference=compare(pickle.loads(a),pickle.loads(b))
        assert difference==group['difference'] and not difference['changed_discrete_counts']
        assert all(v==0. for v in difference['numeric_max_abs_deltas'].values())
        for row in group['rows']:
            binary=folder/(row['label']+'.bin');assert binary.read_bytes()==expected and sha(binary)==row['payload_sha256']
            assert row['source_hashes']==(actual_sources if batch=='final-interleaved' else first_sources)
            assert row['substeps']==len(pickle.loads(expected)['joint']);substeps+=row['substeps']
            label=row['label'][0]
            if batch=='final-interleaved':native[label]=row['native']
            for name,data in row['native'].items():
                path=Path(data['path']);parent=baseline if label=='A' and name=='wheel_contact_kernels' else root/'src'
                assert path.parent==parent
                saved=logs/'first-candidate'/path.name if batch=='base-interleaved' and label=='B' and name=='wheel_contact_kernels' else path
                assert sha(saved)==data['sha256']
        independent=root/'logs/lab-perf-22/independent-model'/scenario
        quality[scenario]=read(independent/'quality.json');assert (independent/'payload.bin').read_bytes()==expected
        assert quality[scenario]['substeps']==len(pickle.loads(expected)['joint'])
        assert quality[scenario]['maxima']['energy_recompute_gap']==0.
        assert quality[scenario]['maxima']['momentum_error']<1e-9 and quality[scenario]['maxima']['force_error']<1e-5 and quality[scenario]['maxima']['port_error']<1e-9
assert substeps==3456 and sum(q['substeps'] for q in quality.values())==432
for name,digest in baseline_native.items():
    assert sha(baseline/name)==digest
    assert (sha(root/'src'/name)==digest)==(not name.startswith('wheel_contact_kernels.'))
for name in ('build-initial.log','build-final.log'):
    build=source(logs/name)
    assert build.count('building ')==1 and "building 'wheel_contact_kernels'" in build and '/fp:strict' in build

validation={name:read(logs/name/'summary.json') for name in ('second-fixed','T0-standard','lab-regression')}
assert all(v['passed'] for v in validation.values())
validation_counts={}
validation_log_encodings={'second-fixed':'utf-8','T0-standard':'utf-8','lab-regression':'gbk'}
for name in validation:
    text=(logs/name/'pytest.log').read_text(encoding=validation_log_encodings[name])
    matches=re.findall(r'(\d+) passed',text);assert len(matches)==1;validation_counts[name]=int(matches[0])
assert validation_counts=={'second-fixed':124,'T0-standard':124,'lab-regression':902}
assert validation['lab-regression']['runtime']==runtime and len(validation['lab-regression']['tests'])==47
profile=read(logs/'profile-bump/profile.json');previous=read(root/'logs/lab-perf-23/profile-bump/profile.json')
expected_counts={'residual':3486,'jacobian':8,'update':1311,'polish':288,'export_seed':288,'warm_seed':287}
assert profile['counts']==previous['counts']==expected_counts
assert (logs/'profile-bump/payload.bin').read_bytes()==(logs/'final-interleaved/nonlinear-bump/B1.bin').read_bytes()
profile_result=read(logs/'profile-bump/result.json');previous_result=read(root/'logs/lab-perf-23/profile-bump/result.json')
assert profile_result['source_hashes']==actual_sources and profile_result['runtime']==previous_result['runtime']
profile_runtime=profile_result['runtime']
assert (profile_runtime['panda'],profile_runtime['bullet'],profile_runtime['scalar_bits'])==(runtime['panda_version'],runtime['bullet_version'],runtime['math_scalar_bits'])
assert sha(Path(profile_runtime['module']))==runtime['files']['panda3d/core.cp314-win_amd64.pyd']
for name,data in previous_result['native'].items():assert baseline_native[Path(data['path']).name]==data['sha256']
for name,data in profile_result['native'].items():assert sha(Path(data['path']))==data['sha256']
previous_EOL_variants={}
for name,digest in previous_result['source_hashes'].items():
    raw=(baseline/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()==digest:continue
    lf=raw.replace(b'\r\n',b'\n');matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
    assert len(matched)==1,name;previous_EOL_variants[name]=matched[0]
profile_counts={}
for label,data in (('A',previous),('B',profile)):
    values={}
    for name,file in (('norm','_linalg.py'),('solve','_linalg.py'),('query','radial_geometry.py'),('box_section','box_radial_geometry.py'),('normal_material','unsprung_contact.py'),('read_mechanics','vehicle_unsprung.py'),('observe_unsprung','vehicle_unsprung.py')):
        values[file+':'+name]=sum(r['calls'] for r in data['functions'] if r['function']==name and Path(r['file']).name==file)
    for name in ('box_cone_samples','box_cone_refine','box_edge_frames','box_edge_proof','ordinary_small_norm','radial_box_bounds'):
        values['native.'+name]=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.'+name+'>' in r['function'])
    profile_counts[label]=values
for key in profile_counts['A']:
    if key in ('_linalg.py:norm','native.box_edge_proof','native.ordinary_small_norm'):continue
    assert profile_counts['A'][key]==profile_counts['B'][key],key
assert profile_counts['A']['_linalg.py:norm']==83346 and profile_counts['B']['_linalg.py:norm']==14574
assert profile_counts['B']['native.box_edge_proof']==3394 and profile_counts['B']['native.ordinary_small_norm']==34832

with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.csv','.h','.c','.pyd') and 'user-data' not in path.parts and path.name!='archive-report.log':
            archive.write(path,path.relative_to(logs).as_posix())
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/baseline/'+path.name)
    for path in (root/'src').glob('wheel_contact_kernels*.pyd'):archive.write(path,'executed-native/current/'+path.name)
    for name in changes:archive.write(baseline/name,'executed-source/baseline/'+name)
    for path in (root/'logs/lab-perf-23/profile-bump').iterdir():
        if path.is_file():archive.write(path,'reused-baseline-profile/'+path.name)
    for scenario in quality:
        for name in ('quality.json','payload.bin'):
            path=root/'logs/lab-perf-22/independent-model'/scenario/name
            archive.write(path,'reused-equation-validation/'+scenario+'/'+name)
    for name in [*['src/'+name for name in changes],'src/unsprung_joint.py','tests/test_lab_small_norm.py','tests/lab_norm_box_reference.py','tests/lab_norm_radial_reference.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py','tools/performance/compare_lab_compute.py']:
        archive.write(root/name,'executed-source/'+name)
with zipfile.ZipFile(output/'raw-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
summary={'baseline':'0cf9585','source_changes':changes,'groups':all_groups['final-interleaved'],'first_candidate_groups':all_groups['base-interleaved'],
         'substeps_in_final_performance':1728,'substeps_in_both_candidates':substeps,
         'support_source_hashes_are_context_not_old_binary_build_manifest':True,
         'old_mode':'shared current support/solver/cross + frozen complete Box function + original NumPy norm aliases + baseline private wheel; separate curvature/cache per world',
         'old_binary_build_source':{name:sha(baseline/name) for name in ('wheel_contact_kernels.c','lab_contact_native.h')},
         'original_norm_and_box_proof_ast_verified':True,'old_C_calculation_prefix_exact':True,
         'first_candidate_saved_source_and_binary_hashes':first_hashes,
         'reused_baseline_profile_EOL_variants':previous_EOL_variants,'profile_counts':profile_counts,'solver_counts':expected_counts,
         'reused_432_substep_equation_validation':quality,'quality_scope':'22块已跑的432子步原方程/能量验证；本块两个候选所有实际payload逐字节相同。较长停车和2,4,8细化未重跑，不宣称本版新增覆盖。',
         'validation':validation,'validation_counts':validation_counts,'validation_log_encodings':validation_log_encodings,'Double_T0_reused_final_identical_source':'second-fixed;124项已通过，未重复运行',
         'native':native,'other_four_native_unchanged':True,'runtime':runtime,'current_source_hashes':actual_sources,
         'formal_T1_T2_T3':'not_run; Double47模块902项试验台专项及真实记录复算；游戏seed/window未跑',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('verified:',validation_counts,'substeps',substeps,'original AST/native/output provenance exact')
print('profile counts:',profile_counts)
