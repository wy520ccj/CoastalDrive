import hashlib
import json
from pathlib import Path

root=Path.cwd();output=root/'logs/lab-perf-24/first-candidate';output.mkdir(exist_ok=False)
hashes={}
for name in ('lab_contact_native.h','wheel_contact_kernels.c','unsprung_dynamics.py','box_radial_geometry.py','radial_geometry.py'):
    raw=(root/'src'/name).read_bytes();(output/name).write_bytes(raw);hashes[name]=hashlib.sha256(raw).hexdigest()
for path in (root/'src').glob('wheel_contact_kernels*.pyd'):
    raw=path.read_bytes();(output/path.name).write_bytes(raw);hashes[path.name]=hashlib.sha256(raw).hexdigest()
(output/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print('first candidate source/native saved; original complete-step results remain in base-interleaved')
