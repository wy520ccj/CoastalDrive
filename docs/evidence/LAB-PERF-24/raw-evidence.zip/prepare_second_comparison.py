from pathlib import Path

root=Path.cwd();folder=root/'logs/lab-perf-24'
source=(folder/'interleaved.py').read_text(encoding='utf-8')
(folder/'first-candidate/interleaved.py').write_text(source,encoding='utf-8')
source=source.replace("output=root/'logs/lab-perf-24/base-interleaved'","output=root/'logs/lab-perf-24/final-interleaved'")
source=source.replace("baseline=root/'builds/lab-perf-24/baseline/src'",'''baseline=root/'builds/lab-perf-24/baseline/src'
old_spec=importlib.util.spec_from_file_location('box_baseline',baseline/'box_radial_geometry.py')
old_box=importlib.util.module_from_spec(old_spec);sys.modules['box_baseline']=old_box
old_spec.loader.exec_module(old_box)''')
source=source.replace("new_only={'ordinary_small_norm'}","new_only={'ordinary_small_norm','box_edge_proof'}")
source=source.replace("if path is None or Path(path).resolve().parent!=root/'src':continue", "if path is None or (Path(path).resolve().parent!=root/'src' and module is not old_box):continue")
source=source.replace('original_curve=box._axis_curvature','original_curve=box._axis_curvature\nold_curve=old_box._axis_curvature\noriginal_box_section=radial.box_section')
source=source.replace('    box._axis_curvature=curvatures[index]','    box._axis_curvature=curvatures[index]\n    old_box._axis_curvature=curvatures[index]\n    radial.box_section=old_box.box_section if index in (0,3) else original_box_section')
source=source.replace('curvatures={i:functools.lru_cache(maxsize=512,typed=True)(original_curve.__wrapped__) for i in range(4)}',
                      'curvatures={i:functools.lru_cache(maxsize=512,typed=True)((old_curve if i in (0,3) else original_curve).__wrapped__) for i in range(4)}')
source=source.replace("'old_norm_reference_sources':", "'old_box_source':str(baseline/'box_radial_geometry.py'),'old_box_sha256':hashlib.sha256((baseline/'box_radial_geometry.py').read_bytes()).hexdigest(),'old_norm_reference_sources':")
source=source.replace('        box._axis_curvature=original_curve','        box._axis_curvature=original_curve\n        old_box._axis_curvature=old_curve\n        radial.box_section=original_box_section')
source=source.replace('# 旧模式仅切换为原NumPy范数，求解器和普通叉积完全共用。','# 旧模式用完整冻结Box及原NumPy范数；求解器和普通叉积共用。')
assert source.count('old_box.box_section if')==1
(folder/'interleaved.py').write_text(source,encoding='utf-8')
print('final crossover: frozen complete Box/original norms versus batched edge bounds/native norms')
