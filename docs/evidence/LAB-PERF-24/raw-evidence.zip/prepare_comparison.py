from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-23/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-23','lab-perf-24')
source=source.replace('import unsprung_body as body','import radial_geometry as radial')
start=source.index('old_spec=importlib.util.spec_from_file_location')
end=source.index('\ndef load(',start)
source=source[:start]+source[end:]
source=source.replace("new_only={'ordinary_cross_rows'}","new_only={'ordinary_small_norm'}")
source=source.replace("(Path(path).resolve().parent!=root/'src' and module is not old_geometry)","Path(path).resolve().parent!=root/'src'")
source=source.replace('original_observe,original_read=vehicle.observe_unsprung,vehicle.read_mechanics\noriginal_body_cross,original_vehicle_cross=body.ordinary_cross,vehicle.ordinary_cross',
                      'original_box_norm,original_surface_norm=box.small_norm,radial.small_norm')
source=source.replace('''    vehicle.observe_unsprung=old_geometry.observe_unsprung if index in (0,3) else original_observe
    vehicle.read_mechanics=old_geometry.read_mechanics if index in (0,3) else original_read
    body.ordinary_cross=np.cross if index in (0,3) else original_body_cross
    vehicle.ordinary_cross=np.cross if index in (0,3) else original_vehicle_cross''','''    box.small_norm=np.linalg.norm if index in (0,3) else original_box_norm
    radial.small_norm=np.linalg.norm if index in (0,3) else original_surface_norm''')
source=source.replace('# 两组共享当前支持源码；旧读取/观测源码和实际扩展路径另外记录。','# 两组共享当前支持源码；原范数别名与旧实际扩展来源另外记录。')
source=source.replace('# 旧模式仅切换叉积实现与观测/读取函数，当前求解器完全共用。','# 旧模式仅切换为原NumPy范数，求解器和普通叉积完全共用。')
source=source.replace("root/'logs/lab-perf-22/base-interleaved'/scenario/'B1.bin'","root/'logs/lab-perf-23/base-interleaved'/scenario/'B1.bin'")
source=source.replace("'old_observer_source':str(baseline/'vehicle_unsprung.py'),'old_observer_sha256':hashlib.sha256((baseline/'vehicle_unsprung.py').read_bytes()).hexdigest()",
                      "'old_norm_reference_sources':{name:hashlib.sha256((baseline/name).read_bytes()).hexdigest() for name in ('radial_geometry.py','box_radial_geometry.py')}")
source=source.replace('''        vehicle.observe_unsprung,vehicle.read_mechanics=original_observe,original_read
        body.ordinary_cross,vehicle.ordinary_cross=original_body_cross,original_vehicle_cross''','''        box.small_norm,radial.small_norm=original_box_norm,original_surface_norm''')
assert 'old_geometry' not in source and 'ordinary_cross_rows' not in source and 'old_observer' not in source
(root/'logs/lab-perf-24/interleaved.py').write_text(source,encoding='utf-8')
print('four-world complete-step crossover: exact original NumPy norms versus native small norms')
