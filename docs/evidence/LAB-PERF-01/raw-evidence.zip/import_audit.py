import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
if len(sys.argv) == 1:
    sources = [root, *sorted((root/"builds/lab-perf-01").glob("*/src"))]
    results = []
    for path in sources:
        source = path.parent if path.name == "src" else path
        data = json.loads(subprocess.check_output([sys.executable, __file__, str(source)], encoding="utf-8"))
        matching = [p for p in (root/"logs/lab-perf-01").glob("*/result.json")
                    if Path(json.loads(p.read_text(encoding="utf-8"))["source"]) == source]
        for recorded in matching:
            hashes = json.loads(recorded.read_text(encoding="utf-8"))["source_hashes"]
            assert all(hashes[Path(row["path"]).name] == row["sha256"] for row in data.values())
        results.append({"source": str(source), "modules": data,
                        "matching_recorded_results": [p.parent.name for p in matching]})
    (root/"logs/lab-perf-01/import-audit.json").write_text(json.dumps(results, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print("imports and extension hashes verified for", len(results), "sources")
else:
    source = Path(sys.argv[1]).resolve()
    sys.path.insert(0, str(source/"src"))
    import lab_experiment
    modules = {name: Path(sys.modules[name].__file__).resolve()
               for name in ("physics_packet_kernels", "mechanical_kernels", "wheel_contact_kernels",
                            "convex_cast_kernels", "radial_contact_kernels") if name in sys.modules}
    assert all(path.parent == source/"src" for path in modules.values())
    print(json.dumps({name: {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                      for name, path in modules.items()}))
