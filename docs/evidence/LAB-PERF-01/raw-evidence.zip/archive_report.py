import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
logs = root/"logs/lab-perf-01"
output = root/"docs/evidence/LAB-PERF-01"
output.mkdir(parents=True, exist_ok=True)
results = {p.parent.name: json.loads(p.read_text(encoding="utf-8"))
           for p in logs.glob("*/result.json")}
assert len(results) == 16
for name in ("run-status", "clean-run-status"):
    assert all(row["exit_code"] == 0 for row in json.loads((logs/(name+".json")).read_text(encoding="utf-8")))
assert all(v["measured"]["ticks"] == 24 for v in results.values())
reference = results["6306801-clean"]["config"]
differences = {}
for name, result in results.items():
    config = result["config"]
    common = {k: [reference[k], config[k]] for k in reference.keys() & config.keys()
              if reference[k] != config[k]}
    if "normal" in name:
        assert common == {"unsprung_enabled": [True, False]}
    else:
        assert common == {}
    added = {k: config[k] for k in config.keys() - reference.keys()}
    assert not added or added == {"suspension_coil_enabled": False,
                                 "suspension_spring_preloads": [0.]*4,
                                 "suspension_installation_curves": None,
                                 "suspension_damper_curves": None}
    differences[name] = {"changed_common": common, "added": added}
instrument = results["current-instrument-32"]
assert instrument["snapshot_hashes"] == results["current-32"]["snapshot_hashes"]
assert instrument["joint_iterations"] == [3]*48
selected = ["6306801-normal-clean", "6306801-clean", "2d45293-clean", "f2df8d0-clean",
            "c058cc4-32", "c058cc4-64", "dd1c9bf-32", "dd1c9bf-64", "current-32",
            "current-double-clean", "current-instrument-32"]
cases = []
for name in selected:
    v = results[name]
    measured = v["measured"]
    cases.append({"case": name, "runtime": v["runtime"], "initialization": v["initialization"],
                  "measured": measured,
                  "step_p95_seconds": float(np.percentile(measured["step_seconds"], 95)),
                  "step_p99_seconds": float(np.percentile(measured["step_seconds"], 99)),
                  "simulated_seconds": measured["ticks"]/120})
commits = {ref: subprocess.check_output(["git", "rev-parse", ref], text=True).strip()
           for ref in ("6306801", "2d45293", "f2df8d0", "c058cc4", "dd1c9bf", "0944541", "d8679c5")}
hotspots = ["src/vehicle_unsprung.py", "src/unsprung_joint.py", "src/unsprung_contact.py",
            "src/unsprung_contact_geometry.py", "src/unsprung_motion.py", "src/radial_geometry.py"]
assert subprocess.check_output(["git", "diff", "0944541", "d8679c5", "--", *hotspots]) == b""
assert subprocess.check_output(["git", "log", "--oneline", "6306801..d8679c5", "--", "vendor"]) == b""
import_audit = json.loads((logs/"import-audit.json").read_text(encoding="utf-8"))
assert len(import_audit) == 7
profile = json.loads((logs/"current-double/profile.json").read_text(encoding="utf-8"))
summary = {"baseline": commits["d8679c5"], "commits": commits,
           "protocol": {"engineering": "docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json",
                        "engineering_sha256": hashlib.sha256((root/"docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json").read_bytes()).hexdigest(),
                        "options": results["current-32"]["options"],
                        "config": results["current-32"]["config"],
                        "ticks": 24, "physics_hz": 120, "mechanical_substeps": 2,
                        "same_protocol_not_same_physics_across_revisions": True,
                        "initialization_included_in_step_timing": False,
                        "gpu_ui_in_step_timing": False},
           "cases": cases, "config_differences": differences,
           "instrumentation": {"inclusive_timings": instrument["inclusive_timings"],
                               "joint_iterations": instrument["joint_iterations"],
                               "snapshots_exactly_equal_to_uninstrumented": True,
                               "percentages_overlap_do_not_add": True},
           "profile": {"ticks": 6, "total_seconds": profile["total_seconds"],
                       "functions": sorted(profile["functions"], key=lambda r: -r["cumulative_seconds"])[:24],
                       "overhead_excluded_from_revision_timings": True},
           "integrity": {"hotspot_sources_same_as_0944541": hotspots, "vendor_unchanged": True,
                         "native_import_audit": import_audit},
           "environment": {"previous_preview_pids": [25268, 12656],
                           "preview_observed_cpu_seconds_per_two_wall_seconds": 1.82,
                           "preview_closed_local_time": "2026-10-15T15:31:52.5804411+08:00",
                           "key_transitions_retested_after_preview_closed": True,
                           "initial_five_historical_builds_plus_one_unused_a71_build": "all six exited zero"},
           "limits": ["每项仅24拍，P95/P99只描述这个短样本，不作实时或尾延迟Gate",
                      "首批6306801/2d45293/f2df8d0及current-double有先前测试预览竞争，原数据保留；关键点使用clean补测",
                      "c058cc4的32位首测处在关闭预览的时间附近，仅作量级交叉参考；当前32/64和dd1c9bf配对无该预览",
                      "不同物理版本不宣称相同结果；同版本开关对照只是定位机制成本，未修改产品默认",
                      "未逐个细分f2df8d0之后约10-15%的剩余增量；未实施优化或重跑功能T1/T2/T3"]}
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(logs).as_posix())
summary["raw_evidence_sha256"] = hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{"case": r["case"], "wall": r["measured"]["wall_seconds"],
                   "cpu": r["measured"]["cpu_seconds"], "p95_ms": r["step_p95_seconds"]*1000}
                  for r in cases], indent=2))
