import dataclasses
import math

import numpy as np

def compare(old,new):
    deltas={};discrete={}
    def walk(a,b,path):
        if dataclasses.is_dataclass(a):
            assert dataclasses.is_dataclass(b)
            for field in dataclasses.fields(a):walk(getattr(a,field.name),getattr(b,field.name),path+'.'+field.name)
        elif isinstance(a,np.ndarray):
            assert isinstance(b,np.ndarray) and a.dtype==b.dtype and a.shape==b.shape,path
            value=float(np.max(np.abs(a-b))) if a.size else 0.
            deltas[path]=max(deltas.get(path,0.),value)
        elif isinstance(a,(tuple,list)):
            assert type(a) is type(b) and len(a)==len(b),path
            for x,y in zip(a,b):walk(x,y,path+'[]')
        elif isinstance(a,dict):
            assert a.keys()==b.keys(),path
            for name in a:walk(a[name],b[name],path+'.'+name)
        elif isinstance(a,(float,np.floating)):
            assert math.isfinite(a) and math.isfinite(b),path
            deltas[path]=max(deltas.get(path,0.),abs(float(a)-float(b)))
        elif a!=b:
            discrete[path]=discrete.get(path,0)+1
    walk(old,new,'payload')
    return {'numeric_max_abs_deltas':deltas,'changed_discrete_counts':discrete}
