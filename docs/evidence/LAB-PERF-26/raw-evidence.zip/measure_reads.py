"""完整三个原工况逐个记录真实read内三次查询，诊断计时不作速度收益。"""
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import compare_lab_compute
from lab_experiment import LabExperiment
from radial_geometry import RadialRoads
from vehicle_unsprung import UnsprungAdvanceInput

old_read,old_query,old_step=UnsprungAdvanceInput.read,RadialRoads.query,LabExperiment.step
active=None;measured=False;rows=[]
def arrays(*values):
    return tuple((a.dtype.str,a.shape,a.strides,a.tobytes()) for a in map(np.asarray,values))
def geometry(value):
    hits=tuple(None if h is None else (h.node,*arrays(h.point,h.normal),h.plane) for h in value.hits)
    return hits,arrays(value.deflection,value.offsets,value.normals,value.tangents,value.laterals,value.normal_offsets)
def query(self,centers,up,axes,**kwargs):
    before=time.perf_counter();result=old_query(self,centers,up,axes,**kwargs);elapsed=time.perf_counter()-before
    if active is not None:active.append((arrays(centers,up,axes),geometry(result),elapsed))
    return result
@classmethod
def read(cls,*args,**kwargs):
    global active
    if not measured:return old_read(*args,**kwargs)
    active=[]
    try:
        result=old_read(*args,**kwargs);assert len(active)==3
        first,initial,target=active
        rows.append({'target_inputs_exact':first[0]==target[0],'target_outputs_exact':first[1]==target[1],
                     'initial_inputs_exact':first[0]==initial[0],'initial_outputs_exact':first[1]==initial[1],
                     'query_seconds':[row[2] for row in active]})
        return result
    finally:active=None
def step(run):
    global measured
    measured=True
    try:return old_step(run)
    finally:measured=False
RadialRoads.query=query;UnsprungAdvanceInput.read=read;LabExperiment.step=step
groups=[]
try:
    for scenario in ('braking','turning','nonlinear-bump'):
        rows=[];folder=root/'logs/lab-perf-26/read-measurement'/scenario
        compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=folder))
        assert (folder/'payload.bin').read_bytes()==(root/'logs/lab-perf-25/final-interleaved'/scenario/'B1.bin').read_bytes()
        assert all(r['target_inputs_exact'] and r['target_outputs_exact'] for r in rows)
        assert all(r['initial_outputs_exact'] for r in rows if r['initial_inputs_exact'])
        group={'scenario':scenario,'substeps':len(rows),'rows':rows,
               'target_exact':sum(r['target_inputs_exact'] for r in rows),'initial_exact':sum(r['initial_inputs_exact'] for r in rows)}
        groups.append(group)
        print(scenario,len(rows),'target',group['target_exact'],'initial',group['initial_exact'],flush=True)
finally:RadialRoads.query=old_query;UnsprungAdvanceInput.read=old_read;LabExperiment.step=old_step
(root/'logs/lab-perf-26/read-measurement/summary.json').write_text(json.dumps({'groups':groups,'diagnostic_only':True},indent=2)+'\n',encoding='utf-8')
