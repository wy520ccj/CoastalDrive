from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-25/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-25','lab-perf-26').replace('final-interleaved','base-interleaved')
source=source.replace('import radial_geometry as radial','import radial_geometry as radial\nimport unsprung_contact_geometry as contact')
start=source.index("old_spec=importlib.util.spec_from_file_location")
end=source.index('\ndef load(',start)
source=source[:start]+'''old_spec=importlib.util.spec_from_file_location('vehicle_baseline',baseline/'vehicle_unsprung.py')
old_vehicle=importlib.util.module_from_spec(old_spec);sys.modules['vehicle_baseline']=old_vehicle
old_spec.loader.exec_module(old_vehicle)
old_spec=importlib.util.spec_from_file_location('contact_baseline',baseline/'unsprung_contact_geometry.py')
old_contact=importlib.util.module_from_spec(old_spec);sys.modules['contact_baseline']=old_contact
old_spec.loader.exec_module(old_contact)
assert old_vehicle.FiniteRadialContact is contact.FiniteRadialContact
'''+source[end:]
source=source.replace("new_only={'radial_query_hits'}","new_only=set()")
source=source.replace('module is not old_radial','module not in (old_vehicle,old_contact)')
source=source.replace('original_query=radial.RadialRoads.query',"original_read=UnsprungAdvanceInput.__dict__['read']\noriginal_init=contact.FiniteRadialContact.__init__")
source=source.replace('    radial.RadialRoads.query=old_radial.RadialRoads.query if index in (0,3) else original_query',
                      '''    UnsprungAdvanceInput.read=classmethod(old_vehicle.UnsprungAdvanceInput.read.__func__) if index in (0,3) else original_read
    contact.FiniteRadialContact.__init__=old_contact.FiniteRadialContact.__init__ if index in (0,3) else original_init''')
source=source.replace('# 两组共享当前支持源码；旧查询完整源码与实际扩展来源另外记录。','# 两组共享其他支持代码，旧读取/有限接触构造源码与实际扩展另列。')
source=source.replace('# 旧模式只切换冻结的完整查询，几何和求解器共用。','# 旧模式执行原读取和原构造，所有几何算法/共同解共用。')
source=source.replace("root/'logs/lab-perf-24/base-interleaved'/scenario/'B1.bin'","root/'logs/lab-perf-25/final-interleaved'/scenario/'B1.bin'")
source=source.replace("root/'logs/lab-perf-24/final-interleaved'/scenario/'B1.bin'","root/'logs/lab-perf-25/final-interleaved'/scenario/'B1.bin'")
source=source.replace("'old_query_source':str(baseline/'radial_geometry.py'),'old_query_sha256':hashlib.sha256((baseline/'radial_geometry.py').read_bytes()).hexdigest()",
                      "'old_sources':{name:{'path':str(baseline/name),'sha256':hashlib.sha256((baseline/name).read_bytes()).hexdigest()} for name in ('vehicle_unsprung.py','unsprung_contact_geometry.py')}")
source=source.replace('        radial.RadialRoads.query=original_query','        UnsprungAdvanceInput.read=original_read\n        contact.FiniteRadialContact.__init__=original_init')
assert 'old_radial' not in source and 'original_query' not in source
assert source.count('old_sources')==1 and 'logs/lab-perf-25/final-interleaved' in source
(root/'logs/lab-perf-26/interleaved.py').write_text(source,encoding='utf-8')
print('four-world complete-step crossover: original real queries versus same-read geometry preparation')
