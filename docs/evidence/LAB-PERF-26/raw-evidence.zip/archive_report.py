"""核对同子步重复输入证据、完整旧接口与本批全部输出，归档限定结果。"""
import ast
import copy
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'logs/lab-perf-26')]
from compare_results import compare
from lab_runtime import runtime_fingerprint

logs=root/'logs/lab-perf-26';baseline=root/'builds/lab-perf-26/baseline/src'
output=root/'docs/evidence/LAB-PERF-26';output.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def source(path):return path.read_text(encoding='utf-8')
def dump(node):return ast.dump(node,include_attributes=False)
suffixes=('.py','.c','.h','.cpp')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['unsprung_contact_geometry.py','vehicle_unsprung.py']
old,new=[ast.parse(source(p/'unsprung_contact_geometry.py')) for p in (baseline,root/'src')]
new.body=[n for n in new.body if not isinstance(n,ast.FunctionDef) or n.name!='_copy_geometry']
a,b=[next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name=='__init__') for t in (old,new)]
b.args.kwonlyargs=[];b.args.kw_defaults=[]
targets={'old_axes','same_axes'}
b.body=[n for n in b.body if not (isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in targets)]
for attr in ('initial','target'):
    index=next(i for i,n in enumerate(b.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Attribute) and n.targets[0].attr==attr)
    prior=next(n for n in a.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Attribute) and n.targets[0].attr==attr)
    b.body[index]=copy.deepcopy(prior)
assert dump(old)==dump(new)
old,new=[ast.parse(source(p/'vehicle_unsprung.py')) for p in (baseline,root/'src')]
calls=[n for n in ast.walk(new) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='FiniteRadialContact']
assert len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='target_geometry'
calls[0].keywords=[]
assert dump(old)==dump(new)
assert (root/'tests/lab_initial_geometry_reference.py').read_bytes()==(baseline/'unsprung_contact_geometry.py').read_bytes()

runtime=runtime_fingerprint();actual_sources={p.name:sha(p) for p in (root/'src').iterdir() if p.suffix in suffixes}
baseline_native=read(logs/'native-copies.json')
assert all(sha(baseline/name)==sha(root/'src'/name)==digest for name,digest in baseline_native.items())
def prior_sources(hashes):
    variants={}
    for name,digest in hashes.items():
        raw=(baseline/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()==digest:continue
        lf=raw.replace(b'\r\n',b'\n');matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
        assert len(matched)==1,name;variants[name]=matched[0]
    return variants
measurement=read(logs/'read-measurement/summary.json');assert measurement['diagnostic_only']
assert [(g['substeps'],g['target_exact'],g['initial_exact']) for g in measurement['groups']]==[(48,48,48),(96,96,0),(288,288,288)]
measurement_EOL_variants={}
for group in measurement['groups']:
    scenario=group['scenario'];folder=logs/'read-measurement'/scenario
    assert all(r['target_inputs_exact'] and r['target_outputs_exact'] for r in group['rows'])
    assert all(r['initial_outputs_exact'] for r in group['rows'] if r['initial_inputs_exact'])
    assert (folder/'payload.bin').read_bytes()==(root/'logs/lab-perf-25/final-interleaved'/scenario/'B1.bin').read_bytes()
    result=read(folder/'result.json');measurement_EOL_variants[scenario]=prior_sources(result['source_hashes'])
    for name,data in result['native'].items():assert baseline_native[Path(data['path']).name]==data['sha256']

groups=read(logs/'base-interleaved/summary.json')['groups'];assert len(groups)==3
native={};quality={};substeps=0
for group in groups:
    scenario=group['scenario'];folder=logs/'base-interleaved'/scenario
    assert group['runtime']==runtime and group['repeat_exact_within_method']
    assert Path(group['support_source_root'])==root/'src'
    assert group['old_sources']=={name:{'path':str(baseline/name),'sha256':sha(baseline/name)} for name in ('vehicle_unsprung.py','unsprung_contact_geometry.py')}
    expected=(root/'logs/lab-perf-25/final-interleaved'/scenario/'B1.bin').read_bytes()
    previous=read(root/'logs/lab-perf-25/final-interleaved'/scenario/'summary.json')
    assert group['options']==previous['options'] and group['actual_config']==previous['actual_config']
    a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes();assert a==b==expected
    difference=compare(pickle.loads(a),pickle.loads(b))
    assert difference==group['difference'] and not difference['changed_discrete_counts']
    assert all(v==0. for v in difference['numeric_max_abs_deltas'].values())
    for row in group['rows']:
        binary=folder/(row['label']+'.bin');assert binary.read_bytes()==expected and sha(binary)==row['payload_sha256']
        assert row['source_hashes']==actual_sources
        assert row['substeps']==len(pickle.loads(expected)['joint']);substeps+=row['substeps']
        label=row['label'][0];native[label]=row['native']
        for name,data in row['native'].items():
            path=Path(data['path']);parent=baseline if label=='A' and name=='wheel_contact_kernels' else root/'src'
            assert path.parent==parent and sha(path)==data['sha256']==baseline_native[path.name]
    independent=root/'logs/lab-perf-22/independent-model'/scenario
    quality[scenario]=read(independent/'quality.json');assert (independent/'payload.bin').read_bytes()==expected
    assert quality[scenario]['substeps']==len(pickle.loads(expected)['joint'])
    assert quality[scenario]['maxima']['energy_recompute_gap']==0.
    assert quality[scenario]['maxima']['momentum_error']<1e-9 and quality[scenario]['maxima']['force_error']<1e-5 and quality[scenario]['maxima']['port_error']<1e-9
assert substeps==1728 and sum(q['substeps'] for q in quality.values())==432
validation={name:read(logs/name/'summary.json') for name in ('T0-final','T0-standard','lab-regression')}
assert all(v['passed'] for v in validation.values())
validation_counts={}
for name in validation:
    matches=re.findall(r'(\d+) passed',source(logs/name/'pytest.log'));assert len(matches)==1;validation_counts[name]=int(matches[0])
assert validation_counts=={'T0-final':68,'T0-standard':68,'lab-regression':982}
assert validation['lab-regression']['runtime']==runtime and len(validation['lab-regression']['tests'])==49
profile=read(logs/'profile-bump/profile.json');previous=read(root/'logs/lab-perf-25/profile-bump/profile.json')
expected_counts={'residual':3486,'jacobian':8,'update':1311,'polish':288,'export_seed':288,'warm_seed':287}
assert profile['counts']==previous['counts']==expected_counts
assert (logs/'profile-bump/payload.bin').read_bytes()==(logs/'base-interleaved/nonlinear-bump/B1.bin').read_bytes()
result=read(logs/'profile-bump/result.json');prior=read(root/'logs/lab-perf-25/profile-bump/result.json')
assert result['source_hashes']==actual_sources and result['runtime']==prior['runtime']
r=result['runtime'];assert (r['panda'],r['bullet'],r['scalar_bits'])==(runtime['panda_version'],runtime['bullet_version'],runtime['math_scalar_bits'])
assert sha(Path(r['module']))==runtime['files']['panda3d/core.cp314-win_amd64.pyd']
for record in (result,prior):
    for name,data in record['native'].items():assert sha(Path(data['path']))==data['sha256']==baseline_native[Path(data['path']).name]
previous_EOL_variants=prior_sources(prior['source_hashes'])
profile_counts={}
for label,data in (('A',previous),('B',profile)):
    values={}
    for name,file in (('solve','_linalg.py'),('query','radial_geometry.py'),('_cached_plane','radial_geometry.py'),('query_plane','radial_geometry.py'),('box_section','box_radial_geometry.py'),('normal_material','unsprung_contact.py'),('read_mechanics','vehicle_unsprung.py'),('observe_unsprung','vehicle_unsprung.py'),('_copy_geometry','unsprung_contact_geometry.py'),('evaluate','unsprung_contact_geometry.py'),('evaluate','unsprung_motion.py')):
        values[file+':'+name]=sum(r['calls'] for r in data['functions'] if r['function']==name and Path(r['file']).name==file)
    for name in ('radial_query_hits','box_cone_samples','box_cone_refine','radial_box_bounds'):
        values['native.'+name]=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.'+name+'>' in r['function'])
    profile_counts[label]=values
for key in ('_linalg.py:solve','unsprung_contact.py:normal_material','vehicle_unsprung.py:read_mechanics','vehicle_unsprung.py:observe_unsprung','unsprung_contact_geometry.py:evaluate','unsprung_motion.py:evaluate'):
    assert profile_counts['A'][key]==profile_counts['B'][key],key
assert profile_counts['B']['unsprung_contact_geometry.py:_copy_geometry']==576
assert profile_counts['A']['native.radial_query_hits']==4960 and profile_counts['B']['native.radial_query_hits']==4384
assert profile_counts['A']['unsprung_contact_geometry.py:evaluate']==1976
assert profile_counts['A']['unsprung_motion.py:evaluate']==3952

with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.csv') and 'user-data' not in path.parts and path.name!='archive-report.log':
            archive.write(path,path.relative_to(logs).as_posix())
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/shared/'+path.name)
    for name in changes:archive.write(baseline/name,'executed-source/baseline/'+name)
    for path in (root/'logs/lab-perf-25/profile-bump').iterdir():
        if path.is_file():archive.write(path,'reused-baseline-profile/'+path.name)
    for scenario in quality:
        for name in ('quality.json','payload.bin'):
            path=root/'logs/lab-perf-22/independent-model'/scenario/name
            archive.write(path,'reused-equation-validation/'+scenario+'/'+name)
    for name in [*['src/'+name for name in changes],'src/unsprung_joint.py','tests/test_lab_initial_geometry.py','tests/lab_initial_geometry_reference.py','tests/test_lab_surface_cache.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py','tools/physics/unsprung_step_checkpoint.py','tools/performance/compare_lab_compute.py']:
        archive.write(root/name,'executed-source/'+name)
with zipfile.ZipFile(output/'raw-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
summary={'baseline':'6798bcb','source_changes':changes,'groups':groups,'substeps_in_performance':substeps,
         'baseline_actual_read_measurement':measurement,'measurement_EOL_variants':measurement_EOL_variants,
         'support_source_hashes_are_context':True,'old_mode':'shared other support/solver/geometry + frozen complete vehicle read/helpers and finite constructor; class types remain current; five binaries identical',
         'outside_geometry_preparation_module_AST_exact':True,'native_unchanged':True,
         'reused_baseline_profile_EOL_variants':previous_EOL_variants,'profile_counts':profile_counts,'solver_counts':expected_counts,
         'mutable_arrays_independent':True,'seed_is_transient_constructor_argument':True,
         'reused_432_substep_equation_validation':quality,'quality_scope':'22块已跑的432子步原方程/能量验证；本块实际payload逐字节相同。长工况/2,4,8细化未重跑。',
         'validation':validation,'validation_counts':validation_counts,'initial_test_failure':'8例比较器直接JSON序列化Bullet节点TypeError；修为实际节点/几何全字段先比较，再数字化节点比较剩余全字段，未改生产或忽略物理字段；原日志保留',
         'native':native,'runtime':runtime,'current_source_hashes':actual_sources,
         'formal_T1_T2_T3':'not_run; Double49模块982项试验台专项及真实记录复算；游戏seed/window未跑',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('verified:',validation_counts,'substeps',substeps,'baseline measurement/native/source/output exact')
print('profile counts:',profile_counts)
