import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd();build=root/'builds/lab-perf-26';build.mkdir(exist_ok=False)
subprocess.run(['git','archive','--format=zip','--output',str(build/'baseline.zip'),'6798bcb','src','assets/game/vehicle-configs'],check=True)
with zipfile.ZipFile(build/'baseline.zip') as archive:archive.extractall(build/'baseline')
native={}
for path in (root/'src').glob('*.pyd'):
    raw=path.read_bytes();(build/'baseline/src'/path.name).write_bytes(raw);native[path.name]=hashlib.sha256(raw).hexdigest()
assert len(native)==5
(root/'logs/lab-perf-26/native-copies.json').write_text(json.dumps(native,indent=2)+'\n',encoding='utf-8')
for name in ('compare_results.py','profile_worker.py','lab_regression.py'):
    text=(root/'logs/lab-perf-25'/name).read_text(encoding='utf-8-sig').replace('lab-perf-25','lab-perf-26').replace('final-interleaved','base-interleaved')
    (root/'logs/lab-perf-26'/name).write_text(text,encoding='utf-8')
(root/'tests/lab_initial_geometry_reference.py').write_bytes((build/'baseline/src/unsprung_contact_geometry.py').read_bytes())
print('6798bcb source and five actual native binaries frozen')
