"""独立进程保存同输入快照与物理耗时；不把墙钟当FPS。"""
import argparse
import gzip
import hashlib
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=ROOT / 'src')
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--case', choices=('coastal', 'single', 'hills', 'reference'), default='coastal')
parser.add_argument('--cpu-affinity', type=lambda value: int(value, 0))
args = parser.parse_args()
if args.cpu_affinity is not None:
    import ctypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    if not kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(), args.cpu_affinity):
        raise ctypes.WinError(ctypes.get_last_error())
sys.path.insert(0, str(args.source.resolve()))
import paths
paths.resource_root = lambda: ROOT
from driving_modes import DrivingMode
from simulation import Control, Simulation
from vehicle_designs import GR86_DESIGN


def exact(value):
    if isinstance(value, float):
        return value.hex()
    if isinstance(value, dict):
        return {k: exact(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [exact(v) for v in value]
    return value


traffic = 0 if args.case == 'single' else 8
track = 'endless' if args.case == 'hills' else 'coastal'
config = DrivingMode.GAME.vehicle_config if args.case == 'reference' else GR86_DESIGN
sim = Simulation(seed=17, track=track, road_shape='hills' if args.case == 'hills' else 'straight',
                 traffic_count=traffic, config=config, input_config=DrivingMode.GAME.input_config)
frames, times = [], []
try:
    for tick in range(128):
        control = Control(throttle=.3 if tick < 96 else 0., brake=.5 if tick >= 96 else 0.,
                          steering=0. if tick < 64 else .1 if tick < 96 else -.1)
        start = time.perf_counter()
        sim.step(control)
        times.append(time.perf_counter() - start)
        frames.append(exact(asdict(sim.snapshot())))
finally:
    sim.close()
encoded = json.dumps(frames, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
args.output.mkdir(parents=True, exist_ok=False)
(args.output / 'snapshots.json.gz').write_bytes(gzip.compress(encoded, mtime=0))
report = {'case': args.case, 'source': str(args.source.resolve()), 'ticks': 128,
          'cpu_affinity': args.cpu_affinity,
          'snapshot_sha256': hashlib.sha256(encoded).hexdigest(), 'tick_seconds': times,
          'sample_32_96_mean_ms': sum(times[32:96]) / 64 * 1000,
          'wall_128': sum(times), 'scope': 'short headless trajectory; no FPS gate'}
(args.output / 'timing.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'tick_seconds'}), flush=True)
