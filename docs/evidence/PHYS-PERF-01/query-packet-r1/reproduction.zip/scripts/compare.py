"""分类完整快照差异，保留整数/模式事件变化与物理量最大误差。"""
import argparse
import gzip
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('before', type=Path)
parser.add_argument('after', type=Path)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
old = json.loads(gzip.decompress((args.before / 'snapshots.json.gz').read_bytes()))
new = json.loads(gzip.decompress((args.after / 'snapshots.json.gz').read_bytes()))
differences, categorical = [], []


def visit(a, b, path):
    if isinstance(a, dict):
        assert a.keys() == b.keys()
        for key in a:
            visit(a[key], b[key], path + '.' + key)
    elif isinstance(a, list):
        assert len(a) == len(b)
        for i, (x, y) in enumerate(zip(a, b)):
            visit(x, y, path + '[' + str(i) + ']')
    elif a != b:
        if isinstance(a, str) and a.startswith(('0x', '-0x')):
            x, y = float.fromhex(a), float.fromhex(b)
            differences.append({'path': path, 'absolute': abs(x-y),
                                'relative': abs(x-y)/max(abs(x), abs(y), 1e-12), 'old': x, 'new': y})
        else:
            categorical.append({'path': path, 'old': a, 'new': b})


visit(old, new, 'snapshot')
pose = [r for r in differences if any(name in r['path'] for name in
        ('.position', '.velocity', '.orientation', '.speed', '.angular_velocity'))]
report = {'snapshots': len(old), 'float_fields_changed': len(differences),
          'categorical': categorical, 'pose_max_absolute': max((r['absolute'] for r in pose), default=0.),
          'largest': sorted(differences, key=lambda r: -r['absolute'])[:20]}
args.output.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
