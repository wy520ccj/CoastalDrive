"""记录Windows实际P/E核分组，供同核短测使用。"""
import ctypes
import json
import struct

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
function = kernel.GetLogicalProcessorInformationEx
function.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
size = ctypes.c_ulong()
function(0, None, ctypes.byref(size))
buffer = ctypes.create_string_buffer(size.value)
if not function(0, buffer, ctypes.byref(size)):
    raise ctypes.WinError(ctypes.get_last_error())
data = buffer.raw
position, cores = 0, []
while position < len(data):
    relation, length = struct.unpack_from('II', data, position)
    efficiency = data[position + 9]
    count = struct.unpack_from('H', data, position + 30)[0]
    mask, group = struct.unpack_from('QH', data, position + 32)
    cores.append(dict(efficiency=efficiency, groups=count, group=group, mask=hex(mask)))
    position += length
print(json.dumps(cores))
