"""保存数值查询与世界提交边界的可复现检查点。"""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LOG = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/PHYS-PERF-01/query-packet-r1'
OUT.mkdir(parents=True, exist_ok=False)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


write('source-hashes.json', {str(p.relative_to(ROOT)): sha(p) for p in (ROOT / 'src').rglob('*')
                          if p.suffix in ('.py', '.c', '.h', '.pyd')})
names = ['stages-coastal', 'native-query-coastal', 'query-packet-coastal',
         *[f'query-abba-{kind}-{run}' for kind,run in [('old',1),('new',1),('new',2),('old',2)]],
         *[f'packet-abba-{kind}-{run}' for kind,run in [('old',1),('new',1),('new',2),('old',2)]],
         *[f'query-packet-final-{case}' for case in ['coastal','single','hills','reference']]]
timings = {name: read(LOG / name / 'timing.json') for name in names}
write('timings.json', timings)
old = sum(timings[f'packet-abba-old-{i}']['sample_32_96_mean_ms'] for i in (1,2)) / 2
new = sum(timings[f'packet-abba-new-{i}']['sample_32_96_mean_ms'] for i in (1,2)) / 2
write('trajectory-diffs.json', {case: read(LOG / f'query-packet-diff-{case}.json')
                              for case in ('coastal','single','hills','reference')})
validations = {p.parent.name: read(p) for p in (ROOT / 'logs/validation').glob('PHYS-PERF-01-*/summary.json')
               if any(word in p.parent.name for word in ('stages-', 'numeric-query-', 'query-packet-', 'query-transform-'))}
write('validation-summaries.json', validations)
write('failure-notes.json', {
    'initial_direct_pytest': '2 observation-wrapper failures and 142 passed; wrappers still observed old Tires.advance. Both were moved to advance_stages without changing assertions.',
    'stages_t0': 'New ordering test initially used nonexistent Simulation.traffic; corrected to actual npcs. Original failed summary retained.',
    'stages_t1': '531 passed, 2 observation-wrapper failures at removed vehicle_tires.advance_drivetrain import. Observation moved to actual tire_drivetrain entry; r2 two nodes and all three seeds passed.',
    'query_transform_t0': 'Initial Ruff import-order failure, then test placed car at x=1 while coastal spawn x=95. Corrected fixture to actual spawn; r3 passed. Original summaries retained.',
    'whole_vehicle_suite': 'Old time-refinement assertion still fails as recorded in optimize-r1; this related 629-test T1 does not close whole vehicle or stage gates.'})
with zipfile.ZipFile(OUT / 'reproduction.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for source,prefix in ((ROOT / 'src','current-src'), (LOG / 'stages-src','stages-baseline-src')):
        for p in source.rglob('*'):
            if p.suffix in ('.py','.c','.h','.pyd'):
                archive.write(p,prefix+'/'+p.relative_to(source).as_posix())
    for name in ('trajectory.py','compare.py','cpu_cores.py','archive_query_packet.py'):
        archive.write(LOG / name,'scripts/'+name)
    for name in ('packet-abba-old-1','packet-abba-new-1'):
        archive.write(LOG / name / 'snapshots.json.gz',name+'/snapshots.json.gz')
    for name in ('test_world_substeps.py','test_joint_suspension.py','test_static_support_cache.py','test_triangle_support.py'):
        archive.write(ROOT / 'tests' / name,'tests/'+name)
receipt = {
    'baseline': 'cef1f4b3823c700386427ee56d53a981f2dd6625',
    'status': 'functional checkpoint verified; chronic lag and realtime budget remain unresolved',
    'world': 'single Bullet world, 120 Hz, two physical substeps; read all vehicle inputs, solve, commit in original order',
    'native_queries': 'same BVH/shape ordering, face/edge/box equations, SVD, 64/96 iteration caps and thresholds; cached numeric transforms invalidated by actual surface-list replacement',
    'precision_audits': '512 BVH face/edge/miss and 512 complete box sweep comparisons equal; transformed real-world query comparisons equal',
    'trajectory': 'four cases x 128 snapshots equal to prior checkpoint, all fields; compared trajectories include turn/brake, hills and reference car',
    'abba': {'old_mean_ms': old, 'new_mean_ms': new, 'reduction_percent': (1-new/old)*100,
             'scope': '128 headless coastal GR86 + eight NPC ticks, timed 32:96, single P-core affinity for measurement only; not FPS'},
    'related_t1': '629 tests, Ruff, seeds 0/17/23 each 1200 ticks passed; earlier overlapping T1 counts are not summed',
    'parallel': 'not implemented; numerical geometry still contains rare SVD/world-query callbacks requiring Python',
    'pending': ['complete native numerical solver and parallel execution', '120 Hz realtime budget', 'final game package', 'foreground performance and human driving gates'],
    'publication': 'local checkpoint only, no push',
    'git_status': subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True,encoding='utf-8')}
receipt['payload_sha256'] = {p.name: sha(p) for p in OUT.iterdir() if p.is_file()}
write('receipt.json', receipt)
print(json.dumps({'evidence': str(OUT), 'abba': receipt['abba']}))
