"""Vehicle dimensions are metres; steering angles are degrees."""

import math
from dataclasses import dataclass, field

from vehicle_brakes import BrakeConfig
from vehicle_stability import StabilityConfig
from vehicle_traction import TractionConfig


@dataclass(frozen=True)
class VehicleConfig:
    mass: float = 1200.0
    # 游戏发动机曲线；引入四轮转动惯量后整体提高5.5%，保留既有动力性目标。
    torque_curve: tuple = (
        (900, 116.05),
        (1800, 174.075),
        (3200, 211),
        (4500, 200.45),
        (6000, 158.25),
        (6500, 0),
    )
    gear_ratios: tuple = (3.25, 2.05, 1.45, 1.10, 0.88)
    final_drive: float = 3.7
    drivetrain_efficiency: float = 0.88
    idle_rpm: float = 900.0
    shift_time: float = 0.28
    torque_response: float = 0.12
    engine_braking: float = 24.0  # Approximate closed-throttle torque at the crank, Nm.
    finite_drivetrain: bool = True  # 两模式共用真实曲轴/有限离合；false用于冻结旧机制A/B。
    front_drive_share: float = 0.0  # 0后驱、1前驱；中间值为开放中差的固定几何份额。
    differential_damping: tuple = (0., 0., 0.)  # 前轴/后轴/中差粘性系数，N·m·s/rad；默认开放。
    differential_capacity: tuple = (0., 0., 0.)  # 对应有限耦合容量，N·m；容量为0关闭端口。
    axle_torque_bias_ratios: tuple = (1., 1.)  # 前／后轴负载依赖最大偏置比；1关闭，非原厂默认TBR。
    engine_inertia: float = .02  # 正常游戏起步响应标定的设计惯量，kg·m²；困难参考车取0.2，非实测。
    engine_axis: tuple = (0., 1., 0.)  # 车身局部曲轴正转方向。
    input_shaft_enabled: bool = True  # false冻结八维传动，仅供同机制旧/新对照。
    input_shaft_inertia: float = .005  # 游戏输入轴设计惯量kg·m²；参考车取.04，均非实测。
    input_shaft_axis: tuple = (0., 1., 0.)  # 壳体局部输入轴正转方向。
    synchronizer_capacity: float = 80.  # 输入轴侧有限同步锥容量N·m，设计值。
    downstream_inertia_enabled: bool = True  # 实体输入轴分支内启用输出/前/后驱动轴；false为机制A/B。
    downstream_inertias: tuple = (.003, .0015, .002)  # kg·m²，游戏设计值；非驱动轴不安装对应转子。
    downstream_axes: tuple = ((0., 1., 0.),) * 3  # 车身局部各轴正转方向；参考模型为纵置轴系。
    engine_idle_response: float = .15
    engine_idle_torque_limit: float = 65.
    engine_redline_rpm: float = 6500.
    clutch_capacity: float = 300.  # Nm；有限干式离合容量。
    clutch_release_time: float = .08
    clutch_engage_time: float = .16
    clutch_launch_response: float = .30  # 起步曲轴反馈设计值；兼顾升速与早期有限传矩。
    max_speed: float = 160 / 3.6
    reverse_speed: float = 22 / 3.6
    reverse_force: float = 2200.0
    reverse_gear_ratio: float = 3.0
    game_speed_limits: bool = True
    brake_torque: float = 3643.2  # Total wheel braking torque, Nm.
    front_brake_share: float = 0.60
    braking: BrakeConfig = field(default_factory=BrakeConfig)
    traction: TractionConfig = field(default_factory=TractionConfig)
    stability: StabilityConfig = field(default_factory=StabilityConfig)
    steering_degrees: float = 26.0
    steering_rate: float = 50.0
    steering_response: float = 7.0
    steering_return: float = 10.0
    wheel_radius: float = 0.33
    wheel_width: float = .205  # m，通用设计胎宽；不作为实车测量数据。
    wheel_shoulder_radius: float = .01  # m，圆角肩部；半径与胎宽均定义含肩部外廓。
    wheel_crown_height: float = .003  # m，胎面中心到肩部的抛物线胎冠落差，通用设计值。
    wheel_inertia: float = 1.8  # 单轮轴向转动惯量，kg·m²。
    longitudinal_stiffness: float = 60000.0  # 静态单轮载荷下，N/单位滑转率。
    lateral_stiffness: float = 50000.0  # 静态单轮载荷下，N/rad。
    rear_lateral_stiffness: float = 50000.0  # 后轮可独立定义侧偏刚度，N/rad。
    tire_peak_load_exponent: float = .90  # 峰值力随轮荷次线性增长；1恢复原线性模型。
    longitudinal_load_exponent: float = .90
    lateral_load_exponent: float = .85
    tire_compliance: bool = True
    wheel_rotor_transport: bool = True  # 机械轮轴、有效力臂及同末状态轴承反力；false冻结旧机制。
    tire_contact_stiffness: float = 150000.0  # 二维各向同性接触区弹性，N/m。
    tire_contact_damping: float = 1000.0  # N·s/m。
    tire_shape: float = 1.9
    tire_curvature: float = 0.97
    slip_speed: float = 1.0  # 低速滑移分母的模型尺度，m/s。
    static_contact_speed: float = .25  # 低速无滑移接触的切换尺度，m/s。
    tire_substeps: int = 2
    suspension_si_enabled: bool = True  # false沿用质量归一化旧硬件，供明确旧/新对照。
    suspension_coupled_enabled: bool = True  # SI分支共同求法向力；false保留首增量的原生SI对照。
    suspension_antiroll_rates: tuple = (6000., 4000.)  # N/m；前/后左右行程差的设计刚度，非实测标定。
    suspension_stop_rates: tuple = (480000.,) * 4  # N/m；行程边界外的渐进止挡设计刚度。
    suspension_spring_rates: tuple = (48000.,) * 4  # N/m；四轮实际弹簧设计值，平路与旧1200kg参数相同。
    suspension_compression_damping: tuple = (5280.,) * 4  # N·s/m；耦合分支的轴向压缩阻尼，原生对照为法向/射线速率。
    suspension_extension_damping: tuple = (2760.,) * 4  # N·s/m；耦合分支的轴向伸张阻尼。
    suspension_stiffness: float = 40.0
    suspension_compression: float = 4.4
    suspension_relaxation: float = 2.3
    air_density: float = 1.225  # kg/m³
    drag_coefficient: float = 0.32
    frontal_area: float = 2.142857142857143  # m²; preserves the previous Cd*A product.
    rolling_coefficient: float = 160 / (1200 * 9.81)
    grass_rolling_coefficient: float = 900 / (1200 * 9.81)
    wheel_rolling_resistance: bool = True  # 有限传动分支走轮端滚阻；false为旧车身阻力A/B。
    rolling_transition_speed: float = 1.0  # m/s；滚动阻力矩从零连续达到Crr*Fn*r的轮缘速度。
    road_friction: float = 1.1
    grass_friction: float = 0.45
    wheelbase: float = 2.2
    track_width: float = 1.68
    axle_track_widths: tuple[float, float] | None = None  # 前／后轴轮距；None明确沿用统一track_width。
    # 同时覆盖当前车型的车身和外露车轮，玩家与交通车共用这组尺寸。
    collision_half_width: float = 1.05
    collision_half_length: float = 2.15
    collision_half_height: float = 0.42
    centered_collision_support: bool = True  # 沿CG投影切分原生Box，完整覆盖名义外廓；默认四块。
    # 车身/轮连接点以车辆设计地面为基准；创建刚体时转换到质心坐标。
    body_center_height: float = 0.84
    wheel_connection_height: float = 0.67
    center_of_mass_height: float = 0.42
    front_weight_share: float = 0.5
    body_inertia: tuple[float, float, float] | None = None
    angular_damping: float = 0.2
    suspension_travel: float = 0.2
    suspension_force_limit: float = 6000.0  # N；仅原生对照分支的数值力限，SI势能反力不作硬裁剪。

    def __post_init__(self):
        if len(self.axle_torque_bias_ratios) != 2 or any(not math.isfinite(value) or value < 1.
                for value in self.axle_torque_bias_ratios):
            raise ValueError("前／后轴扭矩偏置比须为两个不小于1的有限值")
        if self.axle_track_widths is not None and (len(self.axle_track_widths) != 2
                or any(not math.isfinite(width) or width <= 0. for width in self.axle_track_widths)):
            raise ValueError("前／后轴轮距须为两个有限正值m")
        if not math.isfinite(self.rolling_transition_speed) or self.rolling_transition_speed <= 0.:
            raise ValueError("滚阻低速过渡轮缘速度须为有限正值m/s")
        if any(not math.isfinite(c) or c < 0. for c in (self.rolling_coefficient,self.grass_rolling_coefficient)):
            raise ValueError("铺装/草地滚阻系数须为有限非负值")
        if not (math.isfinite(self.wheel_width) and self.wheel_width > 0.
                and math.isfinite(self.wheel_shoulder_radius)
                and 0. < self.wheel_shoulder_radius < min(self.wheel_radius, self.wheel_width / 2)):
            raise ValueError("胎宽须为正值，肩部圆角须小于轮半径与半胎宽")
        if not math.isfinite(self.wheel_crown_height) or not 0. <= self.wheel_crown_height < self.wheel_radius - self.wheel_shoulder_radius:
            raise ValueError("胎冠落差须为有限非负值且小于胎面内核半径")
        if len(self.suspension_antiroll_rates) != 2 or any(not math.isfinite(k) or k < 0 for k in self.suspension_antiroll_rates):
            raise ValueError("前/后防倾刚度须为两个有限非负值N/m")
        if len(self.suspension_stop_rates) != 4 or any(not math.isfinite(k) or k < 0 for k in self.suspension_stop_rates):
            raise ValueError("四轮止挡刚度须为有限非负值N/m")
        if len(self.suspension_spring_rates) != 4 or any(not math.isfinite(k) or k <= 0 for k in self.suspension_spring_rates):
            raise ValueError("四轮弹簧刚度须为有限正值N/m")
        for coefficients in (self.suspension_compression_damping, self.suspension_extension_damping):
            if len(coefficients) != 4 or any(not math.isfinite(c) or c < 0 for c in coefficients):
                raise ValueError("四轮悬架阻尼须为有限非负值N·s/m")
        if len(self.downstream_inertias) != 3 or any(not math.isfinite(j) or j <= 0 for j in self.downstream_inertias):
            raise ValueError("输出/前/后轴惯量须为三个有限正值")
        if len(self.downstream_axes) != 3 or any(len(axis) != 3 or any(not math.isfinite(v) for v in axis)
                or abs(sum(v * v for v in axis) - 1.) > 1e-12 for axis in self.downstream_axes):
            raise ValueError("输出/前/后轴方向须为三个三维单位向量")
        if not math.isfinite(self.input_shaft_inertia) or self.input_shaft_inertia <= 0:
            raise ValueError("输入轴惯量须为有限正值")
        if not math.isfinite(self.synchronizer_capacity) or self.synchronizer_capacity < 0:
            raise ValueError("同步器容量须为有限非负值")
        if (len(self.input_shaft_axis) != 3 or any(not math.isfinite(v) for v in self.input_shaft_axis)
                or abs(sum(v * v for v in self.input_shaft_axis) - 1.) > 1e-12):
            raise ValueError("输入轴方向须为三维单位向量")
        if not 0 <= self.front_drive_share <= 1:
            raise ValueError("前轴驱动份额须在0到1之间")
        if self.front_drive_share != 0 and not self.finite_drivetrain:
            raise ValueError("前驱/四驱需要有限机械传动，旧对照分支仅支持后驱")
        if len(self.differential_damping) != 3 or len(self.differential_capacity) != 3:
            raise ValueError("限滑参数依次为前轴、后轴、中差的三项")
        if any(not math.isfinite(v) or v < 0 for v in (*self.differential_damping, *self.differential_capacity)):
            raise ValueError("限滑系数/容量须为有限非负值")
        for axle, bias in enumerate(self.axle_torque_bias_ratios):
            if bias > 1. and (not self.finite_drivetrain or not self.input_shaft_enabled
                    or self.differential_damping[axle] <= 0. or self.differential_capacity[axle] <= 0.):
                raise ValueError("扭矩偏置需要实体输入轴及对应轴的有限限滑端口")
        enabled = tuple(c > 0 and limit > 0 for c, limit in zip(self.differential_damping, self.differential_capacity))
        if any(enabled) and not self.finite_drivetrain:
            raise ValueError("有限限滑需要有限机械传动")
        if enabled[0] and self.front_drive_share == 0 or enabled[1] and self.front_drive_share == 1:
            raise ValueError("未驱动轴不配置传动限滑")
        if enabled[2] and self.front_drive_share in (0, 1):
            raise ValueError("中差限滑仅用于四驱")

    @property
    def wheel_track_widths(self):
        return (self.track_width, self.track_width) if self.axle_track_widths is None else self.axle_track_widths

    @property
    def drive_weights(self):
        front = self.front_drive_share / 2
        rear = (1 - self.front_drive_share) / 2
        return front, front, rear, rear

    @property
    def driven_wheels(self):
        return tuple(i for i, weight in enumerate(self.drive_weights) if weight > 0)


CAR = VehicleConfig()


def wheel_hubs(config=CAR):
    """前轴静态份额定义质心纵向位置；高度改变真实轮连接点力臂。"""
    return tuple(
        (side * width / 2,
         config.wheelbase * ((1 if axle == 1 else 0) - config.front_weight_share),
         config.wheel_connection_height - config.center_of_mass_height)
        for axle, width in zip((1, -1), config.wheel_track_widths) for side in (-1, 1)
    )


def body_center(config=CAR):
    return (0.0, config.wheelbase * (.5 - config.front_weight_share),
            config.body_center_height - config.center_of_mass_height)


def design_spawn(position, config=CAR, heading=0., pitch=0.):
    """地图出生点沿车身上轴从原设计CG高度转换到所选硬件CG；显式世界坐标不调用它。"""
    delta = config.center_of_mass_height-CAR.center_of_mass_height
    if delta == 0.:
        return position
    h, p = math.radians(heading), math.radians(pitch)
    up = math.sin(h)*math.sin(p), -math.cos(h)*math.sin(p), math.cos(p)
    return tuple(value+delta*axis for value, axis in zip(position, up))


WHEEL_HUBS = wheel_hubs()
