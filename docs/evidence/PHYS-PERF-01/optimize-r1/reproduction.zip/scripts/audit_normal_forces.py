"""独立旧DLL核对反力入口；覆盖离地、止挡、双向阻尼及耦合迁移率。"""
import importlib.util
import itertools
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
import mechanical_kernels as new

spec = importlib.util.spec_from_file_location('original.mechanical_kernels', OUT / 'mechanical-before-forces.pyd')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
rng = random.Random(1708)
success = errors = 0
for flags in itertools.product((False, True), repeat=4):
    for _ in range(64):
        compression = tuple(rng.uniform(-.13, .13) for _ in range(4))
        geometry = tuple(rng.uniform(-.13, .13) for _ in range(4))
        gradients = tuple(tuple(rng.uniform(-2., 2.) for _ in range(6)) for _ in range(4))
        velocity = tuple(rng.uniform(-20., 20.) for _ in range(3))
        angular = tuple(rng.uniform(-2., 2.) for _ in range(3))
        dt = rng.choice((1 / 120, 1 / 240, 1 / 480))
        rates = tuple(rng.uniform(40000., 70000.) for _ in range(4))
        bars = tuple(rng.uniform(0., 18000.) for _ in range(2))
        cd = tuple(rng.uniform(2200., 4000.) for _ in range(4))
        ed = tuple(rng.uniform(800., 1800.) for _ in range(4))
        stops = (3000000.,) * 4
        travel = .1
        mobility = tuple(tuple(sum(gradients[i][a] * gradients[j][a] / 1400 for a in range(6))
                               for j in range(4)) for i in range(4)) if rng.randrange(2) else ((0.,) * 4,) * 4
        previous = tuple(rng.uniform(0., 20000.) for _ in range(4))
        speeds = tuple(new.dot(g, velocity + angular) - dt * new.dot(row, previous)
                       for g, row in zip(gradients, mobility))
        coeff = new.suspension_coefficients(compression, geometry, rates, cd, ed, bars, stops, travel, dt)
        outcomes = []
        for function in (
            lambda: old.suspension_step(compression, speeds, mobility, flags, rates, cd, ed, bars, stops, travel, dt, geometry)[2],
            lambda: new.suspension_forces(coeff, gradients, velocity, angular, flags, mobility, previous),
        ):
            try:
                outcomes.append(tuple(value.hex() for value in function()))
            except ArithmeticError as error:
                outcomes.append((type(error).__name__, str(error)))
        assert outcomes[0] == outcomes[1], (flags, outcomes)
        if outcomes[0][0] == 'ArithmeticError':
            errors += 1
        else:
            success += 1
report = dict(cases=1024, successful=success, matching_failures=errors, float_hex_equal=True,
              original_dll=str(OUT / 'mechanical-before-forces.pyd'))
(OUT / 'audit-normal-forces.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
