"""独立旧/新源码复现落体制动；保留真实硬件轴定义。"""
import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=ROOT / 'src')
parser.add_argument('--steps', type=int, default=2)
parser.add_argument('--refinement', action='store_true')
parser.add_argument('--symmetric-shafts', action='store_true')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source.resolve()))
import paths
paths.resource_root = lambda: ROOT
from driving_modes import REFERENCE_CAR
from simulation import Simulation
sys.path.insert(0, str(ROOT / 'tools'))
from physics import esc_probe

values = {'engine_axis': (1., 0., 0.), 'tire_substeps': args.steps}
if args.symmetric_shafts:
    values.update(input_shaft_axis=(1., 0., 0.), downstream_axes=((1., 0., 0.),) * 3)
trials = []
for steps in ((2, 4, 8, 16) if args.refinement else (args.steps,)):
    values['tire_substeps'] = steps
    trial, trace = esc_probe.run_trial('airborne-recontact', True, 6, 'simulation',
                                      vehicle_config=replace(REFERENCE_CAR, **values))
    trials.append(trial)
    print(json.dumps({k: v for k, v in trial.items() if k in
                     ('peak_abs_unwrapped_heading_deg', 'esc_active_seconds', 'stopped', 'path_distance_m', 'time_to_stop_s')}), flush=True)
args.output.write_text(json.dumps(trials, indent=2), encoding='utf-8')
