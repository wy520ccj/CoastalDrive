"""四轮批量几何与既有独立Python公式逐值核对。"""
import json
import random
import sys
from dataclasses import astuple
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from panda3d.core import TransformState, Vec3
from rotor_dynamics import cross, dot, steering_torque
from wheel_contact_kernels import rotor_frame_geometry
from wheel_dynamics import Mobility
from wheel_geometry import contact_geometry, mechanical_axis

rng = random.Random(1710)
count = 0

def exact(value):
    if isinstance(value, (tuple, list)):
        return tuple(exact(part) for part in value)
    return value.hex()

for trial in range(512):
    quat = TransformState.makeHpr(Vec3(*(rng.uniform(-30., 30.) for _ in range(3)))).getQuat()
    right, forward = tuple(quat.getRight()), tuple(quat.getForward())
    initial, target = (tuple(rng.uniform(-35., 35.) for _ in range(4)) for _ in range(2))
    omega = tuple(rng.uniform(-100., 100.) for _ in range(4))
    normals = tuple(tuple(quat.getUp()) for _ in range(4))
    points = tuple(tuple(rng.uniform(-2., 2.) for _ in range(3)) for _ in range(4))
    tensor = ((.002, 0., 0.), (0., .003, 0.), (0., 0., .0015))
    fraction, previous = rng.random(), rng.random()
    radius, mass, inertia, dt = .33, 1400., 1.7, rng.choice((1 / 120, 1 / 240, 1 / 480))
    width, shoulder, crown = (.205 if trial % 2 else None), .01, .003
    actual = rotor_frame_geometry(right, forward, initial, target, normals, points, tensor, omega,
        (radius, mass, inertia, dt, fraction, previous, width, shoulder, crown))
    expected = []
    for i in range(4):
        angle = initial[i] + (target[i] - initial[i]) * fraction
        old_angle = initial[i] + (target[i] - initial[i]) * previous
        axis = mechanical_axis(right, forward, angle)
        old_axis = mechanical_axis(right, forward, old_angle)
        geometry = {} if width is None else dict(width=width, shoulder=shoulder, crown=crown)
        axis, frame, rolling_radius, mx = contact_geometry(axis, normals[i], points[i], radius, **geometry)
        tangent, lateral, _normal = frame
        my = cross(points[i], lateral)
        rx, ry, rt = tuple(tuple(dot(row, vector) for row in tensor) for vector in (mx, my, axis))
        mobility = Mobility(1 / mass + dot(mx, rx), dot(mx, ry), dot(mx, rt),
                            1 / mass + dot(my, ry), dot(my, rt), dot(axis, rt))
        torque = steering_torque(old_axis, axis, omega[i], inertia, dt)
        expected.append((angle, axis, frame, rolling_radius, mx, rx, ry, rt, astuple(mobility), torque))
    assert exact(actual) == exact(expected), trial
    count += 4
report = dict(wheels=count, float_hex_equal=True, layout='legacy and finite crown')
(OUT / 'audit-rotor-frames.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
