"""独立旧DLL对照边投影；允许已授权的微小浮点差异。"""
import importlib.util
import json
import math
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
import wheel_contact_kernels as new
old_path = next((OUT / 'baseline-src').glob('wheel_contact_kernels*.pyd'))
spec = importlib.util.spec_from_file_location('baseline.wheel_contact_kernels', old_path)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
rng = random.Random(71)
cases = []
for i in range(2048):
    axis = tuple(rng.uniform(-1, 1) for _ in range(3))
    length = math.sqrt(sum(x*x for x in axis))
    axis = tuple(x / length for x in axis)
    offset = 1000. if i % 3 == 0 else 0.
    center = tuple(offset + rng.uniform(-2, 2) for _ in range(3))
    a = tuple(offset + rng.uniform(-1, 1) for _ in range(3))
    b = tuple(offset + rng.uniform(-1, 1) for _ in range(3))
    cases.append((center, axis, a, b, .32, .0925, .003 if i % 2 else 0.))
timings, outputs = [], []
for module in (old, new, new, old):
    started = time.perf_counter()
    values = [module.cylinder_edge_distance(*case) for case in cases]
    timings.append(time.perf_counter() - started)
    outputs.append(values)
maximum = [0., 0., 0.]
positive = [0., 0., 0.]
worst = None
for case, expected, actual in zip(cases, outputs[0], outputs[1]):
    maximum[0] = max(maximum[0], abs(expected[0] - actual[0]))
    maximum[1] = max(maximum[1], *(abs(a-b) for a, b in zip(expected[1], actual[1])))
    maximum[2] = max(maximum[2], *(abs(a-b) for a, b in zip(expected[2], actual[2])))
    if max(expected[0], actual[0]) > 1e-8:
        deltas = [abs(expected[0]-actual[0]), max(abs(a-b) for a,b in zip(expected[1],actual[1])),
                  max(abs(a-b) for a,b in zip(expected[2],actual[2]))]
        if deltas[2] > positive[2]:
            worst = {'case': case, 'expected': expected, 'actual': actual}
        positive = [max(a,b) for a,b in zip(positive,deltas)]
report = {'cases': len(cases), 'ABBA_seconds': timings,
          'max_distance_normal_witness_delta': maximum,
          'positive_distance_delta': positive, 'worst_positive_witness': worst,
          'repeated_outputs_same': outputs[0] == outputs[3] and outputs[1] == outputs[2]}
(OUT / 'edge-audit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
assert maximum[0] < 1e-11 and positive[1] < 1e-10 and positive[2] < 1e-10
