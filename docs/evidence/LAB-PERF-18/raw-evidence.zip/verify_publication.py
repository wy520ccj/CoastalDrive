import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd()
folder=root/'docs/evidence/LAB-PERF-18'
summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'))
archive_path=folder/'raw-evidence.zip'
assert hashlib.sha256(archive_path.read_bytes()).hexdigest()==summary['raw_evidence_sha256']
for group in summary['groups']:
    row=next(r for r in group['rows'] if r['label']=='B1')
    for name,digest in row['source_hashes'].items():
        assert hashlib.sha256((root/'src'/name).read_bytes()).hexdigest()==digest,name
    for name,data in row['native'].items():
        assert hashlib.sha256(Path(data['path']).read_bytes()).hexdigest()==data['sha256'],name
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name in ('src/unsprung_contact_geometry.py','src/lab_contact_native.h','src/wheel_contact_kernels.c',
                 'tests/test_lab_contact_frames.py','tests/lab_contact_frames_reference.py'):
        assert archive.read('executed-source/'+name)==(root/name).read_bytes(),name
    path=Path(summary['native']['B']['wheel_contact_kernels']['path'])
    assert archive.read('executed-native/new/'+path.name)==path.read_bytes()
print('archive integrity/SHA; all executed source and five native modules still exact')
