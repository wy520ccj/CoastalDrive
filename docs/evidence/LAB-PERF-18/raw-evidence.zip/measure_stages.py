import inspect
import json
import sys
import textwrap
import time
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd()
sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import compare_lab_compute
import unsprung_contact_geometry as geometry
from lab_experiment import LabExperiment

counts={}
durations={}
measured=False
def stage(name,started):
    if measured:
        counts[name]=counts.get(name,0)+1
        durations[name]=durations.get(name,0.)+time.perf_counter()-started

function=geometry.FiniteRadialContact.evaluate
source=textwrap.dedent(inspect.getsource(function))
markers=(('preparation','    h,hardware,config ='),('queries','    middle = self.roads.query('),
         ('gradients','    planes,same_plane,touching ='),('ports_and_steering','    contacts = tire_ports('),
         ('projection','    deformation,frame_loss ='),('finish','    friction,rolling ='))
for index,(name,marker) in reversed(list(enumerate(markers))):
    assert source.count(marker)==1
    prefix=('    _stage(%r,_started)\n'%markers[index-1][0] if index else '')
    source=source.replace(marker,prefix+'    _started = _clock()\n'+marker,1)
source=source.replace('    return self.cached','    _stage("finish",_started)\n    return self.cached',1) if False else source
position=source.rindex('    return self.cached')
source=source[:position]+'    _stage("finish",_started)\n'+source[position:]
path=root/'logs/lab-perf-18/diagnostic_evaluate.py'
path.write_text(source,encoding='utf-8')
namespace=vars(geometry)
namespace.update(_clock=time.perf_counter,_stage=stage)
exec(compile(source,str(path),'exec'),namespace)
geometry.FiniteRadialContact.evaluate=namespace['evaluate']
original_step=LabExperiment.step
def step(run):
    global measured
    measured=True
    try:return original_step(run)
    finally:measured=False
LabExperiment.step=step
output=root/'logs/lab-perf-18/stage-diagnosis'
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:geometry.FiniteRadialContact.evaluate=function;LabExperiment.step=original_step
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-17/complete-final-AB/nonlinear-B/payload.bin').read_bytes()
assert set(counts.values())=={14126}
(output/'stages.json').write_text(json.dumps({'counts':counts,'wall_seconds':durations,'scope':'原始实际完整凸起分段诊断，不作速度收益；初始化排除','payload_exact':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(durations)
