import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd()
build=root/'builds/lab-perf-18'
build.mkdir(exist_ok=False)
subprocess.run(['git','archive','--format=zip','--output',str(build/'baseline.zip'),'HEAD','src','assets/game/vehicle-configs'],check=True)
with zipfile.ZipFile(build/'baseline.zip') as archive:archive.extractall(build/'baseline')
copies={}
for path in (root/'src').glob('*.pyd'):
    raw=path.read_bytes()
    (build/'baseline/src'/path.name).write_bytes(raw)
    copies[path.name]=hashlib.sha256(raw).hexdigest()
assert len(copies)==5
(root/'logs/lab-perf-18/native-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8')
for name in ('frozen_ab.py','lab_regression.py','profile_bump.py'):
    text=(root/'logs/lab-perf-17'/name).read_text(encoding='utf-8').replace('lab-perf-17','lab-perf-18')
    (root/'logs/lab-perf-18'/name).write_text(text,encoding='utf-8')
(root/'tests/lab_contact_frames_reference.py').write_bytes((build/'baseline/src/unsprung_contact_geometry.py').read_bytes())
print('6f68437 baseline frozen with five actual native binaries')
