import json
from pathlib import Path

root=Path.cwd()
folder=root/'docs/evidence/LAB-PERF-18'
data=json.loads((folder/'summary.json').read_text(encoding='utf-8'))
groups=data['groups']
wall=[g['wall_seconds_reduction_percent'] for g in groups]
cpu=[g['cpu_seconds_reduction_percent'] for g in groups]
lines=['# 试验台四轮接触构型与材料帧批量准备','',
'2026-10-16，基线6f68437，主目录main，仅试验台；持续优化目标active。','',
'## 原始测量与实现','',
'先对未改FiniteRadialContact.evaluate真实完整实体凸起分段计时，初始化排除，payload与基线逐字节一致。14126次完整求值中，准备段2.376s、真实查询9.222s、梯度准备0.318s、端口/转向拼装1.118s、材料投影0.772s、收尾0.286s；整段诊断完整计算25.151s，初始化26.830s。该诊断含计时开销且机器状态不同，只用于定位，不作为速度表。','',
'新增两个/fp:strict C入口：finite_contact_averages批量调用四次原rotated_path_values，消除Python四次向量/返回元组包装；实际角速度范数仍由原NumPy计算，归一化仍由原NumPy执行，角度仍按原标量顺序计算。速度为零直接返回原axes对象；float32等输入保持原公式/返回类型，不先升精度做除法。','',
'finite_contact_frames将四轮三方向投影、原平方储能损失和法向转向速度合并；三个乘积按原顺序从0累加，原pow平方与(.5*stiffness)前缀、目标差的负号及h*scale顺序保持。前两列转向速度原样复制。旧变形为非float64时仍执行原project_deformation公式；上游帧、尺度、目标和端口已由既有双精度内核提供。','',
'没有把任何矩阵@/范数换成不同归约，没有减少真实几何查询、梯度、差分、Newton或52轮Box细化。原中点/末点查询、平面/接触判定、梯度和端口调用段、摩擦/滚阻判断全文相同；构造器、query_cache与RadialContactStep AST相同。头文件只追加新入口，原C函数和既有模块状态保持，注册表删除新增两行后全文相同；仅wheel扩展重编，其他四扩展与SDK不变。','',
'## 完整步逐拍交叉测量','',
'三个原工况各使用四个独立物理世界，按ABBA/反序逐拍正常前进。各世界有独立的C轴向缓存和Python曲率缓存，各自初始化和预热；绑定切换与序列化在计时外，没有重设、回退状态或调整时间。旧完整接触方法来自冻结原文，本块新增C入口在旧方法中设未使用断言；既有公共C计算段源码完全相同。','',
'| 工况 | 旧墙钟s | 新墙钟s | 耗时减少 | 旧CPU s | 新CPU s | CPU减少 |',
'|---|---:|---:|---:|---:|---:|---:|']
for group in groups:
    a,b=group['measured']['A'],group['measured']['B']
    lines.append(f"| {group['scenario']} | {a['wall_seconds']:.6f} | {b['wall_seconds']:.6f} | {group['wall_seconds_reduction_percent']:.2f}% | {a['cpu_seconds']:.6f} | {b['cpu_seconds']:.6f} | {group['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','| 工况 | 旧P95 ms | 新P95 ms | 旧P99 ms | 新P99 ms |','|---|---:|---:|---:|---:|']
for group in groups:
    a,b=group['measured']['A'],group['measured']['B']
    lines.append(f"| {group['scenario']} | {a['step_p95_seconds']*1000:.3f} | {b['step_p95_seconds']*1000:.3f} | {a['step_p99_seconds']*1000:.3f} | {b['step_p99_seconds']*1000:.3f} |")
lines+=['','初始化单列，不计入收益；制动/转向各24/48拍，非线性实体凸起144拍。制动从第一个计算拍开始brake=1；转向30km/h/2°/onset=0；凸起18km/h/.4m长度/2m位置/实际预载、安装曲线和非线性阻尼。凸起台架拟合输入为合成数据，不代表实车标定。机器绝对耗时仍有变化，只按本批交叉结果报告；CPU逐拍计数存在离散量化，保留原始值，不跨历史拼接收益。','',
'| 工况 | A1初始化s | B1初始化s | B2初始化s | A2初始化s | 初始化拍数 |','|---|---:|---:|---:|---:|---:|']
for group in groups:
    init=[r['initialization'] for r in group['rows']]
    lines.append('| '+group['scenario']+' | '+' | '.join(f"{v['wall_seconds']:.3f}" for v in init)+f" | {init[0]['ticks']} |")
lines+=['','12次共864拍/1728机械子步的全部快照、信号、命令、共同解与能量账payload逐字节一致，并与LAB-PERF-17原完整文件一致；只归一实例epoch并排除含节点的contact_geometry引用，真实接触保留在快照。每组四个世界的缓存计数完全相同，未借用其他世界的命中。18组额外求解逐位一致。','',
'## 验证、工作量与来源','',
'新增31项：720组原四轮旋转路径/零速身份/float32与float64及C/F/跨步长布局，1200组材料投影/平方/转向速度逐位对照（Python float、NumPy float32/64刚度、不同量级与正负零），8组真实平面/Box完整接触（有限悬架、导向偏置、步长及相邻ULP速度），以及缓冲区错误、只读输入、跨步长输出间隙和零速对象身份。数组比dtype/shape/strides/原始字节，不用近似容差。','',
'首轮新增检查3项因F布局转向输出误分配为C布局失败，数值相同但布局可能影响后续矩阵舍入；已用empty_like保留原column_stack布局，31项最终全过。首次Ruff导入格式失败已修正，原日志保留。普通初检62项通过；最终普通/Double T0各93项、Ruff，Double42模块683项完整试验台回归、真实记录和旧检查点复算通过。','',
'短6拍残差1692、接触求值540、端口552、线性求解2823保持；完整凸起残差44318、接触求值14126、端口14414、线性求解74040、范数354783保持。四轮材料投影原57656次Python调用降到1152次，其余56504次进入14126次C批量入口；四轮路径的56504次Python包装进入14126次C批量入口，原rotated_path_values计算仍完整执行。column_stack少14126次。Box包围盒/证明/锥端点/细化次数及两个几何缓存计数保持。','',
'旧短/完整剖析复用LAB-PERF-17，核对全部源码LF/CRLF SHA变体、五扩展、配置/协议、快照和完整凸起payload；只对新版本剖析，分析器时间不进入收益表。实际源码/扩展路径和SHA在各组中记录，速度实验后未改生产源码；头文件原计算段保持，避免旧参考或邻近检出影响判断。','',
'归档首次把六拍材料次数误写为端口次数552，实际旧新材料均540；已核对原剖析修正该预期，两个失败日志保留，没有改生产代码、数值门槛或重跑速度实验。','',
'summary与raw-evidence.zip保留分段诊断、12份完整payload、18组输入、旧新wheel/其余四扩展、执行源码/原完整接触参考、新旧剖析、构建与验证日志、交叉和归档脚本。旧参考只用于测试/证据，不作为产品入口。','',
'复现：项目Python tools/physics/run_sim_double.py logs/lab-perf-18/interleaved.py（输出需新目录）；冻结对照/完整剖析/专项回归脚本同在归档。普通环境仍用共享.venv，Double用隔离Panda1.10.16/Bullet285/LPoint3d。','',
'本块只做试验台，本地提交；游戏seed/window及通用T1/T2/T3未跑。原120Hz/双子步/34变量/真实碰撞/参数/求解和能量账保持，原完整能量/精度、人工体验、实时及EPA网格边缘拒绝仍开放。当前仍慢于实时，持续目标active。下一根据完整新剖析继续真实道路查询及接触构型准备，先测可复用的相同物理量。','']
(folder/'README.md').write_text('\n'.join(lines),encoding='utf-8')
metric='/'.join(f'{value:.2f}' for value in wall)
task=root/'docs/tasks/LAB-PERF-18.md'
task.write_text(f'''# LAB-PERF-18 四轮接触构型/材料帧批量准备

- 状态：done（本功能块）；基线6f68437，主目录main，本地提交；持续目标active。
- 原完整凸起分段计时与payload一致后，合并四轮原rotated_path_values包装、材料帧投影/平方储能和法向转向速度，保留原类型/布局/标量顺序；原NumPy矩阵/范数及全部真实几何保持。
- 三原工况各四独立世界逐拍ABBA/反序完整前进，各有独立缓存；完整制动/转向/凸起墙钟再减{metric}%，实际CPU/尾延迟/初始化见记录，仍慢于实时。
- 1728子步全部payload及18组额外输入逐字节相同；31项新增、普通/Double T0各93项、Double42模块683项完整试验台回归/Ruff及真实记录复算通过。
- 初次3项F/C布局失败及Ruff导入格式失败已修复，原日志保留；没有放宽数值容差。原C计算段/查询/梯度/端口/摩擦判断保持，只有wheel重编。
- 证据与复现：[完整记录](../evidence/LAB-PERF-18/README.md)、summary.json与raw-evidence.zip，包含实际源码/五扩展/SDK、计数、完整状态和验证来源核对。
- 游戏seed/window与通用T1/T2/T3未跑；原完整精度/能量/人工/实时/EPA Gate开放。
- 下一：按新完整剖析继续道路查询与接触构型准备，不减物理细节。
''',encoding='utf-8')
progress=root/'docs/current-progress.md'
text=progress.read_text(encoding='utf-8')
start=text.index('当前施工仅试验台：');end=text.index('\n',start)
text=text[:start]+f'当前施工仅试验台：最新完成[LAB-PERF-18](tasks/LAB-PERF-18.md)四轮接触构型/材料帧批量准备，保留原旋转路径/投影算术与矩阵布局；三工况逐拍交叉整步墙钟再减{metric}%，1728子步完整结果逐字节一致。持续目标active，下一按新完整剖析继续道路查询与接触构型准备。下列历史节点只支持各自版本/协议，最新收益以本块同批对照为准。'+text[end:]
text+=f'\n- [LAB-PERF-18 四轮接触构型/材料帧准备](tasks/LAB-PERF-18.md)：以6f68437为基线，原完整凸起分段计时后将四轮原旋转路径包装/材料投影与原法向转向速度批量C准备，NumPy矩阵/范数/真实查询及完整模型保持。三工况四世界逐拍交叉整步−{metric}%；1728子步完整结果/18组输入逐字节一致，新增31项、普通/Double T0各93项、Double42模块683项与记录复算通过。初次F/C布局失败已按原布局修正，原日志保留；本地提交，持续目标active，原精度/人工/实时/EPA Gate开放。\n'
progress.write_text(text,encoding='utf-8')
print('report/task/progress written from checked actual results')
