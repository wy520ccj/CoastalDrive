import ast
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd()
sys.path.insert(0,str(root/'src'))
logs=root/'logs/lab-perf-18'
output=root/'docs/evidence/LAB-PERF-18'
output.mkdir(parents=True,exist_ok=True)
baseline=root/'builds/lab-perf-18/baseline/src'
suffixes=('.py','.c','.cpp','.h')
def hashes(folder):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix in suffixes}
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes
               and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['lab_contact_native.h','unsprung_contact_geometry.py','wheel_contact_kernels.c']
old_c=(baseline/'wheel_contact_kernels.c').read_text(encoding='utf-8')
new_c=(root/'src/wheel_contact_kernels.c').read_text(encoding='utf-8')
lines=new_c.splitlines(keepends=True)
added=[line for line in lines if any('"'+name+'"' in line for name in ('finite_contact_averages','finite_contact_frames'))]
assert len(added)==2 and ''.join(line for line in lines if line not in added)==old_c
assert (root/'src/lab_contact_native.h').read_text(encoding='utf-8').startswith((baseline/'lab_contact_native.h').read_text(encoding='utf-8').rsplit('#endif',1)[0])
old_py=(baseline/'unsprung_contact_geometry.py').read_text(encoding='utf-8')
new_py=(root/'src/unsprung_contact_geometry.py').read_text(encoding='utf-8')
assert (root/'tests/lab_contact_frames_reference.py').read_text(encoding='utf-8')==old_py
assert old_py.split('        middle = self.roads.query(',1)[1].split('        # 指定转向',1)[0]==new_py.split('        middle = self.roads.query(',1)[1].split('        # 指定转向',1)[0]
assert old_py.split('        friction,rolling = [],[]',1)[1].split('        geometry = replace(',1)[0]==new_py.split('        friction,rolling = [],[]',1)[1].split('        geometry = replace(',1)[0]
trees=[ast.parse(value) for value in (old_py,new_py)]
for name in ('RadialContactStep','__init__','query_cache'):
    nodes=[next(n for n in ast.walk(tree) if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name) for tree in trees]
    assert ast.dump(nodes[0])==ast.dump(nodes[1]),name

interleaved=json.loads((logs/'interleaved/summary.json').read_text(encoding='utf-8'))
groups=interleaved['groups']
assert len(groups)==3
substeps=0
native_by_label={}
for group in groups:
    scenario=group['scenario']
    folder=logs/'interleaved'/scenario
    assert group['exact'] and len(group['rows'])==4
    binaries=[(folder/(row['label']+'.bin')).read_bytes() for row in group['rows']]
    assert all(binary==binaries[0] for binary in binaries)
    reference=root/'logs/lab-perf-17/complete-final-AB'/('braking-A1' if scenario=='braking' else ('turning-A' if scenario=='turning' else 'nonlinear-A'))
    old_result=json.loads((reference/'result.json').read_text(encoding='utf-8'))
    assert binaries[0]==(reference/'payload.bin').read_bytes()
    assert group['actual_config']==old_result['config'] and group['options']==old_result['options'] and group['requested_config']==old_result['requested_config']
    payload=pickle.loads(binaries[0])
    assert len(payload['joint'])==group['rows'][0]['substeps']
    assert len(payload['snapshots'])==len(group['rows'][0]['step_seconds'])+1
    assert all(row['support_cache']==group['rows'][0]['support_cache'] and row['curvature_cache']==group['rows'][0]['curvature_cache'] for row in group['rows'])
    if scenario=='braking':assert max(command.brake for command in payload['commands'])==1.
    for row in group['rows']:
        substeps+=row['substeps']
        label=row['label'][0]
        source=baseline if label=='A' else root/'src'
        assert row['source_hashes']==hashes(source)
        assert row['payload_sha256']==hashlib.sha256(binaries[0]).hexdigest()
        native_by_label[label]=row['native']
        for name,data in row['native'].items():
            assert Path(data['path']).parent==source.resolve()
            assert hashlib.sha256(Path(data['path']).read_bytes()).hexdigest()==data['sha256']
assert substeps==1728
assert [name for name in native_by_label['A'] if native_by_label['A'][name]['sha256']!=native_by_label['B'][name]['sha256']]==['wheel_contact_kernels']

frozen=json.loads((logs/'frozen-results.json').read_text(encoding='utf-8'))
assert frozen['exact'] and len(frozen['runs'][0]['cases'])==18 and frozen['runs'][0]['cases']==frozen['runs'][1]['cases']
stages=json.loads((logs/'stage-diagnosis/stages.json').read_text(encoding='utf-8'))
assert stages['payload_exact'] and set(stages['counts'].values())=={14126}
assert (logs/'stage-diagnosis/payload.bin').read_bytes()==(logs/'interleaved/nonlinear-bump/A1.bin').read_bytes()
stage_result=json.loads((logs/'stage-diagnosis/result.json').read_text(encoding='utf-8'))
stage_eol_variants={}
for name,digest in stage_result['source_hashes'].items():
    raw=(baseline/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()==digest:continue
    lf=raw.replace(b'\r\n',b'\n')
    matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
    assert len(matched)==1,name
    stage_eol_variants[name]=matched[0]
assert {name:value['sha256'] for name,value in stage_result['native'].items()}=={name:value['sha256'] for name,value in native_by_label['A'].items()}

validation={name:json.loads((logs/name/'summary.json').read_text(encoding='utf-8')) for name in ('T0','T0-standard','lab-regression')}
assert all(data['passed'] for data in validation.values())
counts={}
for name in validation:
    matched=re.findall(r'(\d+) passed',(logs/name/'pytest.log').read_text(encoding='utf-8'))
    assert len(matched)==1
    counts[name]=int(matched[0])
assert counts=={'T0':93,'T0-standard':93,'lab-regression':683}
assert len(validation['lab-regression']['tests'])==42
build=(logs/'build-final.log').read_text(encoding='utf-8')
assert build.count("building '")==1 and "building 'wheel_contact_kernels' extension" in build and '/fp:strict' in build

def functions(profile,name,file=None):
    return [r for r in profile['functions'] if r['function']==name and (file is None or Path(r['file']).name==file)]
def calls(profile,name,file):
    rows=functions(profile,name,file)
    assert len(rows)==1,(name,file,len(rows))
    return rows[0]['calls']
def native_calls(profile,name):return sum(r['calls'] for r in profile['functions'] if 'wheel_contact_kernels.'+name+'>' in r['function'])
profile_counts={};eol_variants={}
road_tree=ast.parse((root/'src/radial_geometry.py').read_text(encoding='utf-8'))
road_class=next(n for n in road_tree.body if isinstance(n,ast.ClassDef) and n.name=='RadialRoads')
road_line=next(n.lineno for n in road_class.body if isinstance(n,ast.FunctionDef) and n.name=='query')
for old_folder,new_folder,expected in ((root/'logs/lab-perf-17/profile-after',logs/'profile-after',{'ticks':6,'residuals':1692,'geometry':540,'ports':552,'material':540,'road_queries':1122,'solve':2823,'norm':None}),
                                     (root/'logs/lab-perf-17/profile-final-bump',logs/'profile-final-bump',{'ticks':144,'residuals':44318,'geometry':14126,'ports':14414,'material':14126,'road_queries':29260,'solve':74040,'norm':354783})):
    old_result=json.loads((old_folder/'result.json').read_text(encoding='utf-8'))
    new_result=json.loads((new_folder/'result.json').read_text(encoding='utf-8'))
    assert old_result['config']==new_result['config'] and old_result['options']==new_result['options']
    variants={}
    for name,digest in old_result['source_hashes'].items():
        raw=(baseline/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()==digest:continue
        lf=raw.replace(b'\r\n',b'\n')
        matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
        assert len(matched)==1,name
        variants[name]=matched[0]
    eol_variants[old_folder.name]=variants
    if expected['ticks']==6:assert old_result['snapshot_hashes']==new_result['snapshot_hashes']
    else:
        assert (old_folder/'payload.bin').read_bytes()==(new_folder/'payload.bin').read_bytes()==(logs/'interleaved/nonlinear-bump/A1.bin').read_bytes()
        assert new_result['source_hashes']==hashes(root/'src')
    data={}
    for label,folder in (('before',old_folder),('after',new_folder)):
        profile=json.loads((folder/'profile.json').read_text(encoding='utf-8'))
        values={'ticks':profile['ticks'],'residuals':calls(profile,'evaluate','unsprung_joint.py'),
                'geometry':calls(profile,'evaluate','unsprung_contact_geometry.py'),'ports':calls(profile,'tire_ports','unsprung_drivetrain.py'),
                'material':calls(profile,'normal_material','unsprung_contact.py'),
                'road_queries':sum(r['calls'] for r in functions(profile,'query','radial_geometry.py') if r['line']==road_line),
                'solve':calls(profile,'solve','_linalg.py'),'norm':calls(profile,'norm','_linalg.py'),
                'project_deformation':calls(profile,'project_deformation','tire_compliance.py'),
                'column_stack':calls(profile,'column_stack','_shape_base_impl.py'),
                **{kernel:native_calls(profile,kernel) for kernel in ('rotated_path','finite_contact_averages','finite_contact_frames','box_cone_samples','box_cone_refine','radial_box_bounds','box_face_candidates')}}
        assert all(values[key]==value for key,value in expected.items() if value is not None),(label,values,expected)
        data[label]=values
    assert data['after']['finite_contact_averages']==data['after']['finite_contact_frames']==expected['geometry']
    for key,multiple in (('project_deformation',4),('column_stack',1),('rotated_path',4)):
        assert data['before'][key]-data['after'][key]==multiple*expected['geometry'],key
    assert data['before']['norm']==data['after']['norm']
    for kernel in ('box_cone_samples','box_cone_refine','radial_box_bounds','box_face_candidates'):
        assert data['before'][kernel]==data['after'][kernel]
    profile_counts[str(expected['ticks'])]=data

with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl') and 'user-data' not in path.parts:
            archive.write(path,path.relative_to(logs).as_posix())
    for folder in (root/'logs/lab-perf-17/profile-after',root/'logs/lab-perf-17/profile-final-bump'):
        for path in folder.iterdir():
            if path.is_file():archive.write(path,'reused-baseline/'+folder.name+'/'+path.name)
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/baseline/'+path.name)
    path=Path(native_by_label['B']['wheel_contact_kernels']['path']);archive.write(path,'executed-native/new/'+path.name)
    for name in ('src/unsprung_contact_geometry.py','src/lab_contact_native.h','src/wheel_contact_kernels.c','tests/test_lab_contact_frames.py','tests/lab_contact_frames_reference.py','tools/performance/compare_lab_compute.py'):
        archive.write(root/name,'executed-source/'+name)
summary={'baseline':'6f68437','changes':changes,'groups':groups,'substeps':substeps,'frozen_scenarios':frozen,'stage_diagnosis':stages,'stage_diagnosis_EOL_variants':stage_eol_variants,
         'validation':validation,'validation_counts':counts,'profile_counts':profile_counts,'reused_profile_EOL_variants':eol_variants,
         'native':native_by_label,'old_C_prefix_and_existing_functions_exact':True,'query_gradient_ports_and_friction_logic_exact':True,
         'formal_T1_T2_T3':'not_run; 仅试验台专项完整回归/记录复算，未跑游戏seed/window',
         'fidelity':'原120Hz/双子步/34变量/完整真实几何/差分/Newton/Box52轮细化/参数/门槛保持，全部输出逐字节一致',
         'open_gates':['实时','人工体验','原完整能量/精度','EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':hashlib.sha256((output/'raw-evidence.zip').read_bytes()).hexdigest()}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print([{k:group[k] for k in ('scenario','wall_seconds_reduction_percent','cpu_seconds_reduction_percent')} for group in groups])
print('source/native/independent cache/full payload/config/profiles/validation verified')
