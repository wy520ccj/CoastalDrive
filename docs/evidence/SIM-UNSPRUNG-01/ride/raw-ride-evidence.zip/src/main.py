"""Source and packaged entry point; headless runs never import the renderer."""

import argparse
import json
import logging
import multiprocessing
import os
import traceback
from dataclasses import asdict
from pathlib import Path

from paths import user_data


def main():
    from vehicle_designs import DESIGN_VEHICLES, vehicle_design

    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--lab", action="store_true", help="打开车辆动力学实验室")
    parser.add_argument("--steps", type=int, default=10000)
    parser.add_argument("--traffic-count", type=int, help="无窗口实验的交通车数；省略时按赛道默认值")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--physics-workers", type=int, help="数值进程数；窗口正常模式默认0，困难模式按CPU启用")
    parser.add_argument("--synchronous-physics", action="store_true", help="诊断用：在绘制线程推进固定物理步")
    parser.add_argument("--driving-mode", choices=("game", "simulation"))
    parser.add_argument("--vehicle-design", choices=tuple(v.id for v in DESIGN_VEHICLES),
                        help="明确选择工程硬件；输入模式只改变辅助")
    parser.add_argument("--vehicle-config", type=Path, help="无窗口入口：重建前加载工程JSON")
    parser.add_argument("--abs", dest="abs_selection", choices=("on", "off"))
    parser.add_argument("--tcs", dest="tcs_selection", choices=("on", "off"))
    parser.add_argument("--esc", dest="esc_selection", choices=("on", "off"))
    parser.add_argument("--road-shape", choices=("straight", "curves", "hills"), default="straight")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--window-smoke", action="store_true")
    parser.add_argument("--profile-startup", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--track", choices=("coastal", "highway", "endless", "test"), default="coastal"
    )
    args = parser.parse_args()
    from driving_modes import DrivingMode

    driving_mode = DrivingMode(args.driving_mode) if args.driving_mode else None
    abs_enabled = None if args.abs_selection is None else args.abs_selection == "on"
    tcs_enabled = None if args.tcs_selection is None else args.tcs_selection == "on"
    esc_enabled = None if args.esc_selection is None else args.esc_selection == "on"
    if args.steps <= 0:
        parser.error("--steps must be positive")
    if args.lab and (args.headless or args.smoke or args.window_smoke or args.profile_startup):
        parser.error("--lab用于交互实验室，不能与游戏诊断入口组合")
    if args.traffic_count is not None and (args.traffic_count<0 or not args.headless):
        parser.error("--traffic-count须非负且只用于--headless")
    if args.physics_workers is not None and not 0 <= args.physics_workers <= 32:
        parser.error("--physics-workers must be between 0 and 32")
    if args.vehicle_config is not None and not args.headless:
        parser.error("--vehicle-config仅用于无窗口工程实验，请同时指定--headless")
    if args.profile_startup and (args.headless or args.smoke or args.window_smoke):
        parser.error("--profile-startup requires a visible menu run")
    if args.headless:
        from controls import ConstantController
        from simulation import FIXED_DT, Control, Simulation

        selected = driving_mode or DrivingMode.GAME
        base_config = vehicle_design(args.vehicle_design or "game-tuned").config
        if args.vehicle_config is not None:
            from vehicle_parameters import load_vehicle_config

            base_config = load_vehicle_config(args.vehicle_config, base_config)
        config = selected.configured_vehicle(abs_enabled, tcs_enabled, esc_enabled, base_config=base_config)
        simulation = Simulation(
            args.seed, track=args.track, road_shape=args.road_shape,
            traffic_count=args.traffic_count,
            config=config, input_config=selected.input_config, physics_workers=args.physics_workers or 0,
        )
        controller = ConstantController(Control(throttle=0.5))
        try:
            for _ in range(args.steps):
                simulation.step(controller.sample(simulation.snapshot(), FIXED_DT))
            report = asdict(simulation.snapshot())
            report["driving_mode"] = selected.value
            report["vehicle_config"] = asdict(config)
            report["physics_workers"] = simulation._physics_workers.diagnostics() if simulation._physics_workers is not None else None
            print(json.dumps(report, indent=2))
        finally:
            simulation.close()
        return 0
    startup = None
    if args.profile_startup:
        from performance_baseline import StartupTrace

        origin = os.environ.get("COASTALDRIVE_STARTUP_ORIGIN_NS")
        startup = StartupTrace(int(origin) if origin is not None else None)
        startup.mark("entrypoint_ready")
    logging.basicConfig(filename=user_data() / "runtime.log", level=logging.INFO, encoding="utf-8")
    from application import CoastalDrive

    if startup is not None:
        startup.mark("application_imported")
        app = CoastalDrive(onscreen=True, output=args.output, seed=args.seed, track=args.track,
                           road_shape=args.road_shape, startup_trace=startup,
                           driving_mode=driving_mode, vehicle_design_id=args.vehicle_design,
                           abs_enabled=abs_enabled, tcs_enabled=tcs_enabled, esc_enabled=esc_enabled,
                           physics_workers=args.physics_workers,independent_clock=not args.synchronous_physics)
        try:
            app.taskMgr.step()
            startup.mark("first_rendered_frame")
            if app.main_menu.root.isHidden() or app.panel_option_count != 0:
                raise RuntimeError("主菜单首帧未准备好")
            startup.mark("main_menu_usable")
            report = startup.finish()
            report["scenario"] = "visible coastal main menu, then 8-car free drive"
            report["startup_scene_created"] = app.scene is not None
            report["startup_traffic_count"] = 0
            if report["startup_scene_created"]:
                raise RuntimeError("主菜单启动时不应创建 Gameplay Scene")
            report["resolution"] = [app.win.getXSize(), app.win.getYSize()]
            report["renderer"] = app.win.getGsg().getDriverRenderer()
            from panda3d.core import Filename

            args.profile_startup.parent.mkdir(parents=True, exist_ok=True)
            screenshot = args.profile_startup.with_suffix(".png")
            if not app.win.getScreenshot().write(Filename.fromOsSpecific(str(screenshot))):
                raise RuntimeError("启动首帧截图未保存")
            report["first_frame_capture"] = screenshot.name
            from race import GameMode

            drive_trace = StartupTrace()
            app.startup_trace = drive_trace
            drive_trace.mark("drive_transition_started")
            app.start_game(mode=GameMode.FREE_DRIVE, track="coastal")
            app.taskMgr.step()
            drive_trace.mark("first_drive_frame")
            report["drive_transition"] = drive_trace.finish()
            report["drive_traffic_count"] = len(app.scene.traffic)
            report["drive_transition_s"] = round(
                (drive_trace.events[-1][1] - drive_trace.events[0][1]) / 1e9, 4
            )
            if report["drive_traffic_count"] != 8:
                raise RuntimeError("性能基线未创建预期的八辆交通车")
            args.profile_startup.write_text(json.dumps(report, indent=2), encoding="utf-8")
            print(json.dumps(report, indent=2))
            return 0
        finally:
            app.close_game()

    smoke = args.smoke or args.window_smoke
    workspace = "lab" if args.lab else "game"
    while workspace is not None:
        if workspace == "lab":
            from lab_application import VehicleLab

            app = VehicleLab(output=args.output)
        else:
            app = CoastalDrive(
                smoke=smoke, onscreen=args.window_smoke, output=args.output,
                seed=args.seed, track=args.track, road_shape=args.road_shape,
                driving_mode=driving_mode, vehicle_design_id=args.vehicle_design,
                abs_enabled=abs_enabled, tcs_enabled=tcs_enabled, esc_enabled=esc_enabled,
                physics_workers=args.physics_workers,
                independent_clock=not (smoke or args.synchronous_physics),
            )
        try:
            app.run()
            workspace = app.next_workspace
            if smoke:
                return 0 if app.smoke_passed else 1
        finally:
            app.close_game()
    return 0


if __name__ == "__main__":
    # 冻结游戏的子进程先进入标准数值工作入口，不能再次启动窗口或创建进程池。
    multiprocessing.freeze_support()
    try:
        result = main()
    except Exception:
        # Report entry-point failures; exceptions are not swallowed in the game loop.
        user_data().joinpath("crash.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise
    raise SystemExit(result)
