"""归档实际推进节点的已执行源和证据；后续数学展示修订单独保存。"""

import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"src"))

from lab_records import model_fingerprint


def archive():
    output = ROOT/"docs/evidence/SIM-UNSPRUNG-01/guide-ports"
    output.mkdir(parents=True,exist_ok=True)
    source = model_fingerprint()
    results = {}
    for name in ("guide-port-ride-2-r1","guide-port-ride-4-r1","guide-port-ride-8-r1","guide-port-manual-2-r2"):
        value = json.loads((ROOT/"logs/SIM-UNSPRUNG-01"/name/"result.json").read_text(encoding="utf-8"))
        assert value["source"]==source
        results[name] = {"steps":value["summary"]["ticks"]*value["substeps"],
            "sum":value["sum"],"max_abs":value["max_abs"],"summary":value["summary"]}
    record = ROOT/"logs/SIM-UNSPRUNG-01/guide-port-record-r1/mass-40/experiment.json"
    metadata = json.loads(record.read_text(encoding="utf-8"))
    assert metadata["source_start"]==metadata["source_end"]==source
    for relative,digest in source.items():
        assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==digest
    results["ride_braking_record"] = json.loads((record.parents[1]/"result.json").read_text(encoding="utf-8"))
    results["baseline"] = {str(n):json.loads((ROOT/f"logs/SIM-UNSPRUNG-01/lab-origin-edge-energy-{n}-r1/result.json").read_text(encoding="utf-8"))
                           for n in (2,4,8)}
    (output/"comparison.json").write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding="utf-8")
    (output/"source.json").write_text(json.dumps(source,indent=2),encoding="utf-8")
    assets = [p for folder in (ROOT/"src/ui",ROOT/"assets/game/ui/formulas") for p in folder.rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    with zipfile.ZipFile(output/"executed-model.zip","w",zipfile.ZIP_DEFLATED) as package:
        for path in [*(ROOT/relative for relative in source),*assets]:package.write(path,path.relative_to(ROOT))
    folders = [p for p in (ROOT/"logs/SIM-UNSPRUNG-01").iterdir()
               if p.is_dir() and (p.name.startswith("guide-port-") or p.name.startswith("guide-momentum-"))]
    files = [p for folder in folders for p in folder.rglob("*") if p.is_file()]
    files += [ROOT/"tools/physics/guide_port_archive.py",ROOT/"tools/physics/unsprung_guide_momentum_check.py"]
    with zipfile.ZipFile(output/"raw-evidence.zip","w",zipfile.ZIP_DEFLATED) as package:
        for path in files:package.write(path,path.relative_to(ROOT))
    manifest = {"baseline":"54c913e","files":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
                "archives":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.glob("*.zip")},
                "source_current_at_archive":True,"record_source_start_end_equal":True,
                "note":"Actual physics and full record source archived before subsequent presentation-only formula revision."}
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(json.dumps({"files":len(files),"model_files":len(source),"records_recalculated":1}))


if __name__=="__main__":archive()
