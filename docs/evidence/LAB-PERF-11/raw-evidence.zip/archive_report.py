import hashlib,importlib.util,json,pickle,sys,zipfile
from pathlib import Path
import numpy as np
root=Path.cwd();logs=root/'logs/lab-perf-11';output=root/'docs/evidence/LAB-PERF-11';output.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
prior=read(root/'docs/evidence/LAB-PERF-10/summary.json')
rows=read(logs/'full-step/summary.json');assert len(rows)==4
suffixes=('.py','.c','.cpp','.h')
current={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src').iterdir() if p.suffix in suffixes}
previous=read(root/'logs/lab-perf-10/complete-AB/braking-B1/result.json')['source_hashes']
assert current.keys()==previous.keys()
eol={}
for name,old_hash in previous.items():
    if current[name]==old_hash:continue
    raw=(root/'src'/name).read_bytes().replace(b'\r\n',b'\n')
    variants={label for label,value in [('LF',raw),('CRLF',raw.replace(b'\n',b'\r\n'))] if hashlib.sha256(value).hexdigest()==old_hash}
    assert len(variants)==1,name
    eol[name]=next(iter(variants))
for label in ['A','B']:
    source=root/'builds/lab-perf-10/baseline/src' if label=='A' else root/'src'
    for row in [r for r in rows if '-'+label in r['case']]:
        assert row['source_hashes']=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix in suffixes}
        assert row['runtime']==rows[0]['runtime'] and row['substeps']==48 and row['complete_payload_equal']
        assert row['config']==rows[0]['config'] and row['options']==rows[0]['options']
        for name,value in row['native'].items():
            assert Path(value['path']).parent==source.resolve()
            assert value['sha256']==prior['native_sha256'][label][name]
reference=(root/'logs/lab-perf-10/complete-AB/braking-A1/payload.bin').read_bytes()
for row in rows:assert (logs/'full-step'/row['case']/'payload.bin').read_bytes()==reference
native=read(logs/'native-crossover-final/summary.json');initial=read(logs/'native-crossover/summary.json')
assert len(native['captured'])==48 and native['new_box_paths_executed']==0 and native['complete_numeric_fields_exact']
assert native['binding_count']==len(native['bindings'])==110
assert [r['reference_sha256'] for r in native['captured']]==[r['reference_sha256'] for r in initial['captured']]
assert native['experiment']['config']==rows[0]['config'] and native['experiment']['options']==rows[0]['options']
for label in ['A','B']:assert native['native'][label]['sha256']==prior['native_sha256'][label]['wheel_contact_kernels']
for row in native['captured']:assert hashlib.sha256((logs/'native-crossover-final/inputs'/row['path']).read_bytes()).hexdigest()==row['input_sha256']
sys.path.insert(0,str(root/'src'))
spec=importlib.util.spec_from_file_location('lab_crossover_check',root/'tools/performance/compare_lab_native_crossover.py')
comparator=importlib.util.module_from_spec(spec);spec.loader.exec_module(comparator)
full_payload=pickle.loads(reference)
independent_hashes=[]
for joint in full_payload['joint']:
    value={key:comparator.numeric(item) for key,item in joint.items()}
    independent_hashes.append(hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest())
assert independent_hashes==[row['reference_sha256'] for row in native['captured']]
assert len(native['rows'])==8 and native['warmup_batches']==2
assert all(r['complete_numeric_fields_exact'] and len(r['substep_seconds'])==48 for r in native['rows'])
assert native['runtime']==prior['validation']['lab-regression']['runtime']
validation=read(logs/'T0/summary.json');assert validation['passed']
(logs/'notes.md').write_text('''# 核查范围\n\n生产物理源码/参数未修改，五扩展SHA与LAB-PERF-10最终版本相同；源码仅允许逐项用原SHA精确匹配LF/CRLF变体，正文没有变化。SDK指纹也相同，旧413项完整专项标明复用而非重跑。\n\n先独立运行同进程交叉初探，再跑完整制动ABBA，最后重跑交叉诊断补齐每个切换绑定/输入文件SHA等验收记录；三组没有并发。初探原工具字节单独保存，最终工具在另一新输出目录执行，旧数据保留。\n\n冻结输入仅来自本工具实际制动过程的可信内部检查点，必须先对实际原解逐项通过位模式比较；检查点序列化可能重建数组存储布局。它不含世界推进/快照/UI，不能代替整步性能Gate。110处Python可见wheel引用临时切换并在finally恢复，两个新增Box入口均断言禁止，记录调用0。\n\n每种先预热一批，正式按ABBABAAB运行八批48个冻结解，计时不含摘要计算/序列化；实际数值字段、数组dtype/shape/原始字节与Python标量位模式逐项相同。\n\n完整制动4次仍用原0.2模拟秒/24拍协议及独立进程，两次旧/新实际源码与DLL路径/摘要核对，完整payload与上一轮原文件严格逐字节相同。普通braking确实在首计算拍制动，onset不控制此命名工况。\n\n本轮没有物理生产改动，只新增诊断工具与比较器检查，未再跑原413项。Ruff及新比较器3项T0通过，不宣称通用T1/T2/T3、实时/人工或完整精度Gate通过。未设置CPU优先级/亲和性/时钟，也未记录能唯一归因的硬件频率/温度；结论只到未稳定复现代码回退。\n''',encoding='utf-8')
measured={}
for label in ['A','B']:
    sample=[r for r in rows if '-'+label in r['case']];steps=[v for r in sample for v in r['step_seconds']]
    measured[label]={key:float(np.mean([r[key] for r in sample])) for key in ['wall_seconds','cpu_seconds']}
    measured[label].update({'step_p95_seconds':float(np.percentile(steps,95)),'step_p99_seconds':float(np.percentile(steps,99)),'initialization_wall_seconds':float(np.mean([r['initialization']['wall_seconds'] for r in sample]))})
with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(logs.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.py','.md','.pkl','.bin') and 'user-data' not in p.parts:archive.write(p,p.relative_to(logs).as_posix())
    for path in ['tools/performance/compare_lab_native_crossover.py','tools/performance/compare_lab_compute.py','tools/physics/unsprung_step_checkpoint.py','tests/test_lab_crossover_diagnostics.py']:
        archive.write(root/path,'executed-source/'+path)
    for label,path in [('A',Path(native['native']['A']['path'])),('B',Path(native['native']['B']['path']))]:archive.write(path,'executed-native/'+label+'/'+path.name)
summary={'baseline':'46560d6','compared_pre_optimization':'c18179e','production_source_unchanged':True,'source_EOL_variants':eol,'native_SHA_unchanged_from_LAB_PERF_10':prior['native_sha256']['B'],'native_crossover':native,'initial_crossover':initial,'frozen_reference_matches_independent_full_step':True,'full_step':{'cases':rows,'measured':measured,'total_substeps':192,'complete_payload_exact':True,'wall_reduction_percent':100*(1-measured['B']['wall_seconds']/measured['A']['wall_seconds'])},'validation':validation,'reused_validation':{'task':'LAB-PERF-10','Double_lab_tests':413,'source_and_all_native_SHA_and_SDK_verified':True,'rerun':False},'conclusion':'同进程原生交叉与新一批完整制动均未测得稳定回退；旧异常保留，不唯一归因硬件/调度，不宣称实时或尾延迟Gate通过','continuous_goal':'active','raw_evidence_sha256':hashlib.sha256((output/'raw-evidence.zip').read_bytes()).hexdigest()}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'full_step':measured,'wall_reduction_percent':summary['full_step']['wall_reduction_percent'],'native_crossover_reduction_percent':native['wall_reduction_percent'],'source_EOL_variants':len(eol)},ensure_ascii=False))
