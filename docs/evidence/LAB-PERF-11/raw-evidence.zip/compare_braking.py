import json,subprocess,sys
from pathlib import Path
root=Path.cwd();output=root/'logs/lab-perf-11/full-step';output.mkdir(parents=True,exist_ok=False)
rows=[];reference=(root/'logs/lab-perf-10/complete-AB/braking-A1/payload.bin').read_bytes()
for name,source in [('braking-A1',root/'builds/lab-perf-10/baseline'),('braking-B1',root),('braking-B2',root),('braking-A2',root/'builds/lab-perf-10/baseline')]:
    command=[sys.executable,str(root/'tools/physics/run_sim_double.py'),str(root/'tools/performance/compare_lab_compute.py'),'--worker','--source',str(source),'--scenario','braking','--output',str(output/name)]
    print('RUN',name,flush=True)
    with (output/(name+'.txt')).open('w',encoding='utf-8') as stream:subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=240)
    row=json.loads((output/name/'result.json').read_text(encoding='utf-8'));assert(output/name/'payload.bin').read_bytes()==reference
    rows.append({'case':name,**row,'complete_payload_equal':True});print('PASSED',name,row['wall_seconds'],flush=True)
(output/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
