import json,sys,time
from pathlib import Path
root=Path.cwd()
sys.path.insert(0,str(root/'src'))
import numpy as np
import unsprung_joint
from lab_experiment import LabExperiment,LabOptions
from vehicle_parameters import config_from_document
from vehicle_designs import vehicle_design
from vehicle_unsprung import UnsprungAdvanceInput

doc=json.loads((root/'docs/evidence/SIM-UNSPRUNG-01/production/engineering-preview.json').read_text(encoding='utf-8'))
config=config_from_document(doc,vehicle_design('reference-rwd').config)
run=LabExperiment(LabOptions(duration=.05),config=config,parameter_metadata=doc['metadata'])
original_solve=UnsprungAdvanceInput.solve
original_gyro=unsprung_joint.native_gyro_impulse
groups=[]
active=None

def gyro(inertia,angular,dt):
    key=angular.tobytes()
    active['calls']+=1
    active['hits']+=key in active['keys']
    active['consecutive']+=key==active['last']
    active['keys'].add(key)
    active['last']=key
    return original_gyro(inertia,angular,dt)

def solve(value,**kwargs):
    global active
    active={'calls':0,'hits':0,'consecutive':0,'keys':set(),'last':None}
    before=time.perf_counter()
    result=original_solve(value,**kwargs)
    groups.append({'calls':active['calls'],'exact_dictionary_hits':active['hits'],'consecutive_hits':active['consecutive'],'unique':len(active['keys']),'seconds':time.perf_counter()-before,'iterations':result.iterations})
    return result

UnsprungAdvanceInput.solve=solve
unsprung_joint.native_gyro_impulse=gyro
try:
    while not run.done:run.step()
finally:
    UnsprungAdvanceInput.solve=original_solve
    unsprung_joint.native_gyro_impulse=original_gyro
    run.close()
report={'baseline':'bd65709','ticks':6,'groups':groups,'total_calls':sum(g['calls'] for g in groups),'dictionary_hits':sum(g['exact_dictionary_hits'] for g in groups),'consecutive_hits':sum(g['consecutive_hits'] for g in groups)}
(root/'logs/lab-perf-07/gyro-reuse-probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='groups'}))
