import hashlib
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
sys.path.insert(0, str(root/"src"))
logs = root/"logs/lab-perf-08"
output = root/"docs/evidence/LAB-PERF-08"
output.mkdir(parents=True, exist_ok=True)
baseline = root/"builds/lab-perf-08/baseline/src"
suffixes = (".py", ".c", ".cpp", ".h")
old_names = {p.name for p in baseline.iterdir() if p.suffix in suffixes}
new_names = {p.name for p in (root/"src").iterdir() if p.suffix in suffixes}
changes = sorted(name for name in old_names | new_names if name not in old_names or name not in new_names
                 or (baseline/name).read_bytes().replace(b"\r\n", b"\n") != (root/"src"/name).read_bytes().replace(b"\r\n", b"\n"))
assert changes == ["lab_joint_native.h", "mechanical_kernels.c", "unsprung_joint.py"]
old_joint=(baseline/"unsprung_joint.py").read_text(encoding="utf-8")
new_joint=(root/"src/unsprung_joint.py").read_text(encoding="utf-8")
marker="    config_rear = replace(config,lateral_stiffness=config.rear_lateral_stiffness)"
assert old_joint[old_joint.index(marker):] == new_joint[new_joint.index(marker):]
old_c=(baseline/"mechanical_kernels.c").read_text(encoding="utf-8")
new_c=(root/"src/mechanical_kernels.c").read_text(encoding="utf-8")
for added in ('#include "lab_joint_native.h"\n\n',
    '    {"unsprung_contact_residual",unsprung_contact_residual_native,METH_VARARGS,"试验台四轮原材料残差批量组装"},\n',
    '    {"unsprung_port_residual",unsprung_port_residual_native,METH_VARARGS,"试验台完整有限端口残差批量组装"},\n'):
    assert added in new_c
    new_c=new_c.replace(added,"",1)
assert old_c==new_c
rows = json.loads((logs/"complete-AB/summary.json").read_text(encoding="utf-8"))
assert len(rows)==10
confirmation=json.loads((logs/"bump-confirmation/summary.json").read_text(encoding="utf-8"))
assert confirmation[:2]==[row for row in rows if row["scenario"]=="nonlinear-bump"]
initial_bump_pair=[{"case":row["case"],"wall_seconds":row["wall_seconds"],"cpu_seconds":row["cpu_seconds"]} for row in confirmation[:2]]
rows+=confirmation[2:]
assert len(rows)==12 and sum(row["substeps"] for row in rows)==1728

def case_root(row):
    return logs/("bump-confirmation" if row["case"] in ("nonlinear-B2","nonlinear-A2") else "complete-AB")/row["case"]

native_by_label = {}
for label in ("A", "B"):
    cases = [row for row in rows if "-"+label in row["case"]]
    native_by_label[label] = {name: value["sha256"] for name, value in cases[0]["native"].items()}
    assert all({name: value["sha256"] for name, value in row["native"].items()} == native_by_label[label] for row in cases)
    source = baseline if label == "A" else root/"src"
    for name, value in cases[0]["native"].items():
        assert Path(value["path"]).parent == source.resolve()
        assert hashlib.sha256(Path(value["path"]).read_bytes()).hexdigest() == value["sha256"]
assert [name for name in native_by_label["A"] if native_by_label["A"][name] != native_by_label["B"][name]] == ["mechanical_kernels"]
assert all(row["runtime"] == rows[0]["runtime"] and row["complete_payload_equal"] and row["substeps"] == 2*row["ticks"] for row in rows)
for row in rows:
    source = baseline if "-A" in row["case"] else root/"src"
    assert row["source_hashes"] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix in suffixes}
groups = []
for scenario in ("braking", "turning", "nonlinear-bump"):
    cases = [row for row in rows if row["scenario"] == scenario]
    expected = (case_root(cases[0])/"payload.bin").read_bytes()
    for row in cases:
        actual = (case_root(row)/"payload.bin").read_bytes()
        assert actual == expected and row["payload_sha256"] == hashlib.sha256(expected).hexdigest()
        assert row["config"] == cases[0]["config"] and row["options"] == cases[0]["options"]
    payload = pickle.loads(expected)
    assert len(payload["snapshots"]) == cases[0]["ticks"]+1 and len(payload["joint"]) == cases[0]["substeps"]
    assert all(row["joint_iterations"] == cases[0]["joint_iterations"] for row in cases)
    measured = {}
    for label in ("A", "B"):
        sample = [row for row in cases if "-"+label in row["case"]]
        steps = [dt for row in sample for dt in row["step_seconds"]]
        measured[label] = {"runs": len(sample),
            **{key: float(np.mean([r[key] for r in sample])) for key in ("wall_seconds", "cpu_seconds", "physics_snapshot_seconds")},
            "step_p95_seconds": float(np.percentile(steps, 95)), "step_p99_seconds": float(np.percentile(steps, 99)),
            "initialization": {key: float(np.mean([r["initialization"][key] for r in sample]))
                               for key in ("wall_seconds", "cpu_seconds", "ticks")}}
    group = {"scenario": scenario, "options": cases[0]["options"], "actual_config": cases[0]["config"],
             "requested_config": cases[0]["requested_config"], "measured": measured,
             "wall_reduction_percent": 100*(1-measured["B"]["wall_seconds"]/measured["A"]["wall_seconds"]),
             "cpu_reduction_percent": 100*(1-measured["B"]["cpu_seconds"]/measured["A"]["cpu_seconds"]),
             "complete_payload_exact": True, "payload_sha256": hashlib.sha256(expected).hexdigest()}
    if scenario == "nonlinear-bump":
        assert group["actual_config"]["suspension_coil_enabled"] and group["actual_config"]["suspension_damper_curves"]
        load = np.asarray([s.player.unsprung_state.normal_force for s in payload["snapshots"]])
        group["peak_normal_load_change_from_initial_N"] = np.max(abs(load-load[0]), axis=0).tolist()
        assert group["peak_normal_load_change_from_initial_N"][0] > 100 and group["peak_normal_load_change_from_initial_N"][2] > 100
    groups.append(group)
frozen = json.loads((logs/"frozen-results.json").read_text(encoding="utf-8"))
assert frozen["exact"] and len(frozen["runs"][0]["cases"]) == 18 and frozen["runs"][0]["cases"] == frozen["runs"][1]["cases"]
import re
validation_counts={}
for folder,name in (("T0","Double_T0"),("T0-standard","standard_T0"),("lab-regression","Double_lab_regression")):
    log=(logs/folder/"pytest.log").read_text(encoding="utf-8")
    matches=re.findall(r"(\d+) passed",log)
    assert len(matches)==1
    validation_counts[name]=int(matches[0])
assert validation_counts["Double_lab_regression"]==348
validation = {name: json.loads((logs/name/"summary.json").read_text(encoding="utf-8"))
              for name in ("T0", "T0-standard", "lab-regression")}
assert all(result["passed"] for result in validation.values())
old_profile_root = root/"logs/lab-perf-07/profile-after"
old_profile_result = json.loads((old_profile_root/"result.json").read_text(encoding="utf-8"))
for name in ("unsprung_joint.py", "unsprung_contact_geometry.py", "unsprung_drivetrain.py", "radial_geometry.py", "unsprung_dynamics.py", "unsprung_motion.py"):
    assert hashlib.sha256((baseline/name).read_bytes()).hexdigest() == old_profile_result["source_hashes"][name]
for path in baseline.glob("*.pyd"):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == old_profile_result["source_hashes"][path.name]
new_profile_result=json.loads((logs/"profile-after/result.json").read_text(encoding="utf-8"))
assert old_profile_result["config"] == new_profile_result["config"]
assert old_profile_result["options"] == new_profile_result["options"]
assert old_profile_result["snapshot_hashes"] == new_profile_result["snapshot_hashes"]
profiles = {"before": json.loads((old_profile_root/"profile.json").read_text(encoding="utf-8")),
            "after": json.loads((logs/"profile-after/profile.json").read_text(encoding="utf-8"))}
import ast
query_lines = {}
for label, path in (("before", baseline/"radial_geometry.py"),("after",root/"src/radial_geometry.py")):
    tree=ast.parse(path.read_text(encoding="utf-8"))
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="RadialRoads")
    query_lines[label]=next(n.lineno for n in node.body if isinstance(n,ast.FunctionDef) and n.name=="query")
profile_rows = {}
for label, profile in profiles.items():
    def calls(name, file, line=None):
        found = [row for row in profile["functions"] if row["function"] == name and Path(row["file"]).name == file
                 and (line is None or row["line"] == line)]
        assert len(found) == 1
        return found[0]["calls"]
    profile_rows[label] = {"ticks": profile["ticks"], "residual_calls": calls("evaluate", "unsprung_joint.py"),
                           "road_geometry_queries": calls("query", "radial_geometry.py", query_lines[label]),
                           "port_assembly_calls": calls("tire_ports", "unsprung_drivetrain.py"),
                           "generic_concatenation_calls": calls("__getitem__", "_index_tricks_impl.py"),
                           "numpy_cross_calls": calls("cross", "numeric.py"),
                           "native_body_torque_calls": sum(r["calls"] for r in profile["functions"] if "wheel_contact_kernels.unsprung_body_torque>" in r["function"])}
for values in profile_rows.values():
    assert {k: values[k] for k in ("ticks", "residual_calls", "road_geometry_queries", "port_assembly_calls")} == {"ticks": 6, "residual_calls": 1692, "road_geometry_queries": 1122, "port_assembly_calls": 552}
assert profile_rows["before"]["generic_concatenation_calls"] == profile_rows["after"]["generic_concatenation_calls"] == 186
assert profile_rows["before"]["numpy_cross_calls"] == profile_rows["after"]["numpy_cross_calls"] == 894
assert profile_rows["before"]["native_body_torque_calls"] == profile_rows["after"]["native_body_torque_calls"] == 1692
for label,profile in profiles.items():
    for kernel in ("radial_plane_values","radial_contact_frames"):
        profile_rows[label]["native_"+kernel+"_calls"]=sum(r["calls"] for r in profile["functions"] if "wheel_contact_kernels."+kernel+">" in r["function"])
for label,profile in profiles.items():
    for name,file in (("native_gyro_impulse","unsprung_dynamics.py"),("rotation_increment","unsprung_motion.py"),("solve","_linalg.py")):
        selected=[r for r in profile["functions"] if r["function"]==name and Path(r["file"]).name==file]
        assert len(selected)==1
        profile_rows[label][name+"_calls"]=selected[0]["calls"]
assert profile_rows["before"]["native_gyro_impulse_calls"] == 1095
assert profile_rows["after"]["native_gyro_impulse_calls"] == 1095
assert [profile_rows[label]["rotation_increment_calls"] for label in ("before","after")]==[1080,1080]
assert profile_rows["before"]["solve_calls"] == profile_rows["after"]["solve_calls"] == 2823
for label,profile in profiles.items():
    for name,file in (("contact_force","tire_compliance.py"),("clip","fromnumeric.py")):
        profile_rows[label][name+"_calls"]=sum(r["calls"] for r in profile["functions"] if r["function"]==name and Path(r["file"]).name==file)
    for kernel in ("unsprung_contact_residual","unsprung_port_residual"):
        profile_rows[label][kernel+"_calls"]=sum(r["calls"] for r in profile["functions"] if "mechanical_kernels."+kernel+">" in r["function"])
assert profile_rows["before"]["contact_force_calls"]==6768 and profile_rows["after"]["contact_force_calls"]==0
assert profile_rows["before"]["clip_calls"]==5076 and profile_rows["after"]["clip_calls"]==0
assert profile_rows["after"]["unsprung_contact_residual_calls"]==profile_rows["after"]["unsprung_port_residual_calls"]==1692
build=(logs/"build-final.log").read_text(encoding="utf-8")
assert "building 'mechanical_kernels' extension" in build and "/fp:strict" in build and build.count("building '")==1
bump_profile=json.loads((logs/"profile-bump/profile.json").read_text(encoding="utf-8"))
bump_result=json.loads((logs/"profile-bump/result.json").read_text(encoding="utf-8"))
assert (logs/"profile-bump/payload.bin").read_bytes()==(logs/"complete-AB/nonlinear-B/payload.bin").read_bytes()
assert bump_result["config"]==next(row["config"] for row in rows if row["case"]=="nonlinear-B")
assert bump_result["source_hashes"]==next(row["source_hashes"] for row in rows if row["case"]=="nonlinear-B")
bump_hotspots={}
for name,file in (("box_section","box_radial_geometry.py"),("evaluate","box_radial_geometry.py"),("query","radial_geometry.py")):
    found=[r for r in bump_profile["functions"] if r["function"]==name and Path(r["file"]).name==file]
    if name=="query":
        found=[r for r in found if r["line"]==query_lines["after"]]
    assert len(found)==1
    bump_hotspots[name]={**found[0],"fraction_of_profile_total":found[0]["cumulative_seconds"]/bump_profile["total_seconds"]}
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".log", ".txt", ".py", ".md", ".bin", ".prof") and "user-data" not in path.parts:
            archive.write(path, path.relative_to(logs).as_posix())
    for path in old_profile_root.iterdir():
        if path.is_file():
            archive.write(path, "reused-baseline-profile/"+path.name)
    for path in baseline.glob("*.pyd"):
        archive.write(path,"executed-native/baseline/"+path.name)
    path=next((root/"src").glob("mechanical_kernels*.pyd"))
    archive.write(path,"executed-native/new/"+path.name)
    for path in ("tools/performance/compare_lab_compute.py","src/unsprung_joint.py","src/lab_joint_native.h","src/mechanical_kernels.c","setup.py","tests/lab_joint_residual_reference.py","tests/test_lab_joint_native.py"):
        archive.write(root/path,"executed-source/"+path)
summary = {"baseline": "dff1955", "source_changes": changes, "existing_mechanical_C_source_exact": True,
           "joint_newton_and_energy_tail_exact": True, "runtime": rows[0]["runtime"], "native_sha256": native_by_label,
           "groups": groups, "total_substeps_compared": 1728, "initial_bump_pair": initial_bump_pair, "frozen_scenarios": frozen, "profile_call_counts": profile_rows, "bump_hotspots": bump_hotspots, "validation": validation,
           "validation_counts": validation_counts,
           "formal_full_T1_T2_T3": "not_run; 按用户范围只做试验台，完整专项回归/记录复算完成，游戏seed/window未跑",
           "physics_gate": "原完整模型/120Hz/两子步/34变量/epsilon/阈值保持，物理输出精确相同；既有能量精度Gate开放",
           "known_mesh_boundary": "部分旋转三角网格边缘的原EPA拒绝收敛；旧新异常类型/支持间隙文本一致，未放宽阈值，仍待修复",
           "real_time_human_gate": "open; 当前仍慢于实时，人工体验待确认",
           "continuous_goal": "active; 本块完成不代表持续优化目标完成",
           "raw_evidence_sha256": hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()}
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{k: group[k] for k in ("scenario", "wall_reduction_percent", "cpu_reduction_percent")} for group in groups], indent=2))
print("source/binaries/config/payload/native boundary/18 physical cases/query counts/validation verified")
