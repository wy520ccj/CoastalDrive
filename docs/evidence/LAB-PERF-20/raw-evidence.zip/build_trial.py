import inspect
from pathlib import Path

def make_trial(joint):
    root=Path.cwd()
    original=(root/'builds/lab-perf-20/baseline/src/unsprung_joint.py').read_text(encoding='utf-8')
    source=original[original.index('def solve_unsprung_joint'):]
    source=source.replace('body_external_torque=None,finite_motion=None):','body_external_torque=None,finite_motion=None,jacobian_updates=True):',1)
    assert 'jacobian_updates=True' in source
    source=source.replace('    for iteration in range(30):','    jacobian = None\n    for iteration in range(30):',1)
    source=source.replace('''        if momentum_error<1e-9 and force_error<1e-5 and port_error<1e-9:
            break''','''        polishing = momentum_error<1e-9 and force_error<1e-5 and port_error<1e-9
        if polishing and (not jacobian_updates or jacobian is None):
            break''',1)
    start=source.index('        columns = []')
    end=source.index('        # 轮速差分',start)
    original=source[start:end]
    source=source[:start]+'        fresh_jacobian = jacobian is None\n        if fresh_jacobian:\n            _record("jacobian")\n'+''.join('    '+line if line.strip() else line for line in original.splitlines(keepends=True))+source[end:]
    line='        delta = np.linalg.solve(jacobian,residual/row_scale)*state_scale'
    source=source.replace(line,'''        try:
            delta = np.linalg.solve(jacobian,residual/row_scale)*state_scale
        except np.linalg.LinAlgError:
            if polishing:
                break
            if fresh_jacobian:
                raise
            _record("singular_refresh")
            jacobian = None
            continue''',1)
    start=source.index('        for attempt in range(12):')
    end=source.index('    else:\n        raise ArithmeticError(f"簧下/轮胎/传动共同求解超过30轮',start)
    source=source[:start]+'''        for attempt in range(12):
            candidate = values-2.**-attempt*delta
            candidate_residual,_candidate_details = evaluate(candidate)
            after = np.linalg.norm(candidate_residual/row_scale)
            if after<before:
                if polishing:
                    candidate_errors = (float(np.max(np.abs(candidate_residual[:16]))),
                        float(np.max(np.abs(candidate_residual[16:24]))),float(np.max(np.abs(candidate_residual[24:]))))
                    if not (candidate_errors[0]<1e-9 and candidate_errors[1]<1e-5 and candidate_errors[2]<1e-9):
                        continue
                    values,residual,details = candidate,candidate_residual,_candidate_details
                    momentum_error,force_error,port_error = candidate_errors
                    _record("polish")
                    break
                if jacobian_updates and not attempt and after<.5*before:
                    displacement = (candidate-values)/state_scale
                    squared = np.dot(displacement,displacement)
                    if squared>0.:
                        difference = (candidate_residual-residual)/row_scale
                        jacobian = jacobian+np.outer(difference-jacobian@displacement,displacement)/squared
                        _record("update")
                    else:
                        jacobian = None
                        _record("zero_refresh")
                else:
                    jacobian = None
                    _record("progress_refresh")
                values = candidate
                break
        else:
            if polishing:
                _record("polish_no_descent")
                break
            if not fresh_jacobian:
                jacobian = None
                _record("line_refresh")
                continue
            raise ArithmeticError(f"簧下/轮胎/传动共同线搜索不下降：{momentum_error:g}Ns，{force_error:g}N，{port_error:g}Nm")
        if polishing:
            break
'''+source[end:]
    source=source.replace('        end,forces,torques = values[:16]', '        _record("residual")\n        end,forces,torques = values[:16]',1)
    path=root/'logs/lab-perf-20/trial_joint.py'
    path.write_text(source,encoding='utf-8')
    counters={}
    def record(name):counters[name]=counters.get(name,0)+1
    namespace=dict(vars(joint));namespace['_record']=record
    exec(compile(source,str(path),'exec'),namespace)
    return namespace['solve_unsprung_joint'],counters
