import dataclasses
import json
import sys
import time
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'logs/lab-perf-20')]
import unsprung_joint as joint
import test_unsprung_joint as case
from test_lab_joint_reuse import SCENARIOS
from vehicle_designs import REFERENCE_DESIGN
from build_trial import make_trial

trial,counters=make_trial(joint)
rows=[]
for index,(changes,arguments) in enumerate(SCENARIOS):
    config=dataclasses.replace(REFERENCE_DESIGN,**changes)
    original=case.solve_unsprung_joint
    try:
        case.solve_unsprung_joint=original
        old=case.solve(config,**arguments)[0]
        before=time.perf_counter();counters.clear()
        case.solve_unsprung_joint=trial
        new=case.solve(config,**arguments)[0]
        elapsed=time.perf_counter()-before
        assert new.momentum_error<1e-9 and new.force_error<1e-5 and new.port_error<1e-9
        row={'case':index,'arguments':{k:str(v) for k,v in arguments.items()},'old_iterations':old.iterations,'new_iterations':new.iterations,
             'old_momentum_error':old.momentum_error,'new_momentum_error':new.momentum_error,'old_energy_error':old.energy_error,
             'new_energy_error':new.energy_error,'velocity_max_abs_delta':float(abs(old.velocity-new.velocity).max()),
             'force_max_abs_delta':float(abs(old.forces-new.forces).max()),'counts':dict(counters),'seconds':elapsed}
        rows.append(row)
        print(row,flush=True)
    finally:case.solve_unsprung_joint=original
    (root/'logs/lab-perf-20/probe-polished-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
