import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd();build=root/'builds/lab-perf-20';build.mkdir(exist_ok=False)
subprocess.run(['git','archive','--format=zip','--output',str(build/'baseline.zip'),'HEAD','src','assets/game/vehicle-configs'],check=True)
with zipfile.ZipFile(build/'baseline.zip') as archive:archive.extractall(build/'baseline')
native={}
for path in (root/'src').glob('*.pyd'):
    raw=path.read_bytes();(build/'baseline/src'/path.name).write_bytes(raw)
    native[path.name]=hashlib.sha256(raw).hexdigest()
(root/'logs/lab-perf-20/native-copies.json').write_text(json.dumps(native,indent=2)+'\n',encoding='utf-8')
assert len(native)==5
print('6fe1fc6 source/five native binaries frozen')
