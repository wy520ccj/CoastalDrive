import ast
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'logs/lab-perf-20')]
from compare_results import compare
from lab_runtime import runtime_fingerprint

logs=root/'logs/lab-perf-20';baseline=root/'builds/lab-perf-20/baseline/src'
output=root/'docs/evidence/LAB-PERF-20';output.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
suffixes=('.py','.c','.h','.cpp')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['unsprung_joint.py']
old=(baseline/'unsprung_joint.py').read_text(encoding='utf-8');new=(root/'src/unsprung_joint.py').read_text(encoding='utf-8')
old_tree,new_tree=ast.parse(old),ast.parse(new)
old_solver=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='solve_unsprung_joint')
new_solver=next(n for n in new_tree.body if isinstance(n,ast.FunctionDef) and n.name=='solve_unsprung_joint')
old_loop=next(i for i,n in enumerate(old_solver.body) if isinstance(n,ast.For))
new_loop=next(i for i,n in enumerate(new_solver.body) if isinstance(n,ast.For))
assert ast.dump(ast.Module(body=old_solver.body[:old_loop],type_ignores=[]))==ast.dump(ast.Module(body=new_solver.body[:new_loop-1],type_ignores=[]))
assert old[old.rindex('    end,forces,torques = values[:16]'):]==new[new.rindex('    end,forces,torques = values[:16]'):]
model=ast.parse((root/'tests/lab_solver_model_reference.py').read_text(encoding='utf-8'))
for name in ('evaluate','configuration','velocity_terms'):
    a=next(n for n in ast.walk(old_tree) if isinstance(n,ast.FunctionDef) and n.name==name)
    b=next(n for n in ast.walk(model) if isinstance(n,ast.FunctionDef) and n.name==name)
    assert ast.dump(a)==ast.dump(b),name
finish=next(n for n in ast.walk(model) if isinstance(n,ast.FunctionDef) and n.name=='finish')
assert ast.dump(ast.Module(body=finish.body,type_ignores=[]))==ast.dump(ast.Module(body=old_solver.body[old_loop+1:],type_ignores=[]))
old_for=old_solver.body[old_loop];new_for=new_solver.body[new_loop]
old_columns=next(n for n in old_for.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple))
new_columns=next(n for n in ast.walk(new_for) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='enumerate')
assert ast.dump(old_columns)==ast.dump(new_columns)

groups=read(logs/'base-interleaved/summary.json')['groups'];assert len(groups)==3
runtime=runtime_fingerprint();native={};quality={};errors={};substeps=0
for group in groups:
    scenario=group['scenario'];folder=logs/'base-interleaved'/scenario
    assert group['repeat_exact_within_method'] and group['runtime']==runtime
    a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes()
    assert (folder/'A2.bin').read_bytes()==a and (folder/'B2.bin').read_bytes()==b
    assert a==(root/'logs/lab-perf-19/base-interleaved'/scenario/'B1.bin').read_bytes()
    expected=read(root/'logs/lab-perf-19/base-interleaved'/scenario/'summary.json')
    assert group['options']==expected['options'] and group['actual_config']==expected['actual_config']
    old_payload,new_payload=pickle.loads(a),pickle.loads(b)
    assert old_payload['commands']==new_payload['commands']
    difference=compare(old_payload,new_payload)
    assert difference==group['difference']
    assert set(difference['changed_discrete_counts'])<={'payload.joint[].iterations'}
    independent=logs/'independent-model'/scenario
    quality[scenario]=read(independent/'quality.json')
    assert (independent/'payload.bin').read_bytes()==b
    assert quality[scenario]['substeps']==len(new_payload['joint'])
    assert quality[scenario]['maxima']['momentum_error']<1e-9 and quality[scenario]['maxima']['force_error']<1e-5
    assert quality[scenario]['maxima']['port_error']<1e-9 and quality[scenario]['maxima']['energy_recompute_gap']==0.
    errors[scenario]={}
    for name in ('momentum_error','force_error','port_error','energy_error'):
        errors[scenario][name]={label:max(abs(row[name]) for row in value['joint']) for label,value in (('A',old_payload),('B',new_payload))}
    assert errors[scenario]['momentum_error']['B']<=errors[scenario]['momentum_error']['A']
    assert errors[scenario]['force_error']['B']<=errors[scenario]['force_error']['A']
    for row in group['rows']:
        substeps+=row['substeps'];label=row['label'][0];source=baseline if label=='A' else root/'src'
        assert row['source_hashes']=={p.name:sha(p) for p in source.iterdir() if p.suffix in suffixes}
        native[label]=row['native']
        for name,data in row['native'].items():
            assert Path(data['path']).parent==source.resolve() and sha(Path(data['path']))==data['sha256']
assert substeps==1728
assert {name:data['sha256'] for name,data in native['A'].items()}=={name:data['sha256'] for name,data in native['B'].items()}
assert sum(q['substeps'] for q in quality.values())==432

stress=read(logs/'stress/summary.json');assert len(stress)==2
for case in stress:
    assert case['commands_equal']
    assert set(case['difference']['changed_discrete_counts'])<={'payload.joint[].iterations'}
    assert len(case['runs'])==2 and case['runs'][0]['substeps']==case['runs'][1]['substeps']
    assert case['runs'][0]['reason']==case['runs'][1]['reason'] and case['runs'][0]['ticks']==case['runs'][1]['ticks']
    for row in case['runs']:
        assert row['independent_all_substeps_checked']
        assert row['quality_max']['momentum_error']<1e-9 and row['quality_max']['force_error']<1e-5 and row['quality_max']['port_error']<1e-9
        assert row['quality_max']['energy_recompute_gap']==0.
energy=read(logs/'energy-refinement/summary.json');assert len(energy['rows'])==6 and energy['runtime']==runtime
energy_deltas=[]
for count in (2,4,8):
    a,b=[r for r in energy['rows'] if r['substeps']==count]
    assert a['label']=='A' and b['label']=='B'
    old_energy,new_energy=read(logs/'energy-refinement'/f'{count}-A/result.json'),read(logs/'energy-refinement'/f'{count}-B/result.json')
    assert old_energy['config']==new_energy['config'] and old_energy['runtime']==new_energy['runtime']==runtime
    energy_deltas.append({'substeps':count,'old_sum_J':a['sum']['actual_energy_residual'],'new_sum_J':b['sum']['actual_energy_residual'],
                          'sum_delta_J':b['sum']['actual_energy_residual']-a['sum']['actual_energy_residual']})
assert max(abs(r['sum_delta_J']) for r in energy_deltas)<3.3e-10

validation={name:read(logs/name/'summary.json') for name in ('T0','T0-standard','lab-regression')}
assert all(data['passed'] for data in validation.values())
validation_counts={}
for name in validation:
    matches=re.findall(r'(\d+) passed',(logs/name/'pytest.log').read_text(encoding='utf-8'));assert len(matches)==1
    validation_counts[name]=int(matches[0])
assert validation_counts=={'T0':153,'T0-standard':153,'lab-regression':754}
assert validation['lab-regression']['runtime']==runtime
# 全模块回归后新增3项恢复分支，由最终T0覆盖；并未重跑全模块或把两者说成一次757项。
assert '65 passed' in (logs/'model-refresh-tests.log').read_text(encoding='utf-8')
assert '88 passed' in (logs/'adopt-fixed-tests.log').read_text(encoding='utf-8')
profile=read(logs/'profile-bump/profile.json')
assert profile['counts']=={'residual':21742,'jacobian':288,'update':791,'polish':288}
assert (logs/'profile-bump/payload.bin').read_bytes()==(logs/'base-interleaved/nonlinear-bump/B1.bin').read_bytes()
profile_result=read(logs/'profile-bump/result.json')
assert profile_result['source_hashes']==next(r['source_hashes'] for r in groups[-1]['rows'] if r['label']=='B1')
previous=read(root/'logs/lab-perf-19/profile-final-bump/profile.json')
profile_counts={}
for label,data in (('A',previous),('B',profile)):
    values={}
    for name,file in (('solve','_linalg.py'),('normal_material','unsprung_contact.py')):
        rows=[r for r in data['functions'] if r['function']==name and Path(r['file']).name==file];assert len(rows)==1
        values[name]=rows[0]['calls']
    for name in ('radial_box_bounds','box_face_candidates','box_cone_samples','box_cone_refine'):
        values[name]=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.'+name+'>' in r['function'])
    profile_counts[label]=values
old_iterations=sum(r['iterations']-1 for r in pickle.loads((logs/'base-interleaved/nonlinear-bump/A1.bin').read_bytes())['joint'])
assert old_iterations==629
with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.csv') and 'user-data' not in path.parts:
            archive.write(path,path.relative_to(logs).as_posix())
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/shared/'+path.name)
    archive.write(baseline/'unsprung_joint.py','executed-source/baseline/unsprung_joint.py')
    for name in ('src/unsprung_joint.py','tests/test_lab_solver_update.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py',
                 'tests/test_lab_joint_reuse.py','tests/test_lab_newton_base.py','tests/test_unsprung_joint.py','tools/performance/compare_lab_compute.py'):
        archive.write(root/name,'executed-source/'+name)
summary={'baseline':'6fe1fc6','source_changes':changes,'groups':groups,'substeps_in_performance':1728,
         'quality_all_substeps':quality,'peak_residuals':errors,'stress':stress,'energy_refinement':energy_deltas,
         'validation':validation,'validation_counts':validation_counts,'full_suite_note':'754项完整专项后，另增3项恢复分支由最终T0覆盖；不是一次757项运行',
         'profile_counts':profile_counts,'updated_solver_counts':profile['counts'],'old_jacobian_builds':old_iterations,'native':native,
         'residual_model_and_energy_source_ast_exact':True,'native_unchanged':True,
         'full_newton_reference':'jacobian_updates=False；保留旧完整Newton全部中央差分/固定端口行/原残差和门槛',
         'algorithm_reference':'https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.broyden1.html',
         'formal_T1_T2_T3':'not_run; 仅试验台专项完整回归、记录复算及独立能量/残差验证，游戏seed/window未跑',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print([{k:g[k] for k in ('scenario','wall_seconds_reduction_percent','cpu_seconds_reduction_percent')} for g in groups])
print('original residual/energy AST, native hashes, whole-step source/differences, independent equations, refinement and validation verified')
