import json
from pathlib import Path

root=Path.cwd();folder=root/'docs/evidence/LAB-PERF-20'
summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'));groups=summary['groups']
metrics='/'.join(f"{g['wall_seconds_reduction_percent']:.2f}" for g in groups)
lines=['# 试验台同方程Jacobian更新','',
'2026-10-16，基线6fe1fc6，主目录main，只处理试验台。持续目标active。','',
'## 数值方法与精度边界','',
'上一块实测中央差分占原完整凸起计算82.70%。本块首次仍按原34列中央差分构造缩放Jacobian，接受完整步且缩放残差范数下降超过一半后，采用Broyden一阶割线更新；发生阻尼步/下降不足/零位移则下一轮重建。旧Jacobian奇异或12次线搜索不下降时重建；首次完整Jacobian的错误仍原样传播，30轮上限不变。','',
'更新在x/state_scale与F/row_scale坐标执行J+=(ΔF−JΔx)Δxᵀ/(ΔxᵀΔx)，与[官方SciPy公式](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.broyden1.html)一致。每轮仍按当前分支重写精确有限离合/同步/制动端口行；实际候选仍调用原完整残差，不能以更新模型的残差作为收敛判断。','',
'原门槛仍为动量<1e−9 Ns、切向力<1e−5 N、有限端口<1e−9 Nm。首次试验达标时部分残差较接近门槛，因此增加一次收敛后校正：仅在完整残差范数下降且三类原门槛仍全部满足时接受，否则保留已合格的原状态。不增加迭代上限，不放宽任一物理门槛，不修改力/轮速或真实世界状态。','',
'原共同残差/构型/速度数值定义、初始条件、质量/材料、碰撞、120Hz/双机械子步/34未知数及最终全部能量结果段保持。独立冻结模型的evaluate/configuration/velocity_terms与原函数AST精确相同，finish能量段AST与原结尾相同。只改unsprung_joint.py；五个原生扩展及Panda1.10.16/Bullet285 Double SDK未变。','',
'默认启用Jacobian更新；jacobian_updates=False保留同一残差下的原完整Newton。历史36组共同解、8组真实有限接触逐位检查与旧预测文件1e−13/1e−9门槛均继续对显式完整Newton检查，不放宽原阈值。默认新算法另用冻结原方程独立验证；算法路径改变，不能再宣称旧新完整输出逐字节相同。相同算法重跑仍逐字节相同。','',
'## 同批完整步实测','',
'三个工况各四个独立世界逐拍ABBA/反序正常前进，C轴向缓存和Python曲率缓存各自独立，绑定切换与序列化在计时外，初始化单列。旧世界执行冻结6fe1fc6完整求解器，新世界执行正式源码默认更新方法；相同参数、完整真实几何与原残差。','',
'| 工况 | 旧墙钟s | 新墙钟s | 耗时减少 | 旧CPU s | 新CPU s | CPU减少 |',
'|---|---:|---:|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['wall_seconds']:.6f} | {b['wall_seconds']:.6f} | {g['wall_seconds_reduction_percent']:.2f}% | {a['cpu_seconds']:.6f} | {b['cpu_seconds']:.6f} | {g['cpu_seconds_reduction_percent']:.2f}% |")
lines+=['','| 工况 | 旧P95 ms | 新P95 ms | 旧P99 ms | 新P99 ms |','|---|---:|---:|---:|---:|']
for g in groups:
    a,b=g['measured']['A'],g['measured']['B']
    lines.append(f"| {g['scenario']} | {a['step_p95_seconds']*1000:.3f} | {b['step_p95_seconds']*1000:.3f} | {a['step_p99_seconds']*1000:.3f} | {b['step_p99_seconds']*1000:.3f} |")
lines+=['','机器绝对速度有波动，只报告本批同配置对照，不跨历史批次相乘。当前实体凸起1.2模拟秒仍需5.586墙钟秒，尚未实时。','',
'| 工况 | A1初始化s | B1初始化s | B2初始化s | A2初始化s | 初始化拍数 |','|---|---:|---:|---:|---:|---:|']
for g in groups:
    initial=[r['initialization'] for r in g['rows']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{r['wall_seconds']:.3f}" for r in initial)+f" | {initial[0]['ticks']} |")
lines+=['','制动100km/h/.2s/24拍，第一个计算拍brake=1；转向30km/h/2°/.4s/48拍/onset=0；实体凸起18km/h/1.2s/144拍、2m位置/.4m长度、实际预载/安装曲线/非线性阻尼，台架拟合输入为合成数据，不代表实车标定。','',
'12次共864拍/1728子步，新旧各自两次payload逐字节重复；旧版与LAB-PERF-19实际文件逐字节相同。新旧命令、全部离散物理状态相同，只有求解迭代数变化；全部连续字段差保存在difference.json，不用舍弃数值字段来获得相同结论。只归一实例epoch并排除含原生节点的contact_geometry引用，真实接触仍在快照。','',
'| 工况 | 位置最大差m | 共同速度最大差 | 接触力最大差N |','|---|---:|---:|---:|']
for g in groups:
    d=g['difference']['numeric_max_abs_deltas']
    lines.append(f"| {g['scenario']} | {d['payload.snapshots[].player.position[]']:.3e} | {d['payload.joint[].velocity']:.3e} | {d['payload.joint[].forces']:.3e} |")
lines+=['','## 原方程、能量与较长工况','',
'对新算法三个工况432个实际子步，在每个原始输入上用冻结原方程/独立数值缓存重算34残差，再用原能量结果段重算账本；三类原门槛全部通过，全部能量账复算差为0。该运行不作速度收益，且payload与速度实验的新结果逐字节一致。','',
'| 工况 | 原/新峰值动量残差Ns | 原/新峰值切向力残差N | 原/新峰值能量误差J |','|---|---:|---:|---:|']
for g in groups:
    e=summary['peak_residuals'][g['scenario']]
    lines.append('| '+g['scenario']+' | '+' | '.join(f"{e[k]['A']:.3e} / {e[k]['B']:.3e}" for k in ('momentum_error','force_error','energy_error'))+' |')
lines+=['','本批校正后的新峰值残差更小，但不把有限工况推成全参数精度证明。较长工况继续独立核对旧/新每个实际子步：','',
'| 请求工况 | 旧/新实际拍数 | 旧/新子步数 | 结束原因 | 新峰值动量Ns | 新峰值力N |','|---|---:|---:|---|---:|---:|']
for case in summary['stress']:
    a,b=case['runs']
    lines.append(f"| {case['case']} | {a['ticks']} / {b['ticks']} | {a['substeps']} / {b['substeps']} | {b['reason']} | {b['quality_max']['momentum_error']:.3e} | {b['quality_max']['force_error']:.3e} |")
lines+=['','两组均在相同拍停车而提前于请求时长结束；旧/新命令、离散物理状态一致，所有2052个子步满足原残差门槛且能量复算差0。时间含独立验证，只算功能/精度覆盖，不算速度收益。','',
'另在相同完整工程输入、手动转向/油门/制动/离合实际世界中，做.12秒2/4/8子步细化；原工具同时检查真实世界动能、重力势能、悬架/径向/切向势能与原功耗散账。','',
'| 子步配置 | 旧累计能量残差J | 新累计能量残差J | 差J |','|---|---:|---:|---:|']
for r in summary['energy_refinement']:
    lines.append(f"| {r['substeps']} | {r['old_sum_J']:.12f} | {r['new_sum_J']:.12f} | {r['sum_delta_J']:.3e} |")
lines+=['','六次共420个实际世界子步；差异均不到3.3e−10J，保留原细化趋势。原能量积分误差/速度网格收敛等完整Gate仍开放，不能因这张表或固定步残差通过而回填原阶段成功。','',
'## 验证与工作量','',
'新增65项算法验证：36组不同驱动分配/同步/离地/倒车/路扰/有限悬架/转子储能/导向/轮心误差及陀螺开关，用原模型独立复算并重复新解；8组真实平面/Box有限接触/悬架/导向/陀螺；18组显式完整Newton逐字节参照；3项注入旧Jacobian奇异/上坡方向和首次完整Jacobian错误，确认需要至少第二次68扰动重建或原错传播。','',
'原相关88项及新增62项先检通过。Double44模块754项完整试验台专项/Ruff、真实记录和旧检查点复算通过；随后新增3项刷新分支，最终普通/Double T0各153项通过覆盖这些测试及原相关模块。最终不同用例总数757，不能说成一次757项完整回归。生产源码在速度实验与上述检查期间保持一致，只有之后的测试新增。','',
'原旧预测文件默认算法对1e−13速度基准首检有1.28e−13差（浮点路径改变），因此保留原文件全部门槛给显式完整Newton，并新增默认算法的冻结原方程/能量检查，没有扩大旧阈值。初次生成独立finish函数匹配到evaluate内同名end赋值，产生缩进错误；改为最终能量段后通过。首个归档断言因AST广度优先匹配到固定端口循环，改为指定enumerate差分循环后通过；这些原失败日志均保留，未改物理门槛或重跑速度实验。','',
'完整凸起Jacobian重建629→288，中央差分42772→19584次；总残差44318→21742，新增791次割线更新/288次合格校正。各迭代候选仍执行真实几何与原材料/端口方程；减少的是不必逐轮重新差分的重复构型求值，不能再要求旧新几何调用次数相同。全字段物理事件、实际残差和能量独立复算支持本块采用。','',
'原/新完整剖析仅用于次数与下一热点，不进入速度表；新剖析计数脚本明确记录profiled_solver.py，原计算表达式保持，payload与速度实验相同。没有重复六拍剖析。','',
'summary与raw-evidence.zip保存初试/校正前后结果、完整性能12份payload、全部连续/离散差、独立原模型复算、能量细化/较长工况、共享五扩展、旧/新源码及独立模型、构建/失败/验证日志与复现脚本。旧完整Newton是验证路径，不作为另一个产品版本入口。','',
'复现：项目Python tools/physics/run_sim_double.py logs/lab-perf-20/interleaved.py（须新输出目录与6fe1fc6冻结基线）；quality_worker.py、energy_refinement.py、stress.py分别复现独立方程、实际世界细化和较长工况，lab_regression.py执行专项。算法公式来源见上方官方文档。','',
'本块仅本地提交，持续目标active。游戏seed/window与通用T1/T2/T3未跑；原完整能量/精度、人工体验、实时及EPA部分旋转网格边缘拒绝继续开放。下一按新完整剖析继续原Jacobian首次构造与真实接触计算，兼顾更多工况的算法稳健性。','']
(folder/'README.md').write_text('\n'.join(lines),encoding='utf-8')
(root/'docs/tasks/LAB-PERF-20.md').write_text(f'''# LAB-PERF-20 同方程Jacobian更新策略

- 状态：done（本功能块）；基线6fe1fc6，main，本地提交；持续目标active。
- 首次完整原34列中央差分，随后在原缩放坐标做Broyden割线更新；下降不足/阻尼/退化/旧矩阵线搜索失败重建。每轮精确有限端口行仍刷新，原30轮/12线搜索/残差门槛保持；合格后只接受进一步下降且仍合格的一次校正。
- 只改unsprung_joint.py，原残差/真实接触/材料/能量结尾AST保持，五扩展/SDK未改。jacobian_updates=False保留完整Newton，历史逐字节与1e−13预测门槛明确在原算法验收；默认新方法独立验证原方程。
- 同批四世界逐拍交叉完整制动/转向/凸起耗时减少{metrics}%，本批P95/P99均下降；1728性能子步旧/新各自精确重复，命令/离散物理事件一致，全部连续差原样保存，不宣称新旧逐字节相同。
- 432实际新子步原方程独立复算/能量账差0；较长停车两组旧/新相同拍结束，2052子步同门槛复算；实际世界2/4/8细化420子步，旧新累计能量差<3.3e−10J，原完整能量/精度Gate保持开放。
- 原相关88项、独立模型62项先检；Double44模块754项专项/Ruff/记录与旧检查点复算通过；随后新增3项刷新测试，最终普通/Double T0各153项覆盖。最终不同用例757，不等于一次757完整运行。
- 完整凸起Jacobian629→288、残差44318→21742，791更新/288校正；原真实方程/完整物理/120Hz/双子步/34变量/碰撞/参数/门槛保持。
- [实测与失败记录](../evidence/LAB-PERF-20/README.md)、summary.json、raw-evidence.zip包含来源/配置/CPU/墙钟/P95/P99/初始化/完整结果与源码SHA。
- 当前仍慢于实时，游戏seed/window及通用T1/T2/T3未跑，原人工/实时/完整精度/EPA Gate开放。下一首次Jacobian构造及真实接触热点，持续优化不结束。
''',encoding='utf-8')
path=root/'docs/current-progress.md';text=path.read_text(encoding='utf-8')
start=text.index('当前施工仅试验台：');end=text.index('\n',start)
text=text[:start]+f'当前施工仅试验台：最新完成[LAB-PERF-20](tasks/LAB-PERF-20.md)同方程Jacobian更新与合格后校正，三工况完整步再减{metrics}%，原残差/完整物理/门槛不变；默认算法用原方程独立复算，显式完整Newton保留原逐字节基准。能量2/4/8细化、较长停车和专项通过，仍慢于实时。持续目标active，下一首次Jacobian/真实接触热点。下列历史节点只支持各自版本/协议，最新收益以本块同批对照为准。'+text[end:]
text+=f'\n- [LAB-PERF-20 同方程Jacobian更新](tasks/LAB-PERF-20.md)：6fe1fc6基线，首次完整差分+缩放Broyden/不足时重建/合格下降校正，原残差、真实物理和门槛保持。三工况四世界完整步−{metrics}%；新旧各自精确重放、事件/命令一致，连续差保留。432实际新子步独立原方程/能量复算、较长工况2052子步与实际世界2/4/8细化420子步通过；完整专项754项，后增3项恢复分支由普通/Double最终T0各153项覆盖。旧预测原1e−13门槛保留给显式完整Newton，默认算法独立残差验收；本地提交，持续目标active，原精度/人工/实时/EPA Gate开放。\n'
path.write_text(text,encoding='utf-8')
print('report/task/progress written from verified actual measurements')
