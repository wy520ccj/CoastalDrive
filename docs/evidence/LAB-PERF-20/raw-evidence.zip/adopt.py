from pathlib import Path

root=Path.cwd();baseline=root/'builds/lab-perf-20/baseline/src/unsprung_joint.py'
old=baseline.read_text(encoding='utf-8')
trial=(root/'logs/lab-perf-20/trial_joint.py').read_text(encoding='utf-8')
lines=[line for line in trial.splitlines(keepends=True) if '_record(' not in line]
function=''.join(lines)
function=function.replace('    jacobian = None\n    for iteration',
    '    # 只更新数值Jacobian，原完整残差/精确端口行和收敛门槛不变。\n    jacobian = None\n    for iteration',1)
function=function.replace('        polishing = momentum_error',
    '        # 达到原门槛后，只接受进一步下降且仍合格的一次校正。\n        polishing = momentum_error',1)
function=function.replace('                        difference = (candidate_residual-residual)/row_scale',
    '                        # 在原状态/残差缩放坐标中满足Broyden割线条件。\n                        difference = (candidate_residual-residual)/row_scale',1)
assert '_record' not in function
header=old[:old.index('def solve_unsprung_joint')]
(root/'src/unsprung_joint.py').write_text(header+function,encoding='utf-8')
prefix=old[old.index('def solve_unsprung_joint'):old.index('    for iteration in range(30):')]
prefix=prefix.replace('def solve_unsprung_joint','def make_joint_model',1)
prefix=prefix.replace('    values = np.r_[start,np.asarray(initial_force).ravel(),np.zeros(10)]\n','',1)
tail=old[old.rindex('    end,forces,torques = values[:16]'):]
finish='    def finish(values,details,iteration,momentum_error,force_error,port_error):\n'+''.join('    '+line if line.strip() else line for line in tail.splitlines(keepends=True))
reference=header+prefix+finish+'\n    return evaluate,finish,state_scale,row_scale\n'
(root/'tests/lab_solver_model_reference.py').write_text(reference,encoding='utf-8')
print('adopted one shared residual with optional full-Newton reference; frozen independent residual/energy evaluator written')
