from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-19/base_interleaved.py').read_text(encoding='utf-8').replace('lab-perf-19','lab-perf-20')
source=source.replace("sys.path[:0]=[str(root/'src'),str(root/'tests')]","sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'logs/lab-perf-20')]\nfrom compare_results import compare")
source=source.replace('import lab_newton_base_reference as old_geometry','')
source=source.replace('from lab_newton_base_reference import solve_unsprung_joint as old_solve','')
source=source.replace("baseline=root/'builds/lab-perf-20/baseline/src'", "baseline=root/'builds/lab-perf-20/baseline/src'\nold_spec=importlib.util.spec_from_file_location('solver_baseline',baseline/'unsprung_joint.py')\nold_geometry=importlib.util.module_from_spec(old_spec)\nsys.modules['solver_baseline']=old_geometry\nold_spec.loader.exec_module(old_geometry)\nold_solve=old_geometry.solve_unsprung_joint")
source=source.replace("expected_path=root/'logs/lab-perf-18/interleaved'/scenario/'A1.bin'","expected_path=root/'logs/lab-perf-19/base-interleaved'/scenario/'B1.bin'")
source=source.replace("            assert binary==expected,(scenario,label)","            if label.startswith('A'):assert binary==expected,(scenario,label)")
source=source.replace("        group={'scenario':scenario", "        a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes()\n        assert (folder/'A2.bin').read_bytes()==a and (folder/'B2.bin').read_bytes()==b\n        difference=compare(pickle.loads(a),pickle.loads(b))\n        assert difference['changed_discrete_counts'].keys()<={'payload.joint[].iterations'},difference['changed_discrete_counts']\n        assert pickle.loads(a)['commands']==pickle.loads(b)['commands']\n        (folder/'difference.json').write_text(json.dumps(difference,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8')\n        group={'scenario':scenario")
source=source.replace("'rows':rows,'exact':True}","'rows':rows,'repeat_exact_within_method':True,'difference':difference}")
(root/'logs/lab-perf-20/interleaved.py').write_text(source,encoding='utf-8')
print('6fe1fc6/full Newton versus production default update; same equations, per-method replay and full field differences')
