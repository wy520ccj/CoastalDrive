import json
import pickle
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance'),str(root/'logs/lab-perf-20')]
import unsprung_joint as joint
import vehicle_unsprung as vehicle
import compare_lab_compute
from build_trial import make_trial
from lab_experiment import LabExperiment

scenario=sys.argv[1]
trial,counts=make_trial(joint)
original_solver=vehicle.solve_unsprung_joint;original_step=LabExperiment.step
first=True
def step(run):
    global first
    if first:counts.clear();first=False
    return original_step(run)
vehicle.solve_unsprung_joint=trial;LabExperiment.step=step
output=root/'logs/lab-perf-20/trial-polished'/scenario
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario=scenario,output=output))
finally:vehicle.solve_unsprung_joint=original_solver;LabExperiment.step=original_step
old=pickle.loads((root/'logs/lab-perf-19/base-interleaved'/scenario/'B1.bin').read_bytes())
new=pickle.loads((output/'payload.bin').read_bytes())
assert len(old['joint'])==len(new['joint'])
errors={}
for name in ('momentum_error','force_error','port_error','energy_error','kinetic_change','potential_change','guide_work','body_gyro_work'):
    a=np.asarray([row[name] for row in old['joint']]);b=np.asarray([row[name] for row in new['joint']])
    errors[name]={'old_max_abs':float(np.max(np.abs(a))),'new_max_abs':float(np.max(np.abs(b))),
                  'max_abs_delta':float(np.max(np.abs(a-b)))}
for name in ('velocity','compression','tire_deflection','forces','port_torques'):
    a=np.asarray([row[name] for row in old['joint']]);b=np.asarray([row[name] for row in new['joint']])
    errors[name]={'max_abs_delta':float(np.max(np.abs(a-b)))}
assert errors['momentum_error']['new_max_abs']<1e-9 and errors['force_error']['new_max_abs']<1e-5 and errors['port_error']['new_max_abs']<1e-9
result={'scenario':scenario,'counts':counts,'errors':errors,'old_iterations':sum(row['iterations'] for row in old['joint']),
        'new_iterations':sum(row['iterations'] for row in new['joint']),'commands_equal':old['commands']==new['commands']}
(output/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(result,flush=True)
