import hashlib
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

root = Path.cwd()
sys.path.insert(0, str(root/"src"))
logs = root/"logs/lab-perf-04"
output = root/"docs/evidence/LAB-PERF-04"
output.mkdir(parents=True, exist_ok=True)
baseline = root/"builds/lab-perf-04/baseline/src"
suffixes = (".py", ".c", ".cpp", ".h")
old_names = {p.name for p in baseline.iterdir() if p.suffix in suffixes}
new_names = {p.name for p in (root/"src").iterdir() if p.suffix in suffixes}
changes = sorted(name for name in old_names | new_names if name not in old_names or name not in new_names
                 or (baseline/name).read_bytes().replace(b"\r\n", b"\n") != (root/"src"/name).read_bytes().replace(b"\r\n", b"\n"))
assert changes == ["lab_contact_native.h", "unsprung_contact_geometry.py", "unsprung_drivetrain.py", "wheel_contact_kernels.c"]
assert (baseline/"unsprung_joint.py").read_bytes().replace(b"\r\n", b"\n") == (root/"src/unsprung_joint.py").read_bytes().replace(b"\r\n", b"\n")
old_c = (baseline/"wheel_contact_kernels.c").read_text(encoding="utf-8")
new_c = (root/"src/wheel_contact_kernels.c").read_text(encoding="utf-8")
for line in ('#include "lab_contact_native.h"\n',
             '    {"unsprung_tire_ports",unsprung_tire_ports_native,METH_VARARGS,"试验台四轮完整材料/法向力端口批量组装"},\n',
             '    {"finite_radial_gradients",finite_radial_gradients_native,METH_VARARGS,"试验台原有限径向虚功梯度与接触坐标"},\n'):
    assert line in new_c
    new_c = new_c.replace(line, "", 1)
assert old_c == new_c
rows = json.loads((logs/"complete-AB/summary.json").read_text(encoding="utf-8"))
assert len(rows) == 8
native_by_label = {}
for label in ("A", "B"):
    cases = [row for row in rows if "-"+label in row["case"]]
    native_by_label[label] = {name: value["sha256"] for name, value in cases[0]["native"].items()}
    assert all({name: value["sha256"] for name, value in row["native"].items()} == native_by_label[label] for row in cases)
    source = baseline if label == "A" else root/"src"
    for name, value in cases[0]["native"].items():
        assert Path(value["path"]).parent == source.resolve()
        assert hashlib.sha256(Path(value["path"]).read_bytes()).hexdigest() == value["sha256"]
assert [name for name in native_by_label["A"] if native_by_label["A"][name] != native_by_label["B"][name]] == ["wheel_contact_kernels"]
assert all(row["runtime"] == rows[0]["runtime"] and row["complete_payload_equal"] and row["substeps"] == 2*row["ticks"] for row in rows)
for row in rows:
    source = baseline if "-A" in row["case"] else root/"src"
    assert row["source_hashes"] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix in suffixes}
groups = []
for scenario in ("braking", "turning", "nonlinear-bump"):
    cases = [row for row in rows if row["scenario"] == scenario]
    expected = (logs/"complete-AB"/cases[0]["case"]/"payload.bin").read_bytes()
    for row in cases:
        actual = (logs/"complete-AB"/row["case"]/"payload.bin").read_bytes()
        assert actual == expected and row["payload_sha256"] == hashlib.sha256(expected).hexdigest()
        assert row["config"] == cases[0]["config"] and row["options"] == cases[0]["options"]
    payload = pickle.loads(expected)
    assert len(payload["snapshots"]) == cases[0]["ticks"]+1 and len(payload["joint"]) == cases[0]["substeps"]
    assert all(row["joint_iterations"] == cases[0]["joint_iterations"] for row in cases)
    measured = {}
    for label in ("A", "B"):
        sample = [row for row in cases if "-"+label in row["case"]]
        steps = [dt for row in sample for dt in row["step_seconds"]]
        measured[label] = {"runs": len(sample),
            **{key: float(np.mean([r[key] for r in sample])) for key in ("wall_seconds", "cpu_seconds", "physics_snapshot_seconds")},
            "step_p95_seconds": float(np.percentile(steps, 95)), "step_p99_seconds": float(np.percentile(steps, 99)),
            "initialization": {key: float(np.mean([r["initialization"][key] for r in sample]))
                               for key in ("wall_seconds", "cpu_seconds", "ticks")}}
    group = {"scenario": scenario, "options": cases[0]["options"], "actual_config": cases[0]["config"],
             "requested_config": cases[0]["requested_config"], "measured": measured,
             "wall_reduction_percent": 100*(1-measured["B"]["wall_seconds"]/measured["A"]["wall_seconds"]),
             "cpu_reduction_percent": 100*(1-measured["B"]["cpu_seconds"]/measured["A"]["cpu_seconds"]),
             "complete_payload_exact": True, "payload_sha256": hashlib.sha256(expected).hexdigest()}
    if scenario == "nonlinear-bump":
        assert group["actual_config"]["suspension_coil_enabled"] and group["actual_config"]["suspension_damper_curves"]
        load = np.asarray([s.player.unsprung_state.normal_force for s in payload["snapshots"]])
        group["peak_normal_load_change_from_initial_N"] = np.max(abs(load-load[0]), axis=0).tolist()
        assert group["peak_normal_load_change_from_initial_N"][0] > 100 and group["peak_normal_load_change_from_initial_N"][2] > 100
    groups.append(group)
frozen = json.loads((logs/"frozen-results.json").read_text(encoding="utf-8"))
assert frozen["exact"] and len(frozen["runs"][0]["cases"]) == 18 and frozen["runs"][0]["cases"] == frozen["runs"][1]["cases"]
validation = {name: json.loads((logs/name/"summary.json").read_text(encoding="utf-8"))
              for name in ("T0-initial", "T0-native", "T0-standard", "lab-regression")}
assert all(result["passed"] for result in validation.values())
old_profile_root = root/"logs/lab-perf-03/profile-after"
old_profile_result = json.loads((old_profile_root/"result.json").read_text(encoding="utf-8"))
for name in ("unsprung_joint.py", "unsprung_contact_geometry.py", "unsprung_drivetrain.py"):
    assert hashlib.sha256((baseline/name).read_bytes()).hexdigest() == old_profile_result["source_hashes"][name]
for path in baseline.glob("*.pyd"):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == old_profile_result["source_hashes"][path.name]
profiles = {"before": json.loads((old_profile_root/"profile.json").read_text(encoding="utf-8")),
            "after": json.loads((logs/"profile-after/profile.json").read_text(encoding="utf-8"))}
profile_rows = {}
for label, profile in profiles.items():
    def calls(name, file, line=None):
        found = [row for row in profile["functions"] if row["function"] == name and Path(row["file"]).name == file
                 and (line is None or row["line"] == line)]
        assert len(found) == 1
        return found[0]["calls"]
    profile_rows[label] = {"ticks": profile["ticks"], "residual_calls": calls("evaluate", "unsprung_joint.py"),
                           "road_geometry_queries": calls("query", "radial_geometry.py", 128),
                           "port_assembly_calls": calls("tire_ports", "unsprung_drivetrain.py")}
assert profile_rows["before"] == profile_rows["after"] == {"ticks": 6, "residual_calls": 1692, "road_geometry_queries": 1122, "port_assembly_calls": 552}
(logs/"build.log").write_bytes((root/"logs/lab-perf-04-build.txt").read_bytes())
build = (logs/"build.log").read_text(encoding="utf-8")
assert "building 'wheel_contact_kernels' extension" in build and "/fp:strict" in build
assert build.count("building '") == 1
(logs/"notes.md").write_text("""# 测量边界

基线82ba3ca导出后保存五扩展；本块只重编wheel_contact_kernels（加入两个试验台入口），其余四扩展SHA保持。旧C文件移除新增include/两行注册后与基线完全相同，支持函数与胎冠割线复用既有实现。setup.py增加头文件构建依赖。共享.venv及SDK未改。

八次完整速度实验串行，结束后才运行18组冻结输入、6+6拍采样、普通T0/Double完整回归。无其他测试/预览并发参与速度测量；不调CPU优先级/亲和性。初始化真实执行且分列，完整步含轻量共同解收集，序列化在计时后。全批配置与每次实际源码/扩展SHA核对通过。

施工前分析复用LAB-PERF-03的profile-after，三核心源码和五扩展SHA与本次基线逐项一致；只比调用次数，不拿不同CPU时段的分析器耗时或上一批绝对秒数拼接累计提速。

新测试最初有两个未用导入，Ruff提示后删除。T0-native 64项时尚未增加空中18组参数；最终普通T0 82项和Double完整271项覆盖最终测试。物理与数值对照/回归无失败、超时或放宽门槛。
""", encoding="utf-8")
with zipfile.ZipFile(output/"raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".log", ".txt", ".py", ".md", ".bin", ".prof") and "user-data" not in path.parts:
            archive.write(path, path.relative_to(logs).as_posix())
    for path in old_profile_root.iterdir():
        if path.is_file():
            archive.write(path, "reused-baseline-profile/"+path.name)
    for label, source in (("old", baseline), ("new", root/"src")):
        path = next(source.glob("wheel_contact_kernels*.pyd"))
        archive.write(path, "executed-native/"+label+"/"+path.name)
    for path in ("tools/performance/compare_lab_compute.py", "src/lab_contact_native.h", "tests/lab_contact_reference.py", "tests/test_lab_contact_native.py"):
        archive.write(root/path, "executed-source/"+path)
summary = {"baseline": "82ba3ca", "source_changes": changes, "wheel_existing_C_source_exact": True,
           "joint_solver_source_exact": True, "runtime": rows[0]["runtime"], "native_sha256": native_by_label,
           "groups": groups, "frozen_scenarios": frozen, "profile_call_counts": profile_rows, "validation": validation,
           "validation_counts": {"initial_Double_T0": 33, "preliminary_Double_T0": 64, "final_standard_T0": 82,
                                 "final_Double_lab_regression": 271},
           "formal_full_T1_T2_T3": "not_run; 按用户范围只做试验台，完整专项回归/记录复算完成，游戏seed/window未跑",
           "physics_gate": "原完整模型/120Hz/两子步/34变量/epsilon/阈值保持，物理输出精确相同；既有能量精度Gate开放",
           "real_time_human_gate": "open; 当前仍慢于实时，人工体验待确认",
           "continuous_goal": "active; 本块完成不代表持续优化目标完成",
           "raw_evidence_sha256": hashlib.sha256((output/"raw-evidence.zip").read_bytes()).hexdigest()}
(output/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps([{k: group[k] for k in ("scenario", "wall_reduction_percent", "cpu_reduction_percent")} for group in groups], indent=2))
print("source/binaries/config/payload/native boundary/18 physical cases/query counts/validation verified")
