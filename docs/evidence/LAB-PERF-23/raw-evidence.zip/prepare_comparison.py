from pathlib import Path

root=Path.cwd()
source=(root/'logs/lab-perf-22/interleaved.py').read_text(encoding='utf-8').replace('lab-perf-22','lab-perf-23')
source=source.replace('import vehicle_unsprung as vehicle','import vehicle_unsprung as vehicle\nimport unsprung_body as body')
source=source.replace("old_spec=importlib.util.spec_from_file_location('solver_baseline',baseline/'unsprung_joint.py')", "old_spec=importlib.util.spec_from_file_location('observer_baseline',baseline/'vehicle_unsprung.py')")
source=source.replace('''def old_solve(*args,**kwargs):
    kwargs.pop('jacobian_hint')
    return old_geometry.solve_unsprung_joint(*args,**kwargs)''','old_solve=geometry.solve_unsprung_joint')
source=source.replace('new_only=set()',"new_only={'ordinary_cross_rows'}")
source=source.replace('old_geometry.UnsprungJointStep=geometry.UnsprungJointStep','''original_observe,original_read=vehicle.observe_unsprung,vehicle.read_mechanics
original_body_cross,original_vehicle_cross=body.ordinary_cross,vehicle.ordinary_cross''')
source=source.replace('    vehicle.solve_unsprung_joint=old_solve if index in (0,3) else original_solver', '''    vehicle.solve_unsprung_joint=original_solver
    vehicle.observe_unsprung=old_geometry.observe_unsprung if index in (0,3) else original_observe
    vehicle.read_mechanics=old_geometry.read_mechanics if index in (0,3) else original_read
    body.ordinary_cross=np.cross if index in (0,3) else original_body_cross
    vehicle.ordinary_cross=np.cross if index in (0,3) else original_vehicle_cross''')
source=source.replace("source_hashes['A']['unsprung_joint.py']=hashlib.sha256((baseline/'unsprung_joint.py').read_bytes()).hexdigest()", "# 旧模式仅切换叉积实现与观测/读取函数，当前求解器完全共用。")
source=source.replace("root/'logs/lab-perf-21/base-interleaved'/scenario/'B1.bin'", "root/'logs/lab-perf-22/base-interleaved'/scenario/'B1.bin'")
source=source.replace("            if label.startswith('A'):assert binary==expected,(scenario,label)", "            assert binary==expected,(scenario,label)")
source=source.replace("'old_solver_source':str(baseline/'unsprung_joint.py')", "'old_observer_source':str(baseline/'vehicle_unsprung.py'),'old_observer_sha256':hashlib.sha256((baseline/'vehicle_unsprung.py').read_bytes()).hexdigest()")
source=source.replace("        assert difference['changed_discrete_counts'].keys()<={'payload.joint[].iterations'},difference['changed_discrete_counts']", "        assert not difference['changed_discrete_counts'] and all(v==0. for v in difference['numeric_max_abs_deltas'].values())")
source=source.replace('        vehicle.solve_unsprung_joint=original_solver', '''        vehicle.solve_unsprung_joint=original_solver
        vehicle.observe_unsprung,vehicle.read_mechanics=original_observe,original_read
        body.ordinary_cross,vehicle.ordinary_cross=original_body_cross,original_vehicle_cross''')
(root/'logs/lab-perf-23/interleaved.py').write_text(source,encoding='utf-8')
print('exact-output crossover: original NumPy cross/full observer versus ordinary native cross/kinematic observer')
