import cProfile
import inspect
import json
import pstats
import sys
from pathlib import Path
from types import SimpleNamespace

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'tools/performance')]
import compare_lab_compute
import unsprung_joint as joint
import vehicle_unsprung as vehicle
from lab_experiment import LabExperiment

counts={};measured=False
def record(name):
    if measured:counts[name]=counts.get(name,0)+1
old_solver=vehicle.solve_unsprung_joint;old_step=LabExperiment.step
source=inspect.getsource(old_solver)
markers=(('        end,forces,torques = values[:16]','residual'),('            columns = []','jacobian'),
         ('                        jacobian = jacobian+np.outer','update'),
         ('                    values,residual,details = candidate','polish'),
         ('            jacobian = jacobian_hint.previous','warm_seed'),
         ('        jacobian_hint.current = jacobian*','export_seed'))
for marker,name in markers:
    assert source.count(marker)==1,marker
    indentation=marker[:len(marker)-len(marker.lstrip())]
    source=source.replace(marker,indentation+f'_record("{name}")\n'+marker,1)
path=root/'logs/lab-perf-23/profiled_solver.py';path.write_text(source,encoding='utf-8')
namespace=dict(vars(joint));namespace['_record']=record
exec(compile(source,str(path),'exec'),namespace)
vehicle.solve_unsprung_joint=namespace['solve_unsprung_joint']
profile=cProfile.Profile()
def step(run):
    global measured
    measured=True;profile.enable()
    try:return old_step(run)
    finally:profile.disable();measured=False
LabExperiment.step=step
output=root/'logs/lab-perf-23/profile-bump'
try:compare_lab_compute.worker(SimpleNamespace(source=root,scenario='nonlinear-bump',output=output))
finally:vehicle.solve_unsprung_joint=old_solver;LabExperiment.step=old_step
profile.dump_stats(str(output/'step.prof'))
with (output/'profile.txt').open('w',encoding='utf-8') as stream:
    stats=pstats.Stats(profile,stream=stream);stats.sort_stats('cumulative').print_stats(45);stats.sort_stats('tottime').print_stats(25)
rows=[{'file':p,'line':line,'function':name,'calls':values[1],'self_seconds':values[2],'cumulative_seconds':values[3]}
      for (p,line,name),values in stats.stats.items()]
(output/'profile.json').write_text(json.dumps({'ticks':144,'total_seconds':stats.total_tt,'functions':rows,'counts':counts},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (output/'payload.bin').read_bytes()==(root/'logs/lab-perf-23/base-interleaved/nonlinear-bump/B1.bin').read_bytes()
print(counts)
