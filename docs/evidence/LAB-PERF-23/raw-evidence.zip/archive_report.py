"""核对本块执行来源、原算法与完整输出，归档可复核证据。"""
import ast
import copy
import hashlib
import json
import pickle
import re
import sys
import zipfile
from pathlib import Path

root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root/'logs/lab-perf-23')]
from compare_results import compare
from lab_runtime import runtime_fingerprint

logs=root/'logs/lab-perf-23';baseline=root/'builds/lab-perf-23/baseline/src'
output=root/'docs/evidence/LAB-PERF-23';output.mkdir(exist_ok=True,parents=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def source(path):return path.read_text(encoding='utf-8')
def function(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def dump(node):return ast.dump(node,include_attributes=False)
suffixes=('.py','.c','.h','.cpp')
changes=sorted(p.name for p in baseline.iterdir() if p.suffix in suffixes and p.read_bytes().replace(b'\r\n',b'\n')!=(root/'src'/p.name).read_bytes().replace(b'\r\n',b'\n'))
assert changes==['lab_contact_native.h','unsprung_body.py','unsprung_dynamics.py','vehicle_unsprung.py','wheel_contact_kernels.c']
old_header=source(baseline/'lab_contact_native.h');new_header=source(root/'src/lab_contact_native.h')
assert new_header[:new_header.index('/* 普通三维叉积')]+new_header[new_header.rindex('#endif'):]==old_header
registration='    {"ordinary_cross_rows",ordinary_cross_rows_native,METH_VARARGS,"独立轮心原普通三维叉积行批量"},\n'
assert source(root/'src/wheel_contact_kernels.c').count(registration)==1
assert source(root/'src/wheel_contact_kernels.c').replace(registration,'')==source(baseline/'wheel_contact_kernels.c')

class OriginalCross(ast.NodeTransformer):
    def visit_Call(self,node):
        self.generic_visit(node)
        if isinstance(node.func,ast.Name) and node.func.id=='ordinary_cross':
            node.func=ast.Attribute(value=ast.Name(id='np',ctx=ast.Load()),attr='cross',ctx=ast.Load())
        return node

def original_module(path):
    tree=OriginalCross().visit(ast.parse(source(path)))
    for node in tree.body:
        if isinstance(node,ast.ImportFrom):node.names=[n for n in node.names if n.name not in ('ordinary_cross','ordinary_cross_rows')]
    tree.body=[n for n in tree.body if not isinstance(n,ast.ImportFrom) or n.names]
    return tree

body=original_module(root/'src/unsprung_body.py')
assert dump(body)==dump(ast.parse(source(baseline/'unsprung_body.py')))
dynamics=original_module(root/'src/unsprung_dynamics.py')
dynamics.body.remove(function(dynamics,'ordinary_cross'))
assert dump(dynamics)==dump(ast.parse(source(baseline/'unsprung_dynamics.py')))
old=ast.parse(source(baseline/'vehicle_unsprung.py'));new=original_module(root/'src/vehicle_unsprung.py')
raw=function(new,'read_kinematics');axes=function(new,'wheel_axes')
old_read=function(old,'read_mechanics');new_read=function(new,'read_mechanics')
assert dump(axes.body[0].value)==dump(old_read.body[4].value)
new_read.body=copy.deepcopy(raw.body[1:-1])+new_read.body[1:]
new_read.body[4].value=copy.deepcopy(axes.body[0].value)
assert dump(new_read)==dump(old_read)
old_observe=function(old,'observe_unsprung');new_observe=function(new,'observe_unsprung')
inertia=next(n for n in new_observe.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='world_inertia')
assembled=function(dynamics,'assemble_unsprung')
old_inertia=next(n for n in assembled.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='world_inertia')
assert dump(inertia)==dump(old_inertia)
new_observe.body.remove(inertia)
new_observe.body.pop(3)  # 去掉仅提取出来的原轮轴表达式。
new_observe.body[2]=copy.deepcopy(old_observe.body[2])
class OriginalObservation(ast.NodeTransformer):
    def visit_Name(self,node):
        if node.id=='axes':return ast.Attribute(value=ast.Name(id='hardware',ctx=ast.Load()),attr='axes',ctx=node.ctx)
        if node.id=='world_inertia':return ast.Attribute(value=ast.Attribute(value=ast.Name(id='hardware',ctx=ast.Load()),attr='mechanical',ctx=ast.Load()),attr='world_inertia',ctx=node.ctx)
        return node
OriginalObservation().visit(new_observe)
assert dump(new_observe)==dump(old_observe)
new.body.remove(raw);new.body.remove(axes)
assert dump(new)==dump(old)
assert (root/'tests/lab_observation_reference.py').read_bytes()==(baseline/'vehicle_unsprung.py').read_bytes()

runtime=runtime_fingerprint();groups=read(logs/'base-interleaved/summary.json')['groups']
assert len(groups)==3
actual_sources={p.name:sha(p) for p in (root/'src').iterdir() if p.suffix in suffixes}
baseline_native=read(logs/'native-copies.json');native={};quality={};substeps=0
for group in groups:
    scenario=group['scenario'];folder=logs/'base-interleaved'/scenario
    assert group['runtime']==runtime and group['repeat_exact_within_method']
    assert Path(group['support_source_root'])==root/'src'
    assert Path(group['old_observer_source'])==baseline/'vehicle_unsprung.py'
    assert group['old_observer_sha256']==sha(baseline/'vehicle_unsprung.py')
    expected=(root/'logs/lab-perf-22/base-interleaved'/scenario/'B1.bin').read_bytes()
    previous=read(root/'logs/lab-perf-22/base-interleaved'/scenario/'summary.json')
    assert group['options']==previous['options'] and group['actual_config']==previous['actual_config']
    a=(folder/'A1.bin').read_bytes();b=(folder/'B1.bin').read_bytes()
    assert a==b==expected
    difference=compare(pickle.loads(a),pickle.loads(b))
    assert difference==group['difference'] and not difference['changed_discrete_counts']
    assert all(v==0. for v in difference['numeric_max_abs_deltas'].values())
    for row in group['rows']:
        binary=folder/(row['label']+'.bin')
        assert binary.read_bytes()==expected and sha(binary)==row['payload_sha256']
        assert row['source_hashes']==actual_sources
        assert row['substeps']==len(pickle.loads(expected)['joint'])
        substeps+=row['substeps'];label=row['label'][0];native[label]=row['native']
        for name,data in row['native'].items():
            path=Path(data['path']);parent=baseline if label=='A' and name=='wheel_contact_kernels' else root/'src'
            assert path.parent==parent and sha(path)==data['sha256']
    # 原方程复算是22块已运行证据；只对本次完全相同的三个432子步结果复用。
    independent=root/'logs/lab-perf-22/independent-model'/scenario
    quality[scenario]=read(independent/'quality.json')
    assert (independent/'payload.bin').read_bytes()==expected
    assert quality[scenario]['substeps']==len(pickle.loads(expected)['joint'])
    assert quality[scenario]['maxima']['energy_recompute_gap']==0.
    assert quality[scenario]['maxima']['momentum_error']<1e-9
    assert quality[scenario]['maxima']['force_error']<1e-5
    assert quality[scenario]['maxima']['port_error']<1e-9
assert substeps==1728 and sum(q['substeps'] for q in quality.values())==432
for name,digest in baseline_native.items():
    assert sha(baseline/name)==digest
    same=sha(root/'src'/name)==digest
    assert same==(not name.startswith('wheel_contact_kernels.'))
build=source(logs/'build-final.log')
assert build.count('building ')==1 and "building 'wheel_contact_kernels'" in build and '/fp:strict' in build

validation={name:read(logs/name/'summary.json') for name in ('T0','T0-standard','lab-regression')}
assert all(v['passed'] for v in validation.values())
validation_counts={}
for name in validation:
    matches=re.findall(r'(\d+) passed',source(logs/name/'pytest.log'));assert len(matches)==1
    validation_counts[name]=int(matches[0])
assert validation_counts=={'T0':78,'T0-standard':78,'lab-regression':826}
assert validation['lab-regression']['runtime']==runtime and len(validation['lab-regression']['tests'])==46
profile=read(logs/'profile-bump/profile.json');previous=read(root/'logs/lab-perf-22/profile-bump/profile.json')
expected_counts={'residual':3486,'jacobian':8,'update':1311,'polish':288,'export_seed':288,'warm_seed':287}
assert profile['counts']==previous['counts']==expected_counts
assert (logs/'profile-bump/payload.bin').read_bytes()==(logs/'base-interleaved/nonlinear-bump/B1.bin').read_bytes()
profile_result=read(logs/'profile-bump/result.json');previous_result=read(root/'logs/lab-perf-22/profile-bump/result.json')
assert profile_result['source_hashes']==actual_sources
assert profile_result['runtime']==previous_result['runtime']
profile_runtime=profile_result['runtime']
assert (profile_runtime['panda'],profile_runtime['bullet'],profile_runtime['scalar_bits'])==(runtime['panda_version'],runtime['bullet_version'],runtime['math_scalar_bits'])
assert sha(Path(profile_runtime['module']))==runtime['files']['panda3d/core.cp314-win_amd64.pyd']
for name,data in previous_result['native'].items():
    assert baseline_native[Path(data['path']).name]==data['sha256']
for name,data in profile_result['native'].items():assert sha(Path(data['path']))==data['sha256']
previous_EOL_variants={}
for name,digest in previous_result['source_hashes'].items():
    raw=(baseline/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()==digest:continue
    lf=raw.replace(b'\r\n',b'\n')
    matched=[label for label,data in (('LF',lf),('CRLF',lf.replace(b'\n',b'\r\n'))) if hashlib.sha256(data).hexdigest()==digest]
    assert len(matched)==1,name
    previous_EOL_variants[name]=matched[0]
profile_counts={}
for label,data in (('A',previous),('B',profile)):
    values={}
    for name,file in (('read_mechanics','vehicle_unsprung.py'),('observe_unsprung','vehicle_unsprung.py'),('assemble_unsprung','unsprung_dynamics.py'),('drivetrain_ports','unsprung_drivetrain.py'),('query','radial_geometry.py'),('box_section','box_radial_geometry.py'),('normal_material','unsprung_contact.py'),('solve','_linalg.py')):
        values[file+':'+name]=sum(r['calls'] for r in data['functions'] if r['function']==name and Path(r['file']).name==file)
    values['np.cross']=sum(r['calls'] for r in data['functions'] if r['function']=='cross' and Path(r['file']).name=='numeric.py')
    values['native.ordinary_cross_rows']=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.ordinary_cross_rows>' in r['function'])
    values['native.box_cone_refine']=sum(r['calls'] for r in data['functions'] if 'wheel_contact_kernels.box_cone_refine>' in r['function'])
    profile_counts[label]=values
assert profile_counts['A']['np.cross']==8496 and profile_counts['B']['np.cross']==0
assert profile_counts['B']['native.ordinary_cross_rows']==8496
for key in profile_counts['A']:
    if key in ('np.cross','native.ordinary_cross_rows','vehicle_unsprung.py:read_mechanics','unsprung_dynamics.py:assemble_unsprung','unsprung_drivetrain.py:drivetrain_ports'):continue
    assert profile_counts['A'][key]==profile_counts['B'][key],key
for key in ('vehicle_unsprung.py:read_mechanics','unsprung_dynamics.py:assemble_unsprung','unsprung_drivetrain.py:drivetrain_ports'):
    assert profile_counts['A'][key]==432 and profile_counts['B'][key]==288

with zipfile.ZipFile(output/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.log','.txt','.py','.md','.bin','.prof','.pkl','.csv') and 'user-data' not in path.parts and path.name!='archive-report.log':
            archive.write(path,path.relative_to(logs).as_posix())
    for path in baseline.glob('*.pyd'):archive.write(path,'executed-native/baseline/'+path.name)
    for path in (root/'src').glob('wheel_contact_kernels*.pyd'):archive.write(path,'executed-native/current/'+path.name)
    for name in changes:archive.write(baseline/name,'executed-source/baseline/'+name)
    for path in (root/'logs/lab-perf-22/profile-bump').iterdir():
        if path.is_file():archive.write(path,'reused-baseline-profile/'+path.name)
    for scenario in quality:
        for name in ('quality.json','payload.bin'):
            path=root/'logs/lab-perf-22/independent-model'/scenario/name
            archive.write(path,'reused-equation-validation/'+scenario+'/'+name)
    for name in [*['src/'+name for name in changes],'src/unsprung_joint.py','tests/test_lab_observation_native.py','tests/lab_observation_reference.py','tests/test_lab_jacobian_hint.py','tests/lab_solver_model_reference.py','tests/lab_solver_validation.py','tools/physics/unsprung_step_checkpoint.py','tools/performance/compare_lab_compute.py']:
        archive.write(root/name,'executed-source/'+name)
with zipfile.ZipFile(output/'raw-evidence.zip') as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(set(archive.namelist()))
summary={'baseline':'1a32677','source_changes':changes,'groups':groups,'substeps_in_performance':substeps,
         'support_source_hashes_are_context_not_old_binary_build_manifest':True,
         'old_mode':'shared current support/solver + baseline whole read_mechanics/observe_unsprung + direct np.cross aliases + baseline private wheel; no hint parameter removed',
         'old_binary_build_source':{name:sha(baseline/name) for name in ('wheel_contact_kernels.c','lab_contact_native.h')},
         'ordinary_cross_and_removed_dead_assembly_only_ast_verified':True,
         'reused_baseline_profile_EOL_variants':previous_EOL_variants,'profile_counts':profile_counts,'solver_counts':expected_counts,
         'reused_432_substep_equation_validation':quality,'quality_scope':'22块已跑；本块三个实际B输出与其payload逐字节相同。较长停车/2,4,8细化本块未重跑，不能当作本版新增覆盖。',
         'validation':validation,'validation_counts':validation_counts,'native':native,
         'other_four_native_unchanged':True,'runtime':runtime,'current_source_hashes':actual_sources,
         'formal_T1_T2_T3':'not_run; Double46模块826项试验台专项及真实记录复算；游戏seed/window未跑',
         'open_gates':['原完整能量/精度','人工体验','实时','原EPA部分旋转网格边缘拒绝'],'continuous_goal':'active',
         'raw_evidence_sha256':sha(output/'raw-evidence.zip')}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('verified:',validation_counts,'substeps',substeps,'source AST/native/output provenance exact')
print('profile counts:',profile_counts)
